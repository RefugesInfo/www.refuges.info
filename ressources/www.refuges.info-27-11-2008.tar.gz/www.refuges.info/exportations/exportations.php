<?php
//**********************************************************************************************
//* Nom du module:         | exportations.php                                                  *
//* Date :                 |                                                                   *
//* Cr�ateur :             |                                                                   *
//* R�le du module :       | renvoi un fichier au format souhait� contenant les donn�es        *
//*                        | souhait�es                                                        *
//*                        | le lien d'acc�s � pour format :                                   *
//*                        | exportations.php?format=kmz&liste_id_point_type=1-5&liste_id_massif=5-6-8 *
//*			| Google Maps EST BAS� la dessus !
//*------------------------|-------------------------------------------------------------------*
//* Modifications(date Nom)| Elements modifi�s, ajout�s ou supprim�s                           *
//*------------------------|-------------------------------------------------------------------*
//* 14/01/06 tivencent     | v1.4                                                              * 
//*                        | Module d'export de le base vers un fichier XML lisible par        *
//*                        | GoogleEarth (.kmz)   + telechargement automatique                 *
//* 05/11/07 sly           | Reprise du code de tivincent et ajout de fonctionnalit�s          *
//*                        | Et rangement dans des fonctions et modularisation du tout         *
//*                        |                                                                   *
//*                        |                                                                   *
//* 17/11/2007 jmb	| tvx compatibilit� feedvalidator.org, dans le but d'importer ce format dans le nav sat
//*			| rajout du choix par cadrage lat/long
//*			 | remplacement de '-' par ',' dans l'URL pour un decodage SQL avec IN (list) *
//*			| dans le but d'utiliser ce code pour ggmaps *
//*			| tri: par importance, pour les Folders, il ne faut pas 2 importance = , chgment dans la base
//* 1/12/2007 jmb   rajout du charset iso8859 dans les headers envoy�s (entre autres)
//* 03/08 jmb SQL
//**********************************************************************************************

require("../include/zip.lib.php"); // Librairie pour compresser en ZIP (phpfrance.com) 
require("../include/fonctions_exportations.php");
include('../include/fonctions.php');
include('../include/fonctions_points.php');

connexion_base();

// r�cup�ration de notre liste de point
if ($_GET["limite"]!="sans")
	$conditions->limite=120;
$conditions->type_point=$_GET['liste_id_point_type'];
$conditions->pas_les_points_caches=1;
$conditions->latitude_minimum=$_GET['bbox_latmin'];
$conditions->latitude_maximum=$_GET['bbox_latmax'];
$conditions->longitude_minimum=$_GET['bbox_lngmin'];
$conditions->longitude_maximum=$_GET['bbox_lngmax'];
$conditions->ordre="point_type.importance DESC, points_gps.longitude DESC";
$conditions->liste_id_point=$_GET['liste_id_point'];
$conditions->id_polygone=$_GET['liste_id_massif'];
$liste_points=liste_points($conditions);

$nombre_resultat=$liste_points->nombre_points;

/** selon le type, en cr�er le bon ent�te de fichier **/
switch ($_GET['format'])
{
	case "kmz":case "kml":$output=entete_kml();break;
	case "gpx-garmin":case "gpx":$output=entete_gpx();break;
	case "poi":$output="";break;
	case "csv":$separateur=";";
		$output="id_point".$separateur."nom".$separateur."type".$separateur."massif";
		$output.=$separateur."altitude".$separateur."latitude".$separateur."longitude";
		$output.=$separateur."qualit� GPS".$separateur."nombre de place\r\n";
	break;
	default:die("Erreur : le format que nous demand� n'existe pas");
	break;
}

$kml_folder="";

/** ici on s'occupe point par point du r�sultat de la requ�te **/
while ($point=mysql_fetch_object($liste_points->resultat))
{
	switch ($_GET['format'])
	{
		case "kmz":case "kml":
			// Dans le cas du kml/kmz, on arrange les points par "dossier"
			// c'est un conteneur xml qui permet une l�gende plus claire de GoogleEarth
			if ($point->nom_type!=$kml_folder)
			{ // visiblement on change de dossier
				if ($kml_folder!="") // si ce n'est pas le premier dossier, on ferme le pr�c�dent
					$output.="</Folder>\r\n";
				// on cr�er le nouveau dossier
				// rajout utf8encode pour compatibilit� feedvalidator.org
				$output.="<Folder><name>$point->nom_type</name>\r\n<open>0</open>";
				// on met � jour notre variable pour pas cr�er un nouveau dossier � chaque fois
				$kml_folder=$point->nom_type;
			}
			$output.=placemark_kml($point);
		break;
		case "gpx-garmin":
			$output.=waypoint_gpx($point,"garmin");
		case "poi":
			$output.=poi_export_line($point);
		break;
		case "gpx":
			$output.=waypoint_gpx($point,"complet");
		break;
		case "csv":
			$output.=csv_export_line($point);
		break;

	}
$last_point=$point;
}

if ($nombre_resultat!=1)
	$nom_fichier="refuges-info";
else
	$nom_fichier=replace_url($last_point->nom);


/** ici on s'occupe des choses � faire en fin de fichier **/
switch ($_GET['format'])
{
	case "kmz":$output.="</Folder>\r\n</Document>\r\n</kml>";
		$zip = new zipfile() ; //on cr�e un fichier zip
		$zip->addfile($output, $nom_fichier.".kml") ; //on ajoute le fichier
		$output = $zip->file() ; //on associe l'archive
		$content_type="application/vnd.google-earth.kmz";
	break;
	case "kml":$output.="</Folder>\r\n</Document>\r\n</kml>";
		$content_type="application/vnd.google-earth.kml";
	break;
	case "gpx-garmin":
		$content_type="application/gpx";
		$output.="</gpx>";
		$_GET['format']="gpx";
	break;
	case "csv":$content_type="text/csv";break;
	case "gpx":
		$content_type="application/gpx";
		$output.="</gpx>";
	break;
	
	case "csv":$content_type="text/csv";break;
}



header("Content-disposition: attachment; filename=$nom_fichier.".$_GET['format']);
header("Content-Type: $content_type; charset=ISO-8859-1"); // rajout du charset
header("Content-Transfer-Encoding: binary");
header("Content-Length: ".strlen($output));
header("Pragma: no-cache");
header("Expires: 0");
print($output);


?>