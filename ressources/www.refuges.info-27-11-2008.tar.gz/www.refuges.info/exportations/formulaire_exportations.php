<?php
//**********************************************************************************************
//* Nom du module:         | formulaire_exportations.php                                       *
//* Date :                 |                                                                   *
//* Cr�ateur :             |                                                                   *
//* R�le du module :       | Pr�parer un lien d'exportation direct de nos donn�es              *
//*                        | vers plein de formats pour �tre r�-utiliser                       *
//*                        | Le traitement proprement dit est dans exportations.php            *
//*                        | voir aussi le fichier exportations.php                          *
//*------------------------|-------------------------------------------------------------------*
//* Modifications(date Nom)| Elements modifi�s, ajout�s ou supprim�s                           *
//*------------------------|-------------------------------------------------------------------*
//* 12/01/06  tivencent    | Module de cr�ation du formulaire en vue de l'exportation          * 
//*                        | vers GoogleEarth appel vers le module "export_google.php"ncent    *
//* 05/11/07 sly           | premi�re version, en reprenant le code de tivincent               *
//*                        |                                                                   *
//* 17/11/07 jmb 		| ajout des balises <label>, pour un cochage + facile *
//*				| remplacement de '-' par ',' dans l'URL pour un decodage SQL plus direct, valide RFC *
//* 23/02/08 jmb     | passage en fieldset/legend, en list, en button et en cosmetiques divers. ca se vera plus qd on changera de CSS
//* 				| �galement des modifs pour XHTML strict
//*				| rajout d'un morceau BoundaryBox qd on vient du navigateur
//* 03/2008	jmb	D�coration, H4/H5 au lieu de H2 et <abbr>
//**********************************************************************************************

$formats="kmz (googleearth), gpx, csv ( tableurs )";
$titre_page="Formulaire d'exportation de la base refuges.info aux formats $formats";

$explications['kmz']="
<h4>Le format <abbr title='Keyhole Markup language Zipped'>KMZ</abbr></h4>
<p>
Le format d'export \"kmz\" est le format natif de GoogleEarth dans une version compress�e avec zip
Le logiciel GoogleEarth est disponible ici gratuitement :<a href=\"http://earth.google.com/\">GoogleEarth</a>
</p>
";
$explications['kml']="
<h4>Le format <abbr title='Keyhole Markup Language'>KML</abbr></h4>
<p>
Le format d'export \"kml\" est le format natif de Google Earth
Le logiciel GoogleEarth est disponible ici gratuitement :<a href=\"http://earth.google.com/\">GoogleEarth</a>
</p>
";
$explications['gpx']="
<h4>Le format <abbr title='GPs eXchange format'>GPX</abbr></h4>
<p>
Le format \"gpx\" est en phase de devenir un standard pour transf�rer des points, des routes et des traces GPS.
Il a le grand avantage d'�tre lu par une multitude de logiciel GPS et peut ensuite �tre converti pour �tre entr�
dans un terminal GPS.
</p>
<p>
Explications sur la page de wikipedia :
<a href=\"http://fr.wikipedia.org/wiki/GPX\">GPX sur wikipedia</a>
<h5>Dans ce format vous trouverez les donn�es suivantes :</h5>
<p>
latitude, longitude, altitude, nom du point, type de point, qualit� des coordonn�es GPS, remarques, acc�s
</p>
</p>
";
$explications['gpx-garmin']="
<h2>Le format <abbr title='GPs eXchange format'>GPX</abbr> ( pour Garmin )</h2>
<p>
Le format \"gpx\" est en phase de devenir un standard pour transf�rer des points, des routes et des traces GPS.
Il a le grand avantage d'�tre lu par une multitude de logiciel GPS et peut ensuite �tre converti pour �tre entr�
dans un terminal GPS.
</p>
<p>
Cette version, par rapport � la version compl�te n'inclus que peu d'information mais permet d'�tre plus l�g�re a utiliser.
</p>
<h5>Dans ce format vous trouverez les donn�es suivantes :</h5>
<p>
latitude, longitude, altitude, nom du point
</p>
";
$explications['csv']="
<h4>Le format <abbr title='Comma Separated Values'>CSV</abbr></h4>
<p>
Le format \"csv\" est un grand classique pour partager des donn�es, il est tr�s simple d'utilisation et peut �tre lu par un tableur
ou pour un traitement informatis�. Il est moins performant que gpx mais peut s'av�rer utile
</p>
<p>
Il s'agit en fait d'un fichier texte dont les champs de donn�es sont s�par�s par des ;
<p>
<h5>Dans ce format vous trouverez les donn�es suivantes dans l'ordre :</h5>
<p>
id_point;nom;type;massif;altitude;latitude;longitude;qualit� GPS;nombre de place
</p>
";
$explications['poi']="
<h4>Le format <abbr title='Point Of Interest'>POI</abbr> pour GPS garmin</h4>
<p>
Le format \"poi\" est un format sp�cifique � la gamme de terminaux GPS garmin
</p>
<p>
Il s'agit en fait d'un fichier texte dont les champs de donn�es sont s�par�s par des ,
<p>
<h5>Dans ce format vous trouverez les donn�es suivantes dans l'ordre :</h5>
<p>
latitude,longitude,nom,nom+type.
</p>
<p>
Il est adapt� � la taille m�moire des terminaux garmin ayant des limitations en taille
</p>
";

require("../include/fonctions.php");
require("../include/fonctions_autoconnexion.php");
// virage du language= pour etre conforme XHTML (jmb)
$if_javascript='<script src="/include/exportations.js" type="text/javascript"></script>';

include("../include/header.php");
print("<h3>Exportation de la base refuges.info aux formats $formats</h3>");

// comme on se "post" les informations � soit m�me, on v�rifie dans quel cas on est
if (!isset($_POST['validation'])) // rien de valider, formulaire vierge
{
	print("<h4>Veuillez pr�ciser les options pour l'exportation</h4>");
	$query_dossier = "Select id_point_type,nom_type from point_type order by importance desc";
	$result_dossier = mysql_query($query_dossier) or die("Impossible d'interroger la base de donn�es");

	//Ecriture du formulaire HTML pour les cases � cocher

	$form_points="<form id='choix' method='post' action='".$_SERVER['SCRIPT_NAME']."'>";
	
	// Choix des types de points 
	$form_points.="<fieldset><legend>Choix des points de la base a exporter</legend>";
	$form_points.="<ul>";
	while ($row = mysql_fetch_array($result_dossier)) {
		$form_points.="\n
			<li style='display: inline;
						display: inline-block;
						width: 13em;
						white-space: nowrap;'>
				<label>
					<input
						type='checkbox'
						name='id_point_type[]'
						value='$row[0]' ";
		if (isset($_GET['id_point_type']))
			if (in_array($row[0], $_GET['id_point_type']) )
				$form_points.=" checked='checked' ";
		$form_points.="\n
					/>
					$row[1] &nbsp;
				</label>
			</li>";
		// faut croire que l'inline-block est pas standard ou koi ? les brouteurs ne le supporte pas ... j'aime pas ca... /jmb
		// opera sait faire, lui
	}
	$form_points.="</ul>";

	print($form_points);
	print("
		<button type='button' onclick=\"setCheckboxes('choix', true,'id_point_type[]'); return false;\">
			Tout cocher
		</button>
			&nbsp;/&nbsp;
		<button type='button' onclick=\"setCheckboxes('choix', false,'id_point_type[]'); return false;\">
			Tout d�cocher
		</button>
	</fieldset> <!-- fin de l'encadr� type de points -->
	");

	// choix des diff�rents massifs
	print("<fieldset><legend>Choix des massifs de la base a exporter :</legend>");

	// Creation d'une case � cocher pour chaque type massif
	$query_dossier = "Select id_polygone,nom_polygone 
			from polygones
			where 
			id_polygone_type=".$config['id_massif']."
			ORDER BY nom_polygone";
	$result_dossier = mysql_query($query_dossier) or die("Impossible d'interroger la base de donn�es");

	print("\n<ul>");
	while ($row = mysql_fetch_array($result_dossier)) {
		print("  
			<li style='display: inline;
						display: inline-block;
						width: 13em;
						white-space: nowrap;'>
				<label>
					<input
						type='checkbox'
						name='id_massif[]'
						value='$row[0]' ");
		if ( ! isset($_GET['id_massif']) )
			print(" checked='checked' "); // checked par defo
		else
			if ($_GET['id_massif'] == $row[0]) 
				print(" checked='checked' "); //checked seulement si bon massif
		print("
					/>$row[1] &nbsp;
				</label>
			</li>");
	}
	print("\n</ul>");

	print("
		<button type='button' onclick=\"setCheckboxes('choix', true,'id_massif[]'); return false;\">
			Tout cocher
		</button>
			&nbsp;/&nbsp;
		<button type='button' onclick=\"setCheckboxes('choix', false,'id_massif[]'); return false;\">
			Tout d�cocher
		</button>
	</fieldset> <!-- fin du choix des massifs -->
	");

	// zone BBOX a exporter seulement si present en GET (on viendrait du navigator)
	if(isset($_GET["bbox_latmin"]) )
	{
		print("
			<fieldset><legend>Limites (en degr�s d�cimaux WGS84)</legend>
				<table>
					<tr>
						<td></td>
						<td style='text-align: center;'><input name='bbox_latmax' id='bbox_latmax' type='text' size='4' value='" .$_GET["bbox_latmax"]. "' /></td>
						<td></td>
					</tr>
					<tr style='height: 4em;'>
						<td><input name='bbox_lngmin' id='bbox_lngmin' type='text' size='4' value='" .$_GET["bbox_lngmin"]. "' /></td>
						<td style='background-color: #A6CEE7;'>Zone � exporter</td>
						<td><input name='bbox_lngmax' id='bbox_lngmax' type='text' size='4' value='" .$_GET["bbox_lngmax"]. "' /></td>
					</tr>
					<tr>
						<td></td>
						<td style='text-align: center;'><input name='bbox_latmin' id='bbox_latmin' type='text' size='4' value='" .$_GET["bbox_latmin"]. "' /></td>
						<td></td>
					</tr>
				</table>
			</fieldset>
			");
	}
	// choix du format d'exportation

	print('
	<fieldset><legend>Choix du format d\'exportation :</legend>
		<select name="format">
			<option value="kmz">kmz ( format GoogleEarth compress�)</option>
			<option value="kml">kml ( format GoogleEarth )</option>
			<option value="csv">csv ( format compatible tableur )</option>
			<option value="gpx">gpx ( format d\'echange GPS standard )</option>
			<option value="gpx-garmin">gpx ( simplifi� - terminal GPS )</option>
			<option value="poi">POI ( garmin POI )</option>
		</select> 
	</fieldset>
	');


	// bouton pour obtenir le lien
	print("
		<fieldset><legend>Obtenir le lien d'acc�s direct</legend>
			<input type='submit' name='validation' value='Obtenir le lien' />
		</fieldset>
		</form>
		");

//-------------------------
// Fin du formulaire
}
/**
Si on est en mode "action" donc on pr�sente un lien, on aurait pu zapper cette
�tape en postant directement le fichier souhait�, mais je ne le veux pas
car le but �tant de permettre le partage � des partenaires 
(et donc avec des robots de synchronisation)
je veux leur indiquer qu'il existe un lien en GET pour le faire
sly 02/11/2008
**/
else // formulaire valid�, affichage du lien et d'un blabla
{
	print("
	<h4>Licence</h4>
		<p>
			<a href=\"".lien_mode_emploi("licence")."\">Voir les d�tails sur la licence de refuges.info</a>	
		</p>
	");
	print($explications[$_POST['format']]);

	print("
	<h4>Exportation demand�e</h4>
		<p>Voici le lien permanent d'acc�s direct aux donn�es :<br>");

	if ($_POST['id_point_type']=="" OR $_POST['id_massif']=="")
		print("<strong>Vous demandez vraiment quelque chose de vide ??</strong>");
	else
	{
		foreach ($_POST['id_point_type'] as $id_point_type)
			$liste_id_point_type.="$id_point_type,";

		$liste_id_point_type=trim($liste_id_point_type,",");

		foreach ($_POST['id_massif'] as $id_massif)
			$liste_id_massif.="$id_massif,";

		$liste_id_massif=trim($liste_id_massif,",");

		// limite a la bbox, rajout jmb 02/08
		if(isset($_POST['bbox_latmin']) ) {
			$bbox = "&amp;bbox_latmin=" . $_POST['bbox_latmin'] ;
			$bbox .= "&amp;bbox_latmax=" . $_POST['bbox_latmax'] ;
			$bbox .= "&amp;bbox_lngmin=" . $_POST['bbox_lngmin'] ;
			$bbox .= "&amp;bbox_lngmax=" . $_POST['bbox_lngmax'] ;
		} else {
			$bbox = "";
		}
			
		$options_lien="?limite=sans&amp;format=".$_POST['format']."&amp;liste_id_point_type=$liste_id_point_type&amp;liste_id_massif=$liste_id_massif" . $bbox;
		$lien="http://www.refuges.info/exportations/exportations.php$options_lien";

		print("
				<a href='$lien'>
					$lien
				</a>
			</p>");
	} // fin du else 'demande pas vide"

} // fin du else affichage lien

include("../include/footer.php");
?>
