<?php
//**********************************************************************************************
//* Nom du module:         | point_ajout_etape2.php                                            *
//* Date :                 | 05/10/2007                                                        *
//* Cr�ateur :             | sly                                                               *
//* R�le du module :       | Etape 2 dans l'ajout d'un point                                   *
//*                        | Le but �tant de demander quel point l'internaute va-t-il ajouter  *
//*                        | pour ne pas lui demander le nombre de place d'un sommet !         *
//*------------------------|-------------------------------------------------------------------*
//* Modifications(date Nom)| Elements modifi�s, ajout�s ou supprim�s                           *
//*------------------------|-------------------------------------------------------------------*
//* 05/10/2007 sly         | Fini les tables, de jolies classes CSS avec du zoli xhtml         *
//* 06/03/08 jmb           | new version avec d�co                                             *
//**********************************************************************************************


require("include/fonctions.php");
require("./include/fonctions_autoconnexion.php");
include("./include/fonctions_gmaps.php");

$mysqlink=connexion_base();
$etape="�tape 2/3";

$message_etape = "Ajout d'un point";
$titre_page=strip_tags($message_etape);


$if_javascript= "
	<!--  CHARGEMENT DES LIBS GOOG MAPS -->
	<!-- gros script google maps contenant toute l'API , avec notre clef d'enregistrement-->
	<script src='http://maps.google.com/maps?file=api&amp;v=2.x&amp;key=". $config["gmaps_key"] ."' type='text/javascript' charset='iso-8859-1'></script>

	<script type='text/javascript' charset='iso-8859-1'>
		// pr�-charge les IMAGES de points

		". GM_cree_icones_points() ."
	</script>

	<!-- les fonctions maison gmaps -->
	<script type='text/javascript' src='/include/gmaps.js' charset='iso-8859-1'></script>
";

$if_onloadscript=" onload=\"init_icones(); vignette(document.getElementById('mapvignette'),".$_GET['y'].",". $_GET['x'].");\"
					onunload=\"GUnload();\"";

include("./include/header.php");


$htmlconstruct="
<div class=\"contenu\">
<h3>$message_etape</h3>
<h4>$etape</h4>
";

// Prepare la vignette
//$largeur_vignette=200;
//$hauteur_vignette=300;
//$ech=40; // 40m= 1px
//$vignette= "/wms_image.php?"
//."center=".urlencode(serialize( array("x" => $_GET['x'], "y" => $_GET['y'] )))
//."&amp;pix=".urlencode(serialize(array("width" => $largeur_vignette, "height" => $hauteur_vignette)))
//."&amp;ech=".$ech // echelle de 50m=1px
//."&amp;iconecenter=ne_sait_pas"; // icone a dessiner au centre (facultatif)

//-------------------DEBUT VIGNET
//coordonn�es du point en x:longitude et y:latitude
$centre = array( "x" => $_GET['x'], "y" => $_GET['y'] );
//-------------------------FIN VIGNETTE

$message_non_connecte=avertissement_connexion();

$htmlconstruct.= "
<div
	class='gmaps'
	id='mapvignette'
	style='width: 200px; height: 300px; overflow: hidden; float: right;'>
</div>
";

if ( $message_non_connecte )
	$htmlconstruct.= "
		<h5>Connexion annonyme</h5>
			<p>$message_non_connecte</p>
	";

$htmlconstruct.= "
	<h5>Licence des contenus</h5>
		<p>".$config['message_licence']."</p>
";
$htmlconstruct.= "
	<h5>Que mettre ou ne pas mettre ?</h5>
		<p>Tout ne trouve pas sa place sur le site, merci de prendre connaissance de <a href=\"".lien_mode_emploi("que_mettre")."\">ce qui est attendu ou pas sur le site</a></p>
";
	
$htmlconstruct.= "
<form method='get' action='/point_formulaire_modification.php'>
	<fieldset><legend>Type de point</legend>
		<input type='hidden' name='x' value='".$_GET['x']."'/>
		<input type='hidden' name='y' value='".$_GET['y']."'/>
    
		<select name='id_point_type'>";
	
			$requete_type_point="SELECT * FROM point_type ORDER BY importance DESC";
			$resultat=mysql_query($requete_type_point);
			while ($liste_point_type=mysql_fetch_object($resultat))
				$htmlconstruct.="
					<option $selected value=\"$liste_point_type->id_point_type\">$liste_point_type->nom_type</option>";

			mysql_free_result($resultat);

			$htmlconstruct .= "
		</select>
		<p>Si le point que vous voulez ajouter ne trouve pas son 'type' vous pouvez venir en parler sur le forum afin que nous �tudions la possiblit� de l'ajouter</p>

		<input type='submit' name='action' style='text-align: center;' value='Continuer, �tape suivante' />
	</fieldset>
</form>
</div>
";
echo $htmlconstruct ;

include("./include/footer.php");

?>  
