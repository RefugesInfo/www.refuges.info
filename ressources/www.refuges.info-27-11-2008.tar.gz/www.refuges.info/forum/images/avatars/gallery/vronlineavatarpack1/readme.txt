                                         ------:::::::::::::: \\ .....VRonline Release..... // :::::::::::::::--------

|| Avatar Pack 1 ||

This pack is free to use for all purposes, and contains a set of 16 quality avatars based upon common web programming
languages, such as - HTML, PHP, MySQL.

VRonline Avatar Pack 1 is copyright http://www.vrumchev.com


------------------------------------------------------------------------------------------------------------------------------------------------

For many more free resources and tutorials, check VRonline at http://www.vrumchev.com or you may alternately visit the
VRonline forums at http://www.vrumchev.com/forum/ to request whatever you need.