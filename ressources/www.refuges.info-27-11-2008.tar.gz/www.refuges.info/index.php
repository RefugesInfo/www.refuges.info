<?php
//**********************************************************************************************
//* Nom du module:         | index.php                                                         *
//* Date :                 |                                                                   *
//* Cr�ateur :             |                                                                   * 
//* R�le du module :       | Ecran d'accueil (nouvelles)                                       *
//*                        |                                                                   *
//*                        | Acc�s par "http://www.refuges.info/                               *
//*                        |                                                                   *
//*------------------------|-------------------------------------------------------------------*
//* Modifications(date Nom)| Elements modifi�s, ajout�s ou supprim�s                           *
//*------------------------|-------------------------------------------------------------------*
//* 10/03/06 rff           | d�placement �chelle � droite en bas de l'image. Ajout instr. de   *
//*                        | lib�ration query sql                                              *
//* 21/03/06 rff           | Insertion infos de session : utile pour gestion du cache & menu   *
//*                        | gestion. Ajout layer 'polygones'                                  *
//*                        |                                                                   *
//**********************************************************************************************

require("./include/fonctions.php");
require("./include/fonctions_gmaps.php");

require_once("./include/fonctions_autoconnexion.php");
require_once("./include/fonctions_massifs.php");
$titre_page="Carte des refuges, cabanes et abris de montagne dans les alpes";
require_once("./include/header.php");


//-------------------------------------
// CARTE
?>
			
	<script src='http://maps.google.com/maps?file=api&amp;v=2.x&amp;key=<?php echo $config["gmaps_key"] ; ?>' type='text/javascript' charset='iso-8859-1'></script>
	<script type='text/javascript' src='/include/gmaps.js' charset='iso-8859-1'></script>
<div class="contenu">
	<ul style='display: block;'>
		<li><q>refuges.info</q> est un site web non commercial qui regroupe et pr�sente des informations sur de nombreux refuges de montagne</li>
		<li>c'est un site collaboratif o� les informations sont fournies, mises � jour et compl�t�es par les utilisateurs</li>
		<li>Il <em>n'est le site officiel d'aucun refuge</em> et ne dispense pas de contacter le gardien ou le propri�taire directement 
			(<a href="/statique/mode_emploi.php">en savoir plus</a>)</li>
		<li style="padding-left: 15em;"><a href='/statique/don.php' style="text-decoration: underline;"><strong>nous avons besoin de vous !</strong></a></li>
	</ul>

	<!-- Carte des alpes -->
	<table style='border: none;'>
		<tr>
			<td>
				<div class='gmaps' id='map_alpes' style='width: 700px; height: 500px;'></div>
			</td>
			<td style='vertical-align: top;'>
				<!-- SUR CE DIV VIENNENT S'INSERER LES MINIMAPS DES MASSIFS EXTERIEURS -->
				<div class='gmaps' id='minimaps' style='overflow: hidden;'></div>
			</td>
		</tr>
	</table>

	<script type='text/javascript' charset='iso-8859-1'>

	//  charge la map Gmaps, elle s'appellera 'map' et puis c'est tout ! 
	//----------CREATION DE LOBJET MAP-------------------
	map = new GMap2( document.getElementById('map_alpes') );
	map.addMapType(G_PHYSICAL_MAP); // ajoute la possibilit� RELIEF (v2.94)
	map.setCenter( new GLatLng(45,7) , 7 , G_PHYSICAL_MAP ); // centre, zoom et type

	//-----------MASQUAGE DES CONTROLES SI INACTIF--------------------
	map.hideControls(); // cache les controles
	map.disableDragging();

	// charge le tablo "listemassifs" avec tous les GPolygon dedans 
	<?php echo GM_cree_massifs(TRUE) ; ?>

	while (listemassifs.length > 0) {
		var massif = listemassifs.pop() ;

		if (massif.getBounds().intersects(map.getBounds()) ) {
			// le massif apparait au moins en partie sur la map normale. chargement.
			map.addOverlay( massif );
			
			// ajoute un point au milieu avec l'infobulle
			boutonmassif( map, massif );

		} else {
			// Le massif n'apparait PAS (nlle caledonie, reunion)

			// creation d'une minimap SPECIFIQUE avec un ID au random.... C moche
			var idmap = "map_" + String( Math.round(Math.random()*1000) ) ;
			var newmapdiv = document.createElement("div");
			// newmapdiv.setAttribute("style","height: 120px; width: 120px;"); // marche pas pour IE. bug connu.
			newmapdiv.style.cssText = "height: 120px; width: 120px;"; // sens� marcher partout, mais pas de W3C

			// accolle le div qu'on vient de faire au parent minimaps
			document.getElementById("minimaps").appendChild(newmapdiv);

			// construit la minimap dans ce div
			var minimap = new GMap2( newmapdiv );
			// ajuste le zoom au massif
			var zoom = minimap.getBoundsZoomLevel( massif.getBounds() ) ;
			minimap.addMapType(G_PHYSICAL_MAP); // ajoute la possibilit� RELIEF (v2.94)
			minimap.setCenter( massif.getBounds().getCenter() , zoom , G_PHYSICAL_MAP ); // centre, zoom et type

			minimap.hideControls(); // cache les controles
			minimap.disableDragging(); // map statique

			minimap.addOverlay(massif) ; // ajout du massif dans cette minimap, sinon ca serta a rien...

			// ajoute un point au milieu avec l'infobulle
			boutonmassif( minimap, massif );

			// GESTION DU CLIC SUR POLYGONE
			// abandonn� si on utilise le "bouton"
			//GEvent.addListener(minimap, 'click', function(overlay, point) {
			//	if (overlay) {
			//		if (overlay.mylink) {
			//			window.location.href=overlay.mylink;
			//		}
			//	}
			//}); // fin du event listener de la minimap
			
		} // fin de la gestion des minimaps
		
	} // fin du parcours des massifs

	// GESTION DU CLIC SUR POLYGONE
	// abandonn� si on utilise le "bouton"
	//GEvent.addListener(map, 'click', function(overlay, point) {
	//	if (overlay) {
	//		// we now need a check here in case the overlay is the info window
	//		// only our markers will have a .myhtml property
	//		if (overlay.mylink) {
	//			window.location.href=overlay.mylink;
	//			// overlay.openInfo... march pas, chais pas pkoi, donc :
	//			// attention, ne marche quavec les POLYGON
	//		}
	//	}
	//}); // fin du event listener de la map generale

	</script>
	
	<!-- FIN DU BLOC CARTE -->

	<!-- BLOC APROPOS -->
  <dl style='clear: both;'>
    <dt><strong>Refuges.info</strong>, c'est:</dt>
    <dd>
		<ul style='list-style: disc inside;'>
			<li>Base de donn�es maintenue par les visiteurs dynamiquement</li>
			<li>Si vous connaissez les coordonn�es GPS du point � ajouter, <a href="/point_ajout_etape2.php">aller directement ici</a></li>
			<li>Photos et renseignements pr�cis accompagnant les refuges ( pas toujours mais souvent :-)</li>
			<li>Un groupe de b�n�voles qui se bougent pour les refuges</li>
			<li>Lire le <a href="/statique/mode_emploi.php">mode d'emploi</a> pour en savoir plus</li>
			<li>N'h�sitez pas a venir laisser un message sur le <a href="/forum">forum</a>!</li>
		</ul>
	</dd>
  </dl>
</div>
<!-- FIN BLOC APROPOS -->


<?php 
include("./include/footer.php");
?>
