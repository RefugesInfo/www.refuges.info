<?php
//**********************************************************************************************
//* Nom du module:         | point_formulaire_modification.php                                 *
//* Date :                 |                                                                   *
//* Cr�ateur :             |                                                                   *
//* R�le du module :       | Modification/cr�ation de fiche point.                             *
//*                        |                                                                   *
//*------------------------|-------------------------------------------------------------------*
//* Modifications(date Nom)| Elements modifi�s, ajout�s ou supprim�s                           *
//*------------------------|-------------------------------------------------------------------*
//* 21/03/06 rff           |*mysql_free_result et script php unique sans inclusions html(html  *
//*                        |renvoy� au client par commande echo. Anciennes balises php enlev�es*
//*                        |*Insertion infos de session : utile pour gestion du cache & menu   *
//*                        | gestion.                                                          *
//*                        |*la table 'massifs' devient 'polygones' dans la base 'refuges'     *
//*                        |*Ajout date du jour par d�faut ds 'derni�re visite'                *
//*                        |                                                                   *
//* 15/04/07 jmb           |*ajout de "auteur", et suppr des tables. conforme XHTML 1          *
//* 06/10/07 sly           |Formulaire dynamique selon le type de point � ajouter/modifier     *
//* 06/03/08 jmb           | new version avec d�co                                             *
//* 03/07/08 jmb	   | d�placement du include header a la fin                            *
//* 19/10/08 sly           | remplacement de auteur et id_auteur par l'utilisateur a avoir fait*
//*                        | la derni�re modification
//**********************************************************************************************

require("include/fonctions.php");
require("include/fonctions_points.php");
require("./include/fonctions_autoconnexion.php");
include("./include/fonctions_gmaps.php");

// fonction pour mourrir sur un message d'erreur ;-)
function erreur_on_arrete($texte)
{
	include("./include/header.php");
	print("
	<h3>Erreur</h3>	
	<p>$texte
	</p>");
	include("./include/footer.php");
	die(); // peut �tre moyen de faire mieux mais bon, gros probl�me donc on se tire
}

// 4 cas :
// 1) On veut faire une modification, on ne s'arr�t que si le point n'est pas trouv�
// ou si les droits sont insuffisants
if ( isset($_GET["id_point"]) )  
{
	// on charge
	$point=infos_point($_GET['id_point']);
	// Merde stop, le point n'existe pas
	if ($point==-1) 
		erreur_on_arrete("<h3>probl�me ? vous essayez de modifier un point qui n'existe pas ?</h3>");

	// il existe, le niveau de droit est-il suffisent ?
	if ( $_SESSION['niveau_moderation']<1 AND $_SESSION['id_utilisateur']!=$point->id_auteur_derniere_modification ) 
		erreur_on_arrete("D�sol�, mais pour cette op�ration vous devez �tre mod�rateur du site et connect� au forum
		<a href=\"".$config['connexion_forum']."\">Connexion forum</a>");

	// boutton en plus
	$boutton_supprimer="<input type='submit' name='action' value='Supprimer' />";

	//cosm�tique
	$icone="&amp;iconecenter=ne_sait_pas";
	$action="Modification";
	$verbe="Modifier";
	$etape="";
}
// 2) on veut faire une cr�ation, on va rempli les champs avec ceux du mod�le
elseif ( isset($_GET["id_point_type"]))  
{
	$conditions->type_point=$_GET["id_point_type"];
	$conditions->modele=1;
	$resultat_modele=liste_points($conditions);
	if ($resultat_modele->nombre_point!=1)
		print("<strong>oulla big probl�me, le mod�le du point ".$_GET["id_point_type"]." n'est pas dans la base, on continue avec les champs vides</strong>");
	else
		$point=mysql_fetch_object($resultat_modele->resultat);

	// on force les latitude � ce qui a �t� cliqu� sur la carte (si existe, sinon vide)
	$point->longitude=$_GET["x"];
	$point->latitude=$_GET["y"];

	// on force l'id du point � vide histoire de ne pas modifier le mod�le
	$point->id_point="";

	// cosm�tique
	$icone="&amp;iconecenter=".$point->nom_icone;
	$action="Ajout";
	$verbe="Ajouter";
	$etape="<h4>�tape 3/3</h4>";
}
// 3) on veut dupliquer l'actuel mais garder les m�mes coordonn�es
elseif ( isset($_GET["dupliquer"]))
{
	$conditions->type_point=$_GET["dupliquer"];
	$point=infos_point($_GET["dupliquer"]);
	// on force l'id du point � vide histoire de ne pas modifier la copie
	$point->id_point="";
	$point->nom="";
	$point->proprio="";
	$point->proprio="";
	$point->remark="";
	$point->id_point_type="";
	$point->article_partitif_point_type=""; 
	$point->nom_type="";
	// param�tre cach� du point_gps
	$deja_point_gps.="<input type='hidden' name='id_point_gps' value='$point->id_point_gps' />";

	// cosm�tique
	$disabled_field=" style=\"background-color: #e3d4d4\" onFocus=\"javascript: this.blur()\"";
	$action="Copie avec coordonn�es identiques";
	$verbe="Ajouter";
	$icone="&amp;iconecenter=".$point->nom_icone;
	$etape="<h4>�tape 1/2</h4>";
}
// 4) On ne devrait pas arriver en direct sur ce formulaire
else
	erreur_on_arrete("<h3>Vous n'auriez pas d� arriver sur cette page en direct</h3>");
$boutton_actions="<fieldset><legend>Validation</legend>
		$deja_point_gps
		<input type='hidden' name='id_point' value='$point->id_point' />
 		<input type='submit' name='action' value='$verbe' />
		<input type='reset' value='Recommencer' />
		$boutton_supprimer
	</fieldset>";
$if_javascript= "
	<!--  CHARGEMENT DES LIBS GOOG MAPS -->
	<!-- gros script google maps contenant toute l'API , avec notre clef d'enregistrement-->
	<script src='http://maps.google.com/maps?file=api&amp;v=2.x&amp;key=". $config["gmaps_key"] ."' type='text/javascript' charset='iso-8859-1'></script>

	<script type='text/javascript' charset='iso-8859-1'>
		// pr�-charge les IMAGES de points

		". GM_cree_icones_points() ."
	</script>

	<!-- les fonctions maison gmaps -->
	<script type='text/javascript' src='/include/gmaps.js' charset='iso-8859-1'></script>

";

// necessaire pour la vignette gmaps
$if_onloadscript=" onload=\"init_icones(); vignette(document.getElementById('mapvignette'),".$point->latitude.",". $point->longitude.");\"
					onunload=\"GUnload();\"";


//pr�paration de la listbox des types de points disponibles
//---------------------------------------------------------

$type_selected[$point->id_point_type]=" selected=\"selected\"";
$html_listbox="";
$sql_point_possible="select * from point_type
			ORDER BY importance desc";
$query_point_possible=mysql_query($sql_point_possible);
while ($type_possible=mysql_fetch_object($query_point_possible))
      $html_listbox.="\t<option value=\"$type_possible->id_point_type\"".$type_selected[$type_possible->id_point_type].">$type_possible->nom_type</option>\n";
mysql_free_result($query_point_possible);


$htmlconstruct.= "
<div class=\"contenu\">
<h3>$action $point->article_partitif_point_type $point->nom_type</h3>
$etape

<!--   ========= VIGNETTE GMAPS ========== -->
<div
	class='gmaps'
	id='mapvignette'
	style='width: 200px; height: 300px; overflow: hidden; float: right;'>
</div>
<p>
	Rien d'obligatoire mais essayez d'�tre pr�cis ne laissez pas les valeurs par d�faut; au pire, remplacez par un blanc.
</p>

<form name='point' method='post' action='/point_modification.php'>
	$boutton_actions
	<fieldset><legend>Coordonn�es gps</legend>
		<label>latitude:<input$disabled_field type='text' id='latitude' name='latitude' size='12' maxlength='12' value='$point->latitude' /></label>
		<label>longitude:<input$disabled_field type='text' id='longitude' name='longitude' size='12' maxlength='12' value='$point->longitude' /></label>
		(En degr�s d�cimaux Syst�me WGS84 exemple : 45.2356 et -5.2354)
		<br />
		<label>Pr�cision GPS:
		<select$disabled_field name='id_type_precision_gps'>";

		$requete_type_precision="SELECT * FROM type_precision_gps ORDER BY ordre";
		$resultat=mysql_query($requete_type_precision);
		
		while ($liste_precision_gps=mysql_fetch_object($resultat))
		{
			if ($liste_precision_gps->id_type_precision_gps==$point->id_type_precision_gps)
				$selected="selected='selected'";
			else
				$selected="";

			$htmlconstruct.="
				<option $selected value='$liste_precision_gps->id_type_precision_gps'>$liste_precision_gps->nom_precision_gps</option>";
		}
		mysql_free_result($resultat);

		$htmlconstruct.="
		</select></label>
	</fieldset>

	<fieldset><legend>informations basiques</legend>
		<label>nom :
			<input size=\"40\" type=\"text\" name=\"nom\" value=\"" . htmlentities($point->nom,ENT_QUOTES) . "\" />
		</label>
		<br />Type de point :
			<select name='id_point_type'>
				$html_listbox 
			</select>
		<br />\n";
// tous les points n'ont pas de raison d'avoir ce champ ( lac, sommets, etc.)
if ($point->equivalent_places!="")
{
  $htmlconstruct .= "
      <label>".$point->equivalent_places."<input type=\"text\" name=\"places\" size=\"8\" value=\"".$point->places."\" /></label>\n" ;
}

//rff 21/03/06 : intro date du jour par d�faut
$htmlconstruct .="
		<label>altitude:<input$disabled_field type=\"text\" name=\"altitude\" size=\"6\" value=\"".$point->altitude."\" />m</label>
	</fieldset>\n";

// tous les points n'ont pas forc�ment un propri�taire ( lac, sommet, etc. )
if ($point->equivalent_proprio!="")
{
    $htmlconstruct .="
	<!-- debut zone proprio .................................................................... !-->
	<fieldset><legend>$point->equivalent_proprio</legend>\n
		<textarea name='proprio' cols='55' rows='2'>"
			.$point->proprio.
		"</textarea>$config[lien_syntaxe]
	</fieldset>
	<!-- fin   zone proprio .................................................................... !-->\n";
}

$htmlconstruct .="
<!-- debut zone acc�s ...................................................................... !-->\n
     <fieldset><legend>acc�s:</legend>\n
		<textarea$disabled_field name='acces' cols='60' rows='5'>"
			.$point->acces.
		"</textarea>$config[lien_syntaxe]
     </fieldset>
<!-- fin   zone acc�s ...................................................................... !-->

<!-- debut zone remarques .................................................................. !-->\n
	<fieldset><legend>remarques:</legend>\n
		<textarea name='remark' cols='60' rows='5'>"
			.$point->remark.
		"</textarea>
		$config[lien_syntaxe]<br />
		Si vous souhaitez indiquer une source d'eau, 
		une partie gard�e ou hivers au MEME endroit, 
		vous pourrez le faire par \"duplication\" a l'�tape d'apr�s.
	</fieldset>
<!-- fin   zone remarques .................................................................. !-->
";
// on pr�-remplit le champ auteur si celui-ci est connect�
if (isset($_SESSION['id_utilisateur']))
	$auteur_modification=$_SESSION['login_utilisateur'];
elseif (!isset($_GET['id_point']))
	$auteur_modification="";

$htmlconstruct .="
	<fieldset><legend>Mettez votre nom ou pseudo (facultatif)</legend>\n
		<label><input type='text' name='auteur_modification' maxlength='40' size='41' value=\"".htmlentities($auteur_modification,ENT_QUOTES)."\" /></label>
	</fieldset>\n";

// si l'internaute est connect� et qu'il veut modifier (donc souvent un mod�rateur, sauf cas o� il est l'unique modificateur de la fiche )
// on lui demande si sa modification est mineure, auquel cas on �vitera de le noter comme dernier modificateur de la fiche
if (isset($_SESSION['id_utilisateur']) && isset($_GET['id_point']))
	$htmlconstruct.="
	<fieldset><legend>Si coch�e, on ne se souviendra pas de vous dans la modification</legend>
		<label><input name='modification_mineure' type='checkbox' size='1' value='1'/> Modification mineure</label>
	</fieldset>
	";



// si la personne n'est pas mod�rateur, on demande un code visuel anti-robot. sly
if (!isset($_SESSION['id_utilisateur']))
	$htmlconstruct.="
	<fieldset><legend>Protection anti-Spam</legend>
		<label><input name='lettre_securite' type='text' size='1' />Entrez la lettre <strong>d</strong></label>
	</fieldset>
	";

$htmlconstruct .= "\n
	$boutton_actions
   </form>
  </div>
</div>
";

// ===================================
// Affichage de la page, c'est a la fin quon affiche.
// le include header doit etre apres la declaration des variable JS onload

include("./include/header.php");

echo $htmlconstruct ;

include("./include/footer.php");

?>  
