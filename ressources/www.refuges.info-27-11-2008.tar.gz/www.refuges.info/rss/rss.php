<?php

// --------------
// GENERE UN FLUX RSS
//
// param:
//     -"listeobjets": une liste des id_point_type a integrer dans le RSS (ex: "1,3,4,5,6')
//     -"listemassifs": une liste des id_polygone de massifs a integrer dans le RSS (ex: "1,3,4,5,6')
//
// Renvoie un XML RSS2.0
// chaque item a un title, un link, une descrition et une pubDate
// JM nov 2006

// FIXME : j'ai l'impression d'avoir d�j� vu le formulaire dans export
// et je pense qu'il y aurait du code � regrouper l�
// soit avec export, soit avec la page news...
// je le fais pas tout de suite car il y a pas mal de diff�rence, mais � voir
// sly 02/11/2008

require("../include/fonctions.php");
require("../include/fonctions_nouvelles.php");
require("../include/fonctions_points.php");
require("../include/fonctions_massifs.php");


$mysqlink=connexion_base();


$listetypes = $_GET["listeobjets"] ;
$listetypes = str_replace( "-", ",", $listetypes ) ;

$listemass = $_GET["listemassifs"] ;
$listemass = str_replace( "-", ",", $listemass);

$nbjours = $_GET["jours"] ;

$datedeb = time() - $nbjours*24*60*60 ; // le RSS commencera il y a X jours
$pointurl = "http://www.refuges.info/point/" ; // il ne reste plus que l'ID a concatener
$longdesc = 500 ; // longueur en char du champ description. apres c'est "(...)"



//---------------------
// fonction qui prend un item en tablo et renvoie le XML
// A ADAPTER SUIVANT la version de RSS 1.0, 2.0 ou Atom
function affiche_item ($item)
{
	// la fonction mt_rand sert juste a avoir un GUID unique...........
	return "
	<item>
		<title>".stripslashes(htmlspecialchars($item["title"]))."</title>
		<link>".$item["link"]."</link>
		<guid>".$item["link"]."/".mt_rand(1,1000)."</guid>
		<description>".stripslashes(htmlspecialchars($item["description"]))."</description>
		<pubDate>".date('r',$item["pubdate"])."</pubDate>
		<category>".$item["category"]."</category>
		<!-- <enclosure url='http://www.refuges.info/images/icones/abri.png'
				length='178'
				type='image/png' /> -->
	</item> ";
}

//------------------------
// ent�te XML du flux, avec la description des objets et des massifs concernes
// A ADAPTER SUIVANT la version de RSS 1.0, 2.0 ou Atom
function debut_flux ($types, $massifs, $date)
{
	// recup des vrais noms des points
	$q = " SELECT nom_type
		FROM point_type
		WHERE id_point_type IN ($types) ";
	$rs = mysql_query($q) or die("mauvaise requete: $q");
	while( $typ = mysql_fetch_assoc($rs) )
		$typesentexte .= pos($typ) . ", " ;

	// recup des vrais noms des massifs
	$q = " SELECT nom_polygone
		FROM polygones
		WHERE id_polygone IN ($massifs) ";
	$rs = mysql_query($q) or die("mauvaise requete: $q");
	while( $mass = mysql_fetch_assoc($rs) )
		$massifsentexte .= pos($mass) . ", " ;

	return
"<?xml version='1.0' encoding='UTF-8' ?>
<?xml-stylesheet type='text/xsl' href='rss.xsl' ?>
<rss version='2.0' xmlns:dc='http://purl.org/dc/elements/1.1/'>
   <channel>
	<title>Derniers messages sur refuges.info</title>
	<link>http://www.refuges.info</link> <!-- ici lien vers la conf des flux -->
	<language>fr</language>
	<description>Flux RSS du site refuges.info concernant $typesentexte dans les massifs de $massifsentexte depuis le ".date("d/m/Y", $date)."</description>
	<image>
		<title>www.refuges.info</title>
		<url>http://www.refuges.info/images/logorss.png</url>
		<link>http://www.refuges.info</link>
		<width>138</width>
		<height>69</height>
	</image>
" ;
}


//----------------------
// COEUR du PROGRAMME
//

// Pour chaque categorie de message ( nouveaux points, commentaire, forum, annonces generales)
// je me demerde pour que le SQL renvoie "title,description,pubdate,link,category"
// c'est les champs qui deviendront du XML.

// depuis tous les changements du coeur de la base, je suis mort pour reprendre ces
// requ�tes de la mort qui vont devenir des requ�tes de la mort de l'enfer qui tue la vie
// je tente une bidouille avec les fonctions sur les news (�a ressemble en fait ;-))
// pour arriver � un pauvre truc vite fait qui affiche en gros dans le RSS ce qu'affiche les 
// news, y'a moyen je pense de trouver comment passer ce que souhaite l'internaute
// a voir si des gens s'en servent !
// sly 02/11/2008

//  $query["nouveaux"] = "
// 	SELECT
// 		CONCAT('Nouveau: ',t.nom_type, ', ', p.nom, ' (',y.nom_polygone, ')') AS title,
// 		CONCAT(
// 			LEFT(p.remark, $longdesc),
// 			IF(CHAR_LENGTH(p.remark)>$longdesc, ' (...)','')
// 			) AS description,
// 		p.date_insertion AS pubdate,
// 		CONCAT('$pointurl',p.id_point) AS link,
// 		CONCAT('nouveau,', t.nom_type) AS category
// 	FROM points p
// 		LEFT JOIN point_type t USING (id_point_type)
// 		LEFT JOIN polygones y ON y.id_polygone= p.id_massif
// 	WHERE
// 		p.id_point_type IN ($listetypes)
// 		AND p.id_massif IN ($listemass)
// 		AND p.date_insertion > $datedeb 
// 		AND p.modele!=1";
// 
//  $query["comments"] = "
// 	SELECT
// 		CONCAT('Commentaire sur: ', p.nom, ' (',y.nom_polygone, ')') AS title,
// 		CONCAT(
// 			LEFT(c.texte, $longdesc),
// 			IF(CHAR_LENGTH(c.texte)>$longdesc, ' (...)',''),
// 			IF(c.photo_existe, ' (photo)', '')
// 			) AS description,
// 		UNIX_TIMESTAMP(c.date) AS pubdate,
// 		CONCAT('$pointurl',p.id_point) AS link,
// 		CONCAT('commentaire,', t.nom_type) AS category
// 	FROM commentaires c, points p, point_type t, polygones y
// 	WHERE
// 		c.id_point=p.id_point
// 		AND p.id_point_type=t.id_point_type
// 		AND p.id_massif=y.id_polygone
// 		AND p.id_point_type IN ($listetypes)
// 		AND p.id_massif IN ($listemass)
// 		AND UNIX_TIMESTAMP(c.date) > $datedeb 
// 		AND p.modele!=1";
// 
//  $query["forum"] = "
//  	SELECT
// 		CONCAT(
// 			'Forum de: ', p.nom,
// 			' (', y.nom_polygone, ') ',
// 			x.post_subject ) AS title,
// 		CONCAT( LEFT(x.post_text, $longdesc),
// 			IF(CHAR_LENGTH(x.post_text)>$longdesc, ' (...)','')
// 			) AS description,
// 		o.post_time AS pubdate,
// 		CONCAT('http://forum.refuges.info/viewtopic.php?t=', t.topic_id) AS link,
// 		CONCAT('forum,', pt.nom_type) AS category
// 	FROM phpbb_topics t, phpbb_posts o, phpbb_posts_text x, points p, point_type pt, polygones y
// 	WHERE
// 		p.id_point=t.topic_id_point
// 		AND p.id_point_type=pt.id_point_type
// 		AND p.id_massif=y.id_polygone
// 		AND o.topic_id=t.topic_id
// 		AND o.post_id=x.post_id
// 		AND p.id_point_type IN ($listetypes)
// 		AND p.id_massif IN ($listemass)
// 		AND o.post_time > $datedeb
// 		AND t.topic_first_post_id < t.topic_last_post_id ";
// 
//  $query["general"] = "
//  	SELECT
// 		texte AS title,
// 		'' AS description,
// 		UNIX_TIMESTAMP(date) AS pubdate,
// 		'http://www.refuges.info' AS link,
// 		'general' AS category
// 	FROM commentaires
// 	WHERE
// 		id_point=".$config['numero_commentaires_generaux']."
// 		AND UNIX_TIMESTAMP(date) > $datedeb ";
// 
//  // envoie les requetes les unes apres les autres dans SQL
//  // et melange tout dans un seul gros tableau
//  foreach($query as $sql)
//  {
// 	$rs = @mysql_query($sql);// or die("mauvaise requete: $sql");
// 	while($tabnews[] = @mysql_fetch_assoc($rs));
// 
// 	array_pop($tabnews); // vire le dernier element, toujours vide.
//  }
//  
//  //a OK, maintenant que TOUT est dans tabnews, faut trier par pubdate.
// 
//  if ($tabnews)
//  {
//  // -------COPIE DIRECT de PHP.NET pour trier le tableau par date
//  // Obtient une liste de colonnes
//  foreach ($tabnews as $key => $row) {
// 	$pubdate[$key]  = $row['pubdate'];
// 	}
//  // Tri les donn�es par pubdate d�croissant,
//  // Ajoute $data en tant que dernier param�tre, pour trier par la cl� commune
//  array_multisort($pubdate, SORT_DESC, $tabnews);
//  // -------
//  }

 // Prepare les header (sinon il envoie du HTML! )
 header("Content-Type: text/xml; charset=UTF-8");
 $flux = debut_flux($listetypes, $listemass, $datedeb);
$news_array=affiche_news(10,"commentaires,points",TRUE);
 foreach ($news_array as $news)
{
	$item["pubdate"]=$news['date'];
	$item["title"]=$news['categorie']." : ".$news['titre'];
	$item["link"]=$news['lien'];
	$item["description"]=$news['text'];
	$item["category"]=$news['categorie'];
	
 	$flux .= affiche_item($item);
}
 $flux .= "\n  </channel>\n</rss>";
 echo utf8_encode($flux);

 //---------------------------
 // 5/9/2008 jmb
 // trace car bcp de trafic bizarre, pour voir la repartition en fct des IP
 // je pense qu'il y a de vieux lecteur RSS trop reactifs qui nous font monter le traffic
 // a virer a terme
 file_put_contents( "IPs_rss_WRI.txt"  , $_SERVER["REMOTE_ADDR"] . "\n" , FILE_APPEND ) ;

 
 //------------------------
 // Exemple de worldkit:
 // WORLDKIT est un GIS en flash
 //echo $flux;


/*

	<channel>
		<title>worldKit welcome feed</title>
		<link>http://www.brainoff.com/worldkit/</link>
		<description>Sample feed for worldKit</description>
		<item>
			<title>Essai caban</title>
			<description>Description cabane</description>
			<link>http://10.0.0.5/rfi</link>
			<geo:lat>45.00492</geo:lat>
			<geo:long>5.56415</geo:long>
			<pubDate>Sat, 07 Sep 2002 00:00:01 +00:00</pubDate>
		</item>
	</channel>
</rss>
*/
?>
