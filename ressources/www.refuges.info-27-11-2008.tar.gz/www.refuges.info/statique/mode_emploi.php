<?php
//**********************************************************************************************
//* Nom du module:         | mode_emploi.php                                                   *
//* Date :                 |                                        2008                       *
//* Cr�ateur :             |                                       jmb sur texte Nicolas Masson*
//* R�le du module :       | Descriptif, licence, fonctionnement,... du site                   *
//*                        | On appel le fichier sous forme  mode_emploi.php?page=truc         *
//*------------------------|-------------------------------------------------------------------*
//* Modifications(date Nom)| Elements modifi�s, ajout�s ou supprim�s                           *
//*------------------------|-------------------------------------------------------------------*
//* 23/02/08 jmb           | cosmetique H3 et H4                                               *
//* 03/2008 jmb            |rajout "on fait des trucs" et header2                              *
//* 23/10/2008 sly         |page de re-subdivision sous forme de wiki manuel ;-)               *
//* 24/10/2008 sly         |finalement un quasi-vrai wiki sans historique que pour mod�rateurs *
//**********************************************************************************************

/* je dis pas que c'est une super id�e, mais je tente, tout se trouve dans un sous repertoire avec les textes 
ici c'est une sorte de metamoteur qui g�n�re le tout
�a ressemble � une sorte de "wiki" avec les tags phpBB et HTML autoris�s + nos codes internes [->12] (lien vers un point de la base)
c'est donc "un peu" plus rapide � �crire et disponible pour les mod�rateurs, les liens entres pages sont plus simples et centralis�s
sly 23/10/2008
*/

require("../include/fonctions.php");
require("../include/fonctions_points.php");
require_once("../include/fonctions_autoconnexion.php");

// fonction qui va chercher le texte du fichier correspondant � la page 
function recupere_contenu($page)
{
global $config;
// lieu du fichier texte correspondant � la page souhait�e
$fichier=$config['document_root']."/statique/mode_emploi_textes/".$page.".txt";
if (!is_file($fichier))
	return FALSE;
$pointeur=fopen($fichier,"r");
$contenu=fread($pointeur,filesize($fichier));
return $contenu;
}


// fonction qui va r�-�crire le contenu de la page
function ecrire_contenu($page,$contenu)
{
global $config;
// lieu du fichier texte correspondant � la page souhait�e
$fichier=$config['document_root']."/statique/mode_emploi_textes/".$page.".txt";
$pointeur=fopen($fichier,"w");
fwrite($pointeur,$contenu);
}


// recr�er les liens internes au mode d'emploi au format [url=##page][/url] (page �tant la page texte � afficher)
// traite le phpBB code mais en autorisant le HTML (param�tre TRUE)
function genere_contenu($page)
{
if( ($contenu=recupere_contenu($page))==FALSE)
	return FALSE;
// gestion des liens internes au format [url=##page]c'est l� que �a se passe[/url]
$contenu=str_replace("##","./mode_emploi.php?page=",$contenu);
// conversion bbcode
$html=bbcode2html($contenu,TRUE);
return $html;
}

/******************************** DEBUT *****************************/


// �criture du header, du nom de la page, de la div du contenu
if($_GET['page']=="")
	$_GET['page']="index";
$titre_page="Mode d'emploi de refuges.info ".$_GET['page'];
include("../include/header.php");
$html='
<div class="contenu">
';
// lien pour un retour vers l'index du "wiki"
if ($_GET['page']!="index")
	$html.='<a href="./mode_emploi.php">Retour � l\'index du mode d\'emploi</a>
';

// lien modifier, uniquement pour les mod�rateurs
if ($_SESSION['niveau_moderation']>=1 AND ($_GET['form_modifier']!=1))
	$html.='&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="./mode_emploi.php?form_modifier=1&amp;page='.$_GET[page].'">Modifier cette page</a> <br />
';


//forumlaire pour modifier
if ( ($_SESSION['niveau_moderation']>=1) AND ($_GET['form_modifier']==1) )
{
$page_actuelle=htmlentities(recupere_contenu($_GET['page']));
// un petit minimum pour les pages vides
if ($page_actuelle=="")
$page_actuelle="
<h3>Le titre</h3>
	<p>
		Le texte du premier paragraphe
	</p>
";

$html.='<p>
<form method="post" action="./mode_emploi.php?page='.$_GET['page'].'&modifier=1">
	<textarea cols="150" rows="20" name="texte">'.$page_actuelle.'</textarea><br />
	<input type="submit" value="Modifier"/>
</form>
</p>
';
}
elseif(($_SESSION['niveau_moderation']>=1) AND ($_GET['modifier']==1) )
{
ecrire_contenu($_GET['page'],stripslashes($_POST['texte']));
}
	
	if (($html_temp=genere_contenu($_GET['page']))==FALSE)
	{
		if ($_SESSION['niveau_moderation']>=1)
			$html_temp="<p>Cette page n'a pas encore �t� �crite</p>";
		else
			$html_temp="<p>Cette page n'a pas encore �t� �crite, vous pouvez venir sugg�rer un texte sur le forum</p>";
	}
	$html.=$html_temp;
	$html.='
	</div>';


print($html);
include("../include/footer.php");
?>
