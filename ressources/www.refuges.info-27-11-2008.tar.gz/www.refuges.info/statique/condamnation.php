<?php

// 16/03/08: jmb : 	virage de "g�rant : Sylvain Letuffe" nom propre 

$titre_page="Affaire Refuges.info vs IGN";
include("../include/header.php");
?>
<div class="contenu">
<h3>Tribulations judiciaires de Refuges.info (au pays du G�oportail)</h3>

<h4>En bref</h4>
<p>
	Le site <strong>www.refuges.info</strong> a utilis� par le pass� des cartes de randonn�es IGN Top25 pour illustrer les fiches des refuges. Voici un extrait de la <a href="http://www.refuges.info/statique/condamnation-refuges-info.pdf">condamnation</a>:
</p>	
<blockquote cite='/statique/condamnation-refuges-info.pdf'>
	<p>..
		Condamne la <em>SARL GPLSERVICE</em> � payer, en deniers ou quittances valables, � l'<em>Institut G�ographique National</em>:
			<br />la somme de 6 000 euros � titre de dommages et int�r�ts, tous chefs de pr�judice confondus, en raison de <em>ces faits d�lictueux</em>.
			<br />la somme de 1 500 euros au titre de l'article 700 du nouveau code de proc�dure civile.
		<br />Condamne la <em>SARL GPLSERVICE</em> � payer, en deniers ou quittances valables, � la <em>SARL BAYO</em>:
			<br />la somme de 3 000 euros � titre de dommages et int�r�ts, tous chefs de pr�judice confondus, en raison de ces faits d�lictueux.
			<br />la somme de 1 500 euros au titre de l'article 700 du nouveau code de proc�dure civile.
		<br />Ordonne � la soci�t� GPL SERVICE de faire publier la pr�sente d�cision en premi�re page du site <strong>www.refuges.info</strong> dans les 3 jours de la signification de la pr�sente d�cision.
	..</p>
</blockquote>

<dl>
	<dt>"ces faits d�lictueux"</dt>
		<dd>La publication sur refuges.info d'extraits de cartes de randonn�es IGN Top25, en lieu et place des images satellites pr�sentes actuellement</dd>
	<dt>SARL gplservice</dt>
		<dd>L'entreprise qui assure l'h�bergement et la maintenance technique du site</dd>
	<dt>SARL BAYO</dt>
		<dd>Le revendeur (sous licence de l'IGN) des cartes de randonn�es "Top25" sur c�d�rom. Ces c�d�roms ont �t� achet�s puis pirat�s pour en extraire les bouts de cartes incrimin�s</dd>
	<dt>Institut G�ographique National</dt>
		<dd>�tablissement Public de l'�tat, propri�taire des droits d'auteur des cartes en cause</dd>
	<dt>www.refuges.info</dt>
		<dd>Ce site web b�n�vole, cr�� par jean-marc Bourdaret</dd>
</dl>

<h4>Chronologie</h4>
<table style='border: thin solid black;'
	summary="comparaison chronologique entre l'affaire gplservice/refuges.info et le g�oportail">
	<!-- <caption>Chronologie de l'affaire compar�e au G�oportail</caption> -->
	<colgroup>
		<col style='width: 15%; text-align: center;' />
		<col span='2' style='width: 43%;' />
	</colgroup>
	<thead>
		<tr>
			<th>Date</th>
			<th>Affaire www.refuges.info</th>
			<th>Actualit� du G�oportail</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td>Juillet 2004</td>
			<td></td>
			<td>La directive europ�enne <abbr title="INfrastructure for SPatial Information in EuRope">INSPIRE</abbr> est adopt�e par la Commission europ�ene (publication des donn�es g�ographiques � destination du citoyen)</td>
		</tr>
	</tbody>
	<tbody>
		<tr>
			<td>Mars 2005</td>
			<td>Le constat de contrefa�on est �tabli par un huissier mandat� par BAYO, � partir de leurs locaux</td>
			<td></td>
		</tr>
		<tr>
			<td>�t� 2005</td>
			<td>6 juin, La perquisition �ff�ctu�e dans les locaux de gplservice prouve l'�xistence des cartes sur les serveurs. C'est le premier contact entre GPL service et les plaignants. GPL service efface les cartes des serveurs le lendemain, sans que cela lui soit demand�</td>
			<td>il est d�cid� la cr�ation d'un g�oportail pour donner suite � <abbr title="INfrastructure for SPatial Information in EuRope">INSPIRE</abbr></td>
		</tr>
	</tbody>
	<tbody>
		<tr>
			<td>janvier 2006</td>
			<td></td>
			<td>Le projet est officiellement lanc� par <dfn title="Pr�sident de la R�publique Fran�aise de 1995 � 2007">Jacques Chirac</dfn></td>
		</tr>
		<tr>
			<td>Mars 2006</td>
			<td></td>
			<td>campagne de communication de l'IGN autour du futur g�oportail, premi�res d�monstrations, comparaisons avec Google Maps</td>
		</tr>
		<tr>
			<td>Avril 2006</td>
			<td>audience de premi�re instance au tribunal de commerce de Chamb�ry, mise en d�lib�r�</td>
			<td>Premi�re annonce par un responsable technique du projet de la mise � disposition future d'une API (technique permettant d'afficher les cartes sur n'importe quel site web, pas seulement sur le geoportail)</td>
		</tr>
		<tr>
			<td>Juin 2006</td>
			<td>9 juin, d�lib�r� condamnant GPL service � 12 000 euros de dommages et int�r�ts (<a href="/statique/condamnation-refuges-info.pdf">voir le texte</a> et ses confusions) avec �x�cution imm�diate</td>
			<td>23 juin, inauguration du geoportail par Jacques Chirac, Dominique Perben, Jean-Fran�ois Cop� et Nelly Olin. La cartographie � l'�chelle 25:000 (celle incrimin�e) est disponible a partir de cette date.</td>
		</tr>
		<tr>
			<td>Juillet 2006</td>
			<td>GPL service, en concertation avec le webmaster du site, d�cide de faire appel. L'amende est pay�e par GPLservice et le webmaster � part �gales</td>
			<td></td>
		</tr>
	</tbody>
	<tbody>
		<tr>
			<td>2007</td>
			<td>Tentatives de m�diation avec la cellule juridique de l'IGN sans succ�s. Constitution du dossier d'appel</td>
			<td>Le g�oportail s'enrichit tout au long de l'ann�e (3D, cadastre ...)</td>
		</tr>
	</tbody>
	<tbody>
		<tr>
			<td>Janvier 2008</td>
			<td>Audience de la Cour d'Appel de Chamb�ry en d�but d'apr�s-midi. La cour ne juge pas n�c�ssaire l'avis d'un expert, alors qu'elle en a le pouvoir, et visiblement, le besoin.</td>
			<td></td>
		</tr>
		<tr>
			<td>F�vrier 2008</td>
			<td>D�lib�r�, la Cour confirme et aggrave les dommages et int�r�ts de 2 000 euros par plaignant, soit 4 000 euros.</td>
			<td></td>
		</tr>
		<tr>
			<td>Mars 2008 et apr�s</td>
			<td>Maintenant nous sommes pass�s aux frais annexes et suppl�mentaires : 
			<br />- 837.20 TTC et 1554.80 TTC pour notre avocat. 
			<br />- 365 TTC et 516.68 TTC pour notre avou�. 
			<br />- 1744.43 TTC pour les avou�s de la partie adverse.
			<br />- une quarantaine d'euros pour diverses paperasses
			</td>
			<td></td>
		</tr>
		<tr>
			<td>Printemps 2008</td>
			<td></td>
			<td>L'API du G�oportail est attendue ce printemps apr�s plusieurs mois de retard. Mais vous ne la verrez pas de si t�t sur <strong>refuges.info</strong> ...</td>
		</tr>
	</tbody>
</table>
<h4>Un bilan final lourd</h4>
<p>
	Au final, tout compris, cela nous fait la coquette somme de 21 058 euros TTC pay�e � part �gale par les deux webmaster sly et yip. 
	Parfois on se dit qu'il peut couter cher de donner... car refuges.info a toujours �t� gratuit, et les contenus sont m�mes libres de droits !
</p>

<h4>Que faire ?</h4>
<p>
	Voici donc toute l'histoire du site ces derni�res ann�es ...
	On en gardera des cheveux blancs et des poches vides... au mieux.
	Que faire maintenant que la cour d'appel a rendu son verdict ?
	Continuer et aller en cassation ? la cour de cassation est g�n�ralement r�serv�e aux puissants. La confiance dans les institutions est, disons, �mouss�e.
</p>
<p>
	Nous n'en avons pas trop parl� sur le site, � cause de l'appel qui devait �tre jug� en enquel nous mettions nos espoirs que les ammendes soient revues � la baisse.
	Maintenant qu'elle ont �t� revues � la hausse, nous allons mettre en place un <a href="/statique/don.php">syst�me d'�ventuelles donations</a>.
	Les sommes sont exhorbitantes, et il n'est pas question de les �quilibrer avec des dons. Cependant, comme ces sommes ont d�ja �t� pay�es, chaque don sera per�u comme un soutien psychologique, et c'est ce qu'il nous faut.
	Les dons seront partag�s entre Sly et moi-m�me, et je vais r�guli�rement publier ces comptes (anonymes) sur le site.
</p>
	<address>
		Jean-marc Bourdaret (pseudos yip ou boubou)
		<br /> Cr�ateur et co-webmaster du site
	</address>
</div>
<?php
include("../include/footer.php");
?>
