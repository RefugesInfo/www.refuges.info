<?php
// 16/03/08: jmb : virage des noms propres 
// 11/07/08 : jmb : ajout des 2 derniers donateurs, reorganisation pour qu'on sache ou on en est

/*===================================================================
// 	DONATEURS

date : nom complet : montant : moyen : pseudo : adresse
12/03/08 : Nicolas Masson : 636(659) : paypal : Nicolas Masson : 18 rue du Pr� d'Elle 38240 MEYLAN
12/03/08 : Dominique Cavailhez : 1000 : cheque : Dominique : 24 rue du coteau 92370 Chaville ( demand� � bien rester ANONYME )
13/03/08 : Guillaume Laget : 193(200) : paypal : GlaG : 11 rue Antoine Polotti 38400 SAINT MARTIN D'HERES
16/03/08 : Patrice Drouin : 48(50) : paypal : ?? : 2 allee Chauffingeal Lotissement le Chatelain 26120 Chabeuil
17/03/08 : Cyril Excoffon : 48(50) : paypal : ?? : 8 all�e des myosotis 38640 Claix
18/03/08 : Andr� Bois-Crettez : 96(100) : paypal : ?? : 3 av albert 1er de belgique 38000 Grenoble
18/03/08 : Vincent Faure : 29(30) : paypal : ?? : 17,place alexandre labadie 13001 marseille
19/03/08 : ?? : 50 : cheque : ??(oubli�...) : ??
01/04/08 : Olivier Castany : 10 : cheque : Scal (?) : Kerlembars,29280 Plouzan�
====PARTAGE  (1046 euros chacun)=====
10/04/08 : Frederic Gindrey : 96(100) : paypal : ?? : 11 2nd street brooklyn, NY 11231 USA
11/04/08 : Julien Rousset : 19(20) : paypal : ?? : les perrins 38220 ST JEAN DE VAULX
12/04/08 : Thierry Zehnder : 14(15) : paypal : ?? : Vaux 69840 Juli�nas
21/04/08 : Mireille et JeanPierre Moy : 100 : cheque : ? : 15 rue de la Monta 38120 St Egreve
21/04/08 : Fatma Rahmani/JeanLouis Faure : 20 : cheque : ? : 5 passage du bachais 38240 Meylan
05/05/08 : Regis Cahn : 15 : cheque : ? : 11 rue charles peguy 38100 Grenoble
24/05/08 : Patrick Leger : 10 : cheque : ? : 38 rue de vaucoutre 26270 Loriol
08/06/08 : Claude ? : 100 : liquide : Artos : Achieux, 38(?) (rando WRI)
19/06/08 : Romain Joly : 20 : cheque : ?? : 142 rue carnot 60180 Nogent sur oise
28/06/08 : Pascal Blachier : 96(100) : paypal : ?? : Vernay, 73190 Curienne

A PARTAGER : 490 ( frais paypal d�duit)

TOTAL: 10/06/08 : 2600 ( + 50 sans compter frais paypal)

=========================================================================*/

$titre_page="Don au b�n�fice de refuges.info";
include("../include/header.php");

?>
<div class="contenu">

<h3><em>refuges.info</em> a besoin de vous !</h3>

<h4>Pourquoi donner ?</h4>
<p>
	A cause de la <em>fameuse condamnation</em>, assum�e financi�rement par 2 personnes.
	J'ai �crit une <a href='/statique/condamnation.php'>page sp�ciale pour pr�senter l'affaire</a>, page qui se concentre sur les faits et les textes. Voir aussi le <a href="http://forum.refuges.info/viewtopic.php?t=1383">d�bat sur le forum</a>
</p>
<p>
	Les sommes que nous pouvons recevoir (Sly et Yip),
	ne sont pas sur la m�me �chelle que celles que nous avons d�bours�es,
	mais c'est tr�s important de se sentir soutenu dans cette �preuve totalement surr�aliste...
	Et maintenant que la "justice" ne peut plus rien, on essaie de se raccrocher ...
</p>
<p>
	... A <em>vous</em>, visiteurs r�guliers du site. 
	vous qui connaissez la valeur "utile" du site, qui vous est d�stin� evidemment.
	Le site essaie d'�tre l� quand vous en avez besoin, maintenant c'est nous qui avons besoin de vous.
</p>

<h4>Pourquoi <strong>ne pas</strong> donner ?</h4>
<p>
	L'argent <em>n'ira pas</em> � un propri�taire de cabane pour son entretien, voir directement le proprietaire dans ce cas.
</p>
<p>
	C'est un geste personnel et les raisons ne regardent que vous
</p>

<h4>Dons re�us</h4>

<table summary='liste des dons, et total' rules='groups' border='1'>
	<caption>liste des donations re�ues</caption>
	<colgroup />
	<colgroup align="center" />
	<colgroup align="center" />
	<colgroup align="center" style='font-style: italic;' />
	<thead>
		<tr>
			<th>Date</th>
			<th>Montant</th>
			<th>Donateur</th>
			<th>Moyen</th>
		</tr>
	</thead>
	<tfoot>
		<tr>
			<th>10 juillet 2008</th>
			<th><strong>2600 euros</strong></th>
			<th>Total</th>
		</tr>
	</tfoot>
	<tbody>
		<tr><td>12 mars 2008</td><td>636</td><td></td><td>paypal</td></tr>
		<tr><td>12 mars 2008</td><td>1000</td><td></td><td>ch�que</td></tr>
		<tr><td>13 mars 2008</td><td>193</td><td></td><td>paypal</td></tr>
		<tr><td>16 mars 2008</td><td>48</td><td></td><td>paypal</td></tr>
		<tr><td>17 mars 2008</td><td>48</td><td></td><td>paypal</td></tr>
		<tr><td>18 mars 2008</td><td>96</td><td></td><td>paypal</td></tr>
		<tr><td>18 mars 2008</td><td>29</td><td></td><td>paypal</td></tr>
		<tr><td>19 mars 2008</td><td>50</td><td></td><td>ch�que</td></tr>
		<tr><td>01 avril 2008</td><td>10</td><td></td><td>ch�que</td></tr>
		<tr><td>10 avril 2008</td><td>96</td><td></td><td>paypal</td></tr>
		<tr><td>11 avril 2008</td><td>19</td><td></td><td>paypal</td></tr>
		<tr><td>12 avril 2008</td><td>14</td><td></td><td>paypal</td></tr>
		<tr><td>21 avril 2008</td><td>20</td><td></td><td>ch�que</td></tr>
		<tr><td>22 avril 2008</td><td>100</td><td></td><td>ch�que</td></tr>
		<tr><td>05 mai 2008</td><td>15</td><td></td><td>ch�que</td></tr>
		<tr><td>24 mai 2008</td><td>10</td><td></td><td>ch�que</td></tr>
		<tr><td>08 juin 2008</td><td>100</td><td></td><td>liquide</td></tr>
		<tr><td>19 juin 2008</td><td>20</td><td></td><td>ch�que</td></tr>
		<tr><td>28 juin 2008</td><td>96</td><td></td><td>paypal</td></tr>
	</tbody>

</table>

<p>Les frais de Paypal sont d�duits (environ 55 euros, ceci explique les montants de 96 au lieu de 100 euros, 19 au lieu de 20...). Les donations sont anonymes par d�faut.</p>

<h4>O� va l'argent ?</h4>
	<p>
		Les sommes sont �quitablement r�parties entre "Yip" et "Sly". Comme elles sont r�parties pour l'-amende-. Ces deux personnes ont �t� <em>solidaires</em> de GPLservice financi�rement
	</p>
	<dl>
		<dt>Yip</dt>
			<dd>est le cr�ateur du site, co-webmaster, et auteur des copies de cartes ayant �t� diffus�es</dd>
		<dt>Sly</dt>
			<dd>est co-webmaster du site</dd>
	</dl>

<h4>Comment donner ?</h4>
<ul style='list-style-type: disc;'>
	<li>en envoyant un ch�que � "Jean-marc Bourdaret" � l'adresse suivante:
			<address>
				Jean-marc Bourdaret
				109 rue Francis de Pr�ssens� (bat 8E)
				69100 Villeurbanne
			</address>
	</li>
	<li>en utilisant le service de paiement en ligne "Paypal":
		<p>
			l'inscription � leur service n'est pas obligatoire.
			Il est possible d'utiliser une carte VISA.
			Paypal retient entre 3% et 5%, en fonction du montant.
			<br />Cliquer sur ce bouton pour faire un don via Paypal :
		</p>
		<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
			<input type="hidden" name="cmd" value="_s-xclick">
			<input type="image" src="https://www.paypal.com/fr_FR/FR/i/btn/btn_donate_LG.gif" border="0" name="submit" alt="Effectuez vos paiements via PayPal : une solution rapide, gratuite et s�curis�e">
			<img alt=""	border="0" src="https://www.paypal.com/fr_FR/i/scr/pixel.gif" width="1" height="1">
			<input type="hidden" name="encrypted" value="-----BEGIN PKCS7-----MIIImQYJKoZIhvcNAQcEoIIIijCCCIYCAQExggEwMIIBLAIBADCBlDCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb20CAQAwDQYJKoZIhvcNAQEBBQAEgYCIQm/TGI8Xm9OK8nL0YcXrNO0/Hz02tt5RjWqmcI8IjhBs0bYOoQHhBeByThis31JLtWDM9AdxdREgthW8W818Vg1RXkoe46xcqvz6ty8E8T0gtdIC16mcnpclqayMKcx1RamOKr8KC3R2Eh9jZpLI7AkpGwHYQCVOUzqUq0fnNjELMAkGBSsOAwIaBQAwggIVBgkqhkiG9w0BBwEwFAYIKoZIhvcNAwcECNaskLh/8UoJgIIB8DhBLNGq8f2RFL04ImayBBIY7LCOs648sR4TF04nsBm1E/QQcZ11DCExvEVqkF9fRZsSKFOEyZcfcXQ202hdtvq0C9PGr3CSks8tyv35cuZqSmqBZphmwspfJcKwOyOJe4UWuLzlMa4tsQCmXg2Q+nXKSeRvM96Efd+HcX2zKTecAREZ2g2/BNGjC1yyn4Z8nHLLEF7sQvbZnH04x2s4020FdYj38DQF58ulG0ovfRftViGtIzwRoXgM8HC4UB0/g3Gv2pEDQ1IGANRt3UQlGnoEq1YxgTDRt0IN+LX98olGp94Xs7ze9B1Vmg2xepr3tmS9R8361OEPUuQt0Cr3ESncQ9dXGaXH7+OSiL/kk+tkM++NZIyZ2mhHmbXPtsFYvWZcFA5NnuuJk0bAPqQIQw5tfzGYUW3nOZfrbTjn0oXnQY3MVMhh/cSwNx8uU+wru5I61LNE8uvnS12oBtZSrzXZ/OP/K1B6Kbz3DsuHldyBBCag2uLhdVJYI0+/miNVIsqBkHtrhY4+FnevW0PYgRsz3amRma/OUnONg/lafwKONllmnhTFOKjFRd+Bz0obMwfUfHsA6dxfXx/YFM0XSYI2+7aThwfGQ64gOazWfYZZC8rPJRYZPeL6GqQtrh9LnieATSPUVj++Y/jT/9pniwygggOHMIIDgzCCAuygAwIBAgIBADANBgkqhkiG9w0BAQUFADCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb20wHhcNMDQwMjEzMTAxMzE1WhcNMzUwMjEzMTAxMzE1WjCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb20wgZ8wDQYJKoZIhvcNAQEBBQADgY0AMIGJAoGBAMFHTt38RMxLXJyO2SmS+Ndl72T7oKJ4u4uw+6awntALWh03PewmIJuzbALScsTS4sZoS1fKciBGoh11gIfHzylvkdNe/hJl66/RGqrj5rFb08sAABNTzDTiqqNpJeBsYs/c2aiGozptX2RlnBktH+SUNpAajW724Nv2Wvhif6sFAgMBAAGjge4wgeswHQYDVR0OBBYEFJaffLvGbxe9WT9S1wob7BDWZJRrMIG7BgNVHSMEgbMwgbCAFJaffLvGbxe9WT9S1wob7BDWZJRroYGUpIGRMIGOMQswCQYDVQQGEwJVUzELMAkGA1UECBMCQ0ExFjAUBgNVBAcTDU1vdW50YWluIFZpZXcxFDASBgNVBAoTC1BheVBhbCBJbmMuMRMwEQYDVQQLFApsaXZlX2NlcnRzMREwDwYDVQQDFAhsaXZlX2FwaTEcMBoGCSqGSIb3DQEJARYNcmVAcGF5cGFsLmNvbYIBADAMBgNVHRMEBTADAQH/MA0GCSqGSIb3DQEBBQUAA4GBAIFfOlaagFrl71+jq6OKidbWFSE+Q4FqROvdgIONth+8kSK//Y/4ihuE4Ymvzn5ceE3S/iBSQQMjyvb+s2TWbQYDwcp129OPIbD9epdr4tJOUNiSojw7BHwYRiPh58S1xGlFgHFXwrEBb3dgNbMUa+u4qectsMAXpVHnD9wIyfmHMYIBmjCCAZYCAQEwgZQwgY4xCzAJBgNVBAYTAlVTMQswCQYDVQQIEwJDQTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEUMBIGA1UEChMLUGF5UGFsIEluYy4xEzARBgNVBAsUCmxpdmVfY2VydHMxETAPBgNVBAMUCGxpdmVfYXBpMRwwGgYJKoZIhvcNAQkBFg1yZUBwYXlwYWwuY29tAgEAMAkGBSsOAwIaBQCgXTAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqGSIb3DQEJBTEPFw0wODAzMDgxOTMyMTNaMCMGCSqGSIb3DQEJBDEWBBT7gII1ygZVCwMfNwW5PXv+MLFrDTANBgkqhkiG9w0BAQEFAASBgLWPeGNg45NsPS5vBU59Q6XhM7yldHCie8dZVxFJ9xcJRvXB07bLX40cgMFUEw1NCdrcY5mrbBOrNTcx1BZjmGQTQ15QgRvGsWsaYrG+Jx6WA3FWiv5CvRphyplvx4tBsBL3eKDglM0c1e2YIXXAqiWyIsXjabBOBxI0c3cxRvGu-----END PKCS7-----">
		</form>
	</li>
</ul>

<h4>Quid de la publicit� ?</h4>
<p>
	Personne n'aime la publicit�. Et nous non plus, les habitu�s du forum le savent.<br />
	La publicit� est apparue avec le d�but des ennuis judiciaires; et avec la d�cision de la cour d'appel, elle ne va pas dispara�tre malheureusement ...
	Les sommes qu'elle g�n�re sont trop faibles, mais que pouvons-nous faire ?<br />
	Si cette publicit� vous incommode trop, il reste possible si vous utilisez le navigateur firefox d'utiliser le module <a href="http://addons.mozilla.org/fr/firefox/addon/1865">ADblockplus pour firefox</a> qui vous permettra de naviguer tranquille
</p>

<p><strong>Merci de votre soutien</strong></p>
</div>
<?php
include("../include/footer.php");
?>
