<?php
//**********************************************************************************************
//* Nom du module:         | point_ajout_commentaire.php                                       *
//* Date :                 |                                                                   *
//* Cr�ateur :             | sly                                                               *
//* R�le du module :       | comme son nom l'indique, ajouter un commentaire ratach� � un point*
//*                        | s�par� d�sormais de la fiche point pour all�ger                   *
//*                        | Contient le formulaire et l'action du formulaire                  *
//*                        |                                                                   *
//*------------------------|-------------------------------------------------------------------*
//* Modifications(date Nom)| Elements modifi�s, ajout�s ou supprim�s                           *
//*------------------------|-------------------------------------------------------------------*
//* 06/10/07               | C'est peut-�tre parano mais je test plein d'erreur possible       *
//* 13/03/08   jmb 		virage de WMS.
//**********************************************************************************************

require("./include/fonctions.php");
require("./include/fonctions_autoconnexion.php");
require("./include/fonctions_points.php");

//include("./include/fct_wmsimage.php");
setlocale(LC_TIME, "fr_FR");

/** Traitement des erreurs g�n�riques **/
// ajout d'un commentaire sur rien ?
if (!isset($_GET['id_point']))
	$erreur_fatale="<p>Vous n'aurriez pas d� vous trouver l�, je ne trouve pas le point sur lequel vous voulez faire un commentaire</p>";
else
{
 $q_select_abri = "SELECT * FROM points,point_type,phpbb_topics 
			WHERE point_type.id_point_type=points.id_point_type 
			AND phpbb_topics.topic_id_point=points.id_point
			AND 
			id_point=".$_GET['id_point'];
 $r_select_abri = mysql_query($q_select_abri) or die("mauvaise requete");
 
// le point n'existe plus ?
if (mysql_num_rows($r_select_abri)!=1)
	$erreur_fatale="<p>Le point sur lequel vous faites un commentaire n'existe pas ou plus</p>";

$point=mysql_fetch_object($r_select_abri);
}
$info=avertissement_connexion();

if ($_POST['action']!="") // on vient de valider notre formulaire, faisons le n�cessaire
{
$reussi=FALSE;
/** V�rification des erreurs potentielles **/
$erreur="";
// peut �tre un robot ?
if ( ($_POST["lettre_verification"] != "f") AND !isset($_SESSION['id_utilisateur']) )
	$erreur="<h2>Mauvaise lettre !</h2><p>Merci de recopier la lettre indiqu�e. ceci afin de lutter contre les message 
			ind�sirables. Il y a eu ici beaucoup de messages laiss�s par des 'robots' faisant de la 
			publicit� pour des sites plus que douteux. Du coup, cette manoeuvre a pour but de leur 
			compliquer la t�che. Id�alement, seul un 'humain' saura comprendre ce qu'il faut faire. 
			Nous sommes d�sol� de cette perte d'ergonomie; Un des objectifs principal du site a 
			toujours �t� d'�tre simple et rapide d'utilisation.
			</p>";

// utilisateur dont l'adresse IP est bannie
if (bloquage_internaute($_POST['comment_auteur']))
	$erreur.="<p><h4>Banni !</h4>Une erreur est survenu lors de l'ajout de votre commentaire car vous �tes banni, vous pouvez en parler ici : <a href=\"/forum/viewtopic.php?t=671\">Sur le forum</a></p>";

// commentaire vide

if ( !is_uploaded_file($_FILES['comment_photo']['tmp_name']) AND $_POST['comment_texte']=="")
	$erreur.="<p><h4>Vide !</h4>Votre commentaire ne comporte ni photo ni texte, il n'est pas ajout�</p>";

if ($erreur=="")
{
/***************************************************************
Ici insertion d'un commentaire et/ou de la photo
***************************************************************/
 if (($comment_texte!="")||($comment_auteur!="")||($comment_photo!=""))
 {
   	set_magic_quotes_runtime(0);
   	if ($_POST['demande_correction']==TRUE)
		$demande_correction=1;
	else
		$demande_correction=0;
	/* On commence par cr�er le commentaire sans se soucier de l'existence d'une photo */
	$insert_comment ="
		INSERT INTO commentaires
		SET
			id_point = ".$_GET['id_point'].",
			date = NOW(),
			texte = '" . ucfirst(mysql_real_escape_string(stripslashes($_POST['comment_texte']))) . "',
			auteur = '" . mysql_real_escape_string(stripslashes($_POST['comment_auteur'])) . "',
			demande_correction=$demande_correction";

	if (isset($_SESSION['id_utilisateur']))
		$insert_comment.=",id_createur=".$_SESSION['id_utilisateur'];
	mysql_query($insert_comment) or die("insert_comment est mauvais: $insert_comment");
   	
	/* d�sormais le nom de la photo est tr�s simple c'est $id_commentaire-originale.jpeg */
	$destifile = $config['rep_photos_points'] . mysql_insert_id() . "-originale.jpeg";
	
	/* puis on redimmensionne pour afficher celle du site, mais garder celle d'origine sly 06/10/07 */
	$image_finale=$config['rep_photos_points'] . mysql_insert_id() . ".jpeg";
	
	/* si on doit placer une photo on la place o� il faut sous le bon nom*/
   	if (move_uploaded_file($_FILES['comment_photo']['tmp_name'] ,$destifile))
   	{
	// on test si on a bien re�u un jpeg
	$taille = getimagesize($destifile);
	if ($taille[2] == 2) 
	{
	copy($destifile,$image_finale);
   	$update_comment ="UPDATE commentaires set photo_existe=1 where id_commentaire=".mysql_insert_id();
	mysql_query($update_comment) or die("requete mauvaise, impossible de  : $update_comment");
	/****** si l'image est trop grosse on la redimensionne *****/
		if ( ($taille[0]>$config['largeur_max_photo'])
			||($taille[1]>$config['hauteur_max_photo']))
		{
			$info="<h4>La photo est grande (plus grande que "
				.$config['largeur_max_photo'] . "x"
				.$config['hauteur_max_photo']
				."), elle est redimensionn�e</h4>";
			redimensionnement_photo($image_finale);
		}
  	$info.="<h4>Photo ajout�e</h4>";
	}
	else
		$info.="<p>Le fichier que vous avez envoy� ne semble pas �tre une image jpeg, il a �t� ignor� et supprim�</p>";
   	} 
  $info.="<h4>Commentaire ajout�</h4>";
  $reussi=TRUE;
  
 }
}
}
if ($erreur_fatale=="")
{
	$titre_page="Ajout d'un commentaire sur $point->article_defini $point->nom_type : $point->nom";
	$info.="<h4><a href=\"".lien_point_lent($id_point) . "\">Retour � $point->article_demonstratif $point->nom_type : $point->nom</a></h4>";
}
else
	$titre_page="Ajout d'un commentaire sur ?";
include("./include/header.php");
print("<div class=\"contenu\">");
print("<h3>$titre_page</h3>\n");
print($erreur);
print($info);


// soit on a eu une erreur et on repr�sente le formulaire, soit on vient d'arriver
if ($reussi)
{
	print("<p>Vous pouvez ajouter un nouveau commentaire si vous le souhaitez</p>");
	$_POST['comment_texte']="";
}
{
?>
<p>
</p>
<div class="com">
<form id="comment" method="post" action="/point_ajout_commentaire.php?id_point=<?=$_GET['id_point']?>" enctype="multipart/form-data">
	<fieldset><legend style="font-size: 1.2em;">Rajouter une information ou une pr�cision</legend>

	<textarea name="comment_texte" cols="70" rows="6"><?=$_POST['comment_texte']?></textarea><?=$config['lien_syntaxe']?>

	<br />
<?php
if (isset($_POST['comment_auteur']))
	$auteur=$_POST['comment_auteur'];
else
	$auteur=$_SESSION['login_utilisateur']
?>
	<label>auteur:</label>
		<input type="text" value="<?=$auteur?>" name="comment_auteur" maxlength="120" size="60" />(facultatif)
	<br />
	<label>Mon commentaire comporte une demande de modification de l'en t�te de la fiche (un mod�rateur sera pr�venu):</label>
		<input type="checkbox" name="demande_correction"/>
	<br />

	<fieldset><legend>une photo ?</legend>
	<label>Fichier JPEG:</label>
		<input type="file" name="comment_photo" size="15" value=""/>(facultatif)
	</fieldset>

	<?php
	if (!isset($_SESSION['id_utilisateur']))
	{ // visiteur, faut afficher les codes anti-spam
	print("
	<fieldset>
		<legend>Protection anti-spam</legend>
		Merci de simplement �crire la lettre \"f\" dans la case<br />
		<input type='text' name='lettre_verification'/>
		Ceci afin d'�viter les messages ind�sirables automatiques (d�sol�)
	</fieldset>
	");
	}
	?>
	
	<input type="submit" name="action" value="Envoyer" />
	<input type="reset" value="Recommencer" />

	<fieldset>
	<legend>Rappels: <a href="<?=lien_mode_emploi('que_mettre')?>">voir ce que vous pouvez ou non mettre sur le site</a></legend>
		<ul>
			<li><strong>Cette information peut �tre modifi�e/supprim�e/d�plac�e par les mod�rateurs !</strong></li>
			<?php
			if ($point->equivalent_proprio!="")
				print("<li><em>le site n'a aucun rapport avec les propri�taires ou g�rants de $point->article_demonstratif $point->nom_type (inutile de leur laisser un message ici)</em></li>");
			?>
			<li><em>Cette <b>information</b> doit �tre utile et objective</em></li>
			<li><em>Pour une appr�ciation, direction <a href="<?php print($config['forum_refuge'].$point->topic_id); ?>">le forum</a></em></li>
		</ul>
	</fieldset>
	<fieldset>
		<legend>Droits sur ce que vous allez mettre</legend>
		<p>
			Vous ne devez en aucun cas ins�rer un texte ou une photo qui ne vous appartient pas.
		</p>
		<p>
			Une copie d'un autre site, le scan d'un journal ou livre <strong>ne peut pas</strong> trouver sa place sur ce site.
		</p>
		<?=$config['message_licence']?>
	</fieldset>
	</fieldset>
</form>
</div>
</div>
<?php
}
print($erreur_fatale);
include("./include/footer.php"); 
?> 
