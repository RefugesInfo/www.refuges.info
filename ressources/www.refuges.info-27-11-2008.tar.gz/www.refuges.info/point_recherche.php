<?php
//**********************************************************************************************
//* Nom du module:         | point_recherche.php                                               *
//* Date :                 |                                                                   *
//* Cr�ateur :             | sly                                                               *
//* R�le du module :       | les resultats de la recherche. Ce fichier recupere les criteres   *
//*                        | en POST de point_formulaire_recherche.php ( une suite            *
//*                        | de fiche refuges, mais sans tous les d�tails )                    *
//*                        |                                                                   *
//*------------------------|-------------------------------------------------------------------*
//* Modifications(date Nom)| Elements modifi�s, ajout�s ou supprim�s                           *
//*------------------------|-------------------------------------------------------------------*
//* 10/03/06 rff           | Ajout instr. de lib�ration query sql                              *
//*                        | lib�ration query sql                                              *
//* 21/03/06 rff           | la table 'massifs' devient 'polygones' dans la base 'refuges'     *
//*                        |                                                                   *
//* 04/10/07 sly           | La requ�te devient de plus en plus grosse et param�trique         *
//*                        | je cherche toujours une solution pour la rendre plus claire !     *
//* 23/02/08 jmb           | refait la d�co
//* 22/05/08 jmb remplacement des AND-OR par des IN pour une meilleure lisibilit�
//*			optimization SQL pour le total (tout ca grace au mysql recent !)
//*			correction du Bug de duplica qd on recherche avec un commentaire
/**********************************************************************************************/

require("./include/fonctions.php");
require("./include/fonctions_autoconnexion.php");
require("./include/fonctions_points.php");
require("./include/fonctions_massifs.php");
include("./include/header.php");
print("<div class='contenu'>");
$mysqlink=connexion_base();
// une fonction r�alise maintenant tout �a ! je vais donc migrer ces test dans la fonction.
// pour rappel, la fonction doit aussi servir � l'exportation
/*
// voici la variable des conditions qui va grandir au f�r � mesure que l'internaute a pr�cis� sa recherche
$conditions="";

  // condition sur les recherche par coordonn�es GPS

 if($_POST["gps_lat"] && $_POST["gps_long"] && $_POST["gps_autour"] ) {
    $conditions .= " AND points.gps_lat BETWEEN ".($_POST["gps_lat"] - $_POST["gps_autour"])." AND ".($_POST["gps_lat"] + $_POST["gps_autour"]) ;
    $conditions .= " AND points.gps_long BETWEEN ".($_POST["gps_long"] - $_POST["gps_autour"])." AND ".($_POST["gps_long"] + $_POST["gps_autour"]) ;
 }

 // on veut les points avec photo, donc on a besoin de la table commentaires
if($_POST["photo"])
{
	$conditions .= "		AND commentaires.photo_existe = 1 \n";
}
// si on veut chercher dans les commentaires, 
// ATTENTION requ�te un poil lourde, car il commence � y avoir plein de commentaires !
 if($_POST["comm"])
 {
    $comm = urldecode($_POST["comm"]) ;
    $conditions .= "		AND ( points.acces LIKE \"%$comm%\" OR points.remark LIKE \"%$comm%\" OR points.proprio LIKE \"%$comm%\""; 
	if($_POST["commenttoo"]) 
	{ // la case a cocher recherche dans les commentaires
	$conditions .= " OR commentaires.texte LIKE \"%$comm%\" OR commentaires.auteur LIKE \"%$comm%\"";
	// Si une recherche dans les commentaires doit �tre faite, on fait une liaison � la table, sinon rien sly 12/08/2008
	$table_commentaire=",commentaires";
	$condition_liaison_commentaire="AND commentaires.id_point = points.id_point";
	}
	else
	{
	$table_commentaire="";$condition_liaison_commentaire="";
	}
	
	$conditions .= " ) \n";

 }
*/
$conditions->avec_infos_massif=1;
$conditions->id_polygone=$_POST['id_massif'];
$conditions->altitude_maximum=$_POST['altitude_maximum'];
$conditions->altitude_minimum=$_POST['altitude_minimum'];
$conditions->places_maximum=$_POST['places_maximum'];
$conditions->places_minimum=$_POST['places_minimum'];
$conditions->type_point=$_POST['id_point_type'];
$conditions->nom=$_POST['nom'];
$conditions->limite=$config['max_points_recherche'];
$conditions->precision_gps=$_POST['precision_gps'];
$conditions->description=$_POST['description'];
$liste_points=liste_points($conditions);

if ($liste_points->nombre_point > 1) // un peu de joli fran�ais, avec un "s" ou pas
	$pluriel = "s";
else
	$pluriel = "";

if ($liste_points->nombre_point > $config['max_points_recherche'])
	$trop=", seuls les ".$config['max_points_recherche']." premiers sont affich�s";
else
	$trop="";

//afficher nb de points trouv�s
print("<h3>$liste_points->nombre_point point$pluriel trouv�$pluriel $trop</h3>\n");

// Parcoure tous les refuges de la recherche
while ( $point = mysql_fetch_object($liste_points->resultat) )
    print( presentation_infos_point_court($point) );

print ("</div>");
include("./include/footer.php"); 
?> 