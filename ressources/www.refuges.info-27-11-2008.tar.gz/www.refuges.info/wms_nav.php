<?php
// ce fichier ne fait pas grand chose, sont but est de maintenir la compatibilit� avec les liens existants de
// l'ancien navigateur sattelite au nouveau
// je renvois un code 301 indiquant qu'il faut mettre � jour le lien.
// en th�orie il faudrait le garder quelques ann�es avant que l'internet entier se mette � jour
// ( utiliser les stats pour le v�rifier )
// sly 2008-03-18
include("./include/fonctions.php");

// afin d'�viter cependant la multiplication de liens pointants vers la m�me chose
//je renvois vers le bon truc par un des artifice du protocol http 
$array=explode('/',$_SERVER['PATH_INFO']);
if (isset($array[2]))
	$lien=lien_polygone_lent($array[2]);
else
	$lien="/nav";
header("HTTP/1.1 301 Moved Permanently");
header("Location: $lien");

?>
