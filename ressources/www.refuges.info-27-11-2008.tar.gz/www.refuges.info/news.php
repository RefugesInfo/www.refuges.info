<?php
//**********************************************************************************************
//* Nom du module:         | news.php                                                         *
//* Date :                 |                   12/2007                                                *
//* Cr�ateur :             |                               jmb                                    *
//* R�le du module :       | Ecran de nouvelles                                       *
//*                        |                                                                   *
//*                        | Acc�s par "http://www.refuges.info/ puis menu                         *
//*                        |                                                                   *
//*------------------------|-------------------------------------------------------------------*
//* Modifications(date Nom)| Elements modifi�s, ajout�s ou supprim�s                           *
//*------------------------|-------------------------------------------------------------------*
//* 22/04/08		jmb	la fct affiche news va dans fonctions.php
//**********************************************************************************************

require("./include/fonctions.php");
require("./include/fonctions_points.php");
require("./include/fonctions_nouvelles.php");
require("./include/fonctions_massifs.php");
require_once("./include/fonctions_autoconnexion.php");
$titre_page="Derni�res nouvelles du site et informations ajout�es sur les refuges";
require_once("./include/header.php");
// Petits stats de d�but sur l'int�gralit� de la base
// donc je liste bien les point_type 7,8,9 et 10 qui sont des h�bergements
// les autres sont des sommets, des cols, des villes o� autre, je pr�pare une page pour eux... un jour sly 22/09/06
$query_nombre_refuge="SELECT count(*) as somme 
			FROM points where 
			id_point_type IN (".$config['tout_type_refuge'].")
			AND points.modele != 1";

$nbrefuges=mysql_result($result=mysql_query($query_nombre_refuge),0);
mysql_free_result($result);

$query_nombre_photos="SELECT count(*) FROM commentaires WHERE photo_existe=1";
$nbphotos=mysql_result($result=mysql_query($query_nombre_photos),0);
mysql_free_result($result);

$query_nombre_comm="SELECT count(*) FROM commentaires";
$nbcomm=mysql_result($result=mysql_query($query_nombre_comm),0);
mysql_free_result($result);

print("<div class=\"contenu\">");
echo "<h3>$nbrefuges refuges, $nbcomm commentaires et $nbphotos photos! </h3>";
?>

<!-- BLOC NEWS -->
    <h4>Evolution du site</h4>
    <ul>
        <?php affiche_news(3+$general,"general"); ?>
    </ul>
    <a href="/news.php?general=10">(Voir les plus anciennes)</a>

    <h4>Les nouvelles</h4>
    <ul>
        <?php 
	if ($_GET['quoi']=="")
		$quoi="commentaires,points,forums";
	affiche_news(15+$commentaires,$quoi);
	?>
    </ul>
    <a href="/news.php?commentaires=50&amp;<?="quoi=".$_GET['quoi']?>">(Voir les plus anciennes)</a>
    &nbsp;<a href="/news.php?quoi=points">Points</a>
    &nbsp;<a href="/news.php?quoi=refuges">Refuges</a>
    &nbsp;<a href="/news.php?quoi=commentaires">Commentaires</a>
    &nbsp;<a href="/news.php?quoi=forums">Forum</a>
    &nbsp;<a href="/news.php?quoi=commentaires,points">Tout sauf forum</a>
    &nbsp;<a href="/news.php">Tout</a>
<!-- FIN BLOC NEWS -->

	<h4>Flux <abbr title='Really Simple Syndication'>RSS</abbr></h4>
		<p>
			La technologie <abbr title='Really Simple Syndication'>RSS</abbr> permet de recevoir directement sur son ordinateur, les derni�res nouvelles du site, sans devoir se connecter � <em>www.refuges.info</em>.
			Pour en b�n�ficier, il est n�c�ssaire de t�l�charger un logiciel sp�cifique. A noter que le navigateur <dfn title='lien sponsoris� en bas de page'>FireFox</dfn> int�gre un support RSS basique d'origine, via les <q>Marque-pages dynamiques</q>.
			Une fois pr�t, vous pouvez vous rendre sur la <a href='/rss/choixrss.php'>page d�di�e RSS</a> et s�l�ctionner vos options.
		</p>
</div>	
<?php
require_once("./include/footer.php");
?>