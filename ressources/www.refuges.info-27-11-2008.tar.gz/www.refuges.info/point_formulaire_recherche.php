<?php
//**********************************************************************************************
//* Nom du module:         | point_recherche_formulaire.php                                    *
//* Date :                 |                                                                   *
//* Cr�ateur :             |                                                                   *
//* R�le du module :       | Formulaire de recherche                                           *
//*                        |                                                                   *
//*------------------------|-------------------------------------------------------------------*
//* Modifications(date Nom)| Elements modifi�s, ajout�s ou supprim�s                           *
//*------------------------|-------------------------------------------------------------------*
//* 10/03/06 rff           |*Ajout instr. de lib�ration query sql                              *
//* 21/03/06 rff           |*Insertion infos.de session pour mod�ration                        *
//*                        |*la table 'massifs' devient 'polygones' dans la base 'refuges'     *
//*                        |*balises <table> d�plac�es depuis header.php & depuis footer.php   *
//*                        |                                                                   *
//* 23/11/07 jmb           | remplacement H3 par H4, H3 est pour le titre de page (ok ce devrait plutot etre H1)
//* 23/02/08 jmb           | vire la derniere visite, plue en base                             *
//* 23/02/08 jmb           | refait la d�co, rajoute la recherche sponsorisee google           *
//* 22/04/08 jmb           | virage de la saloperie de pub google                              *
//**********************************************************************************************


$titre_page="Recherche de refuges/abris/gites dans les alpes";
require("./include/fonctions.php");
require("./include/fonctions_autoconnexion.php");

include("./include/header.php");

$mysqlink=connexion_base();

echo "
<div class=\"contenu\">
	<h3>$titre_page</h3>\n";
?>
<h4>Rechercher sur le site</h4>
  <p>C'est une recherche basique, tous les champs sont facultatifs<br />Lancer sans rien remplir pour avoir TOUS les points que le site connait</p>
    <form method="post" action="./point_recherche.php">
	<fieldset><legend>Options de recherche</legend>
    <table>
    <tr>
        <td>
            Nom: 
        </td>
        <td>
            <input type="text" name="nom" />&nbsp;ex "jasse" ou "la pra"
        </td>
    </tr>
    <tr>
        <td>
            Massif: 
        </td>
        <td>
            <select name="id_massif">
            <option value="">(tous)</option>
<?php
            //remplissage de la combobox 'massifs'  (on laisse le massif 'nul part' qui contient des points hors massifs
            $q_select_massif = "SELECT *
                 FROM polygones
                 WHERE polygones.id_polygone_type = ".$config['id_massif']."
                 ORDER BY nom_polygone";

            $r_select_massif = mysql_query($q_select_massif) or die("mauvaise requete");
            while ($massif = mysql_fetch_object($r_select_massif)) 
                echo "\n\t\t\t<option value=\"$massif->id_polygone\">$massif->nom_polygone</option>";

            // rff 10/03/06 : Maintenant, nous lib�rons le r�sultat et continuons notre script
            mysql_free_result($r_select_massif);
?>
            </select>
        </td>
    </tr>
    <tr>
        <td>
            Points � rechercher
        </td>
        <td>
            <select name="id_point_type">
            <option value="">(tous)</option>
            <option value="<?=$config['tout_type_refuge']?>" selected="selected">Tout type de refuge</option>
<?php
            $q_select_massif = "SELECT 
	    					id_point_type,nom_type 
						FROM point_type 
						ORDER BY importance desc";
            $r_select_massif = mysql_query($q_select_massif) or die("mauvaise requete");
            while ($type = mysql_fetch_object($r_select_massif)) 
            {
                echo "\n\t\t\t<option value=\"$type->id_point_type\">$type->nom_type</option>";
            }

            // rff 10/03/06 : Maintenant, nous lib�rons le r�sultat et continuons notre script
            mysql_free_result($r_select_massif);
?>
            </select>
        </td>
    </tr>
    <tr>
        <td>
            Nombre de places compris entre :
        </td>
        <td>
            <input type="text" name="places_minimum" maxlength="3" size="3" />
            et
            <input type="text" name="places_maximum" maxlength="3" size="3" />
        </td>
    </tr>
    <tr>
        <td>
            Altitude entre :
        </td>
        <td>
            <input type="text" name="altitude_minimum" maxlength="4" size="4" />
            m et 
            <input type="text" name="altitude_maximum" maxlength="4" size="4" />m
        </td>
    </tr>
    <tr>
        <td>
            Pr�cision des coordonn��s GPS :
        </td>
        <td>
            <select name="precision_gps">
            <option value="">(Peu importe)</option>
            <option value="1,2">Prises sur une carte ou le terrain</option>
<?php
            $q_select_precision = "SELECT *
					FROM `type_precision_gps`
					ORDER BY id_type_precision_gps";
            $r_select_precision = mysql_query($q_select_precision) or die("mauvaise requete");
            while ($type_precision = mysql_fetch_object($r_select_precision)) 
            {
                echo "\n\t\t\t<option value=\"$type_precision->id_type_precision_gps\">$type_precision->nom_precision_gps</option>";
            }
?>
            </select>
        </td>
    </tr>
    <tr>
        <td>
            Coordonn�es GPS :
        </td>
        <td>
            <label>Lattitude:<input type="text" name="gps_lat" maxlength="10" size="8" /></label>
            <label>Longitude:<input type="text" name="gps_long" maxlength="10" size="8" /></label>
            et
            <label><input type="text" name="gps_autour" maxlength="6" size="4" value="0.01" />degr�s autour</label>
        </td>
    </tr>
    <tr>
        <td>
            Description: 
        </td>
        <td>
            <input type="text" name="description" />
            &nbsp; ex "poele" ou "source" ou "lacs"
        </td>
    </tr>
    <tr><td></td>
        <td>
            <input type="checkbox" name="commenttoo" value="sertarien" checked="checked" /><i>Rechercher �galement dans les commentaires</i>
        </td>
    </tr>
    <tr>
        <td>
            Uniquement les refuges avec photo:
        </td>
        <td>
            <input type="checkbox" name="photo" value="foto" />
        </td>
    </tr>
    <tr>
        <td colspan="2">
            <input type="submit" value="chercher!" />
        </td>
    </tr>
    </table>
	</fieldset>
</form> 

<h4>Rechercher dans les Pyr�n�es ?</h4>
<p>
	Consulter l'<em>excellent</em> site 
	<a href="http://www.pyrenees-refuges.com">www.pyrenees-refuges.com</a>
</p>

</div>

<?php
include("./include/footer.php");
?>
