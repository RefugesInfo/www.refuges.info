<?php
//**********************************************************************************************
//* Nom du module:         | point.php                                                         *
//* Date :                 |                                                                   *
//* Cr�ateur :             | sly???                                                            *
//* R�le du module :       | Fiche du point qui s'occupe de pr�senter le point, sommet,        *
//*                        | village et tout autre "type" possible de la base avec photos,     *
//*                        | nom, infos, commentaires, etc...                                  *
//*                        |                                                                   *
//*------------------------|-------------------------------------------------------------------*
//* Modifications(date Nom)| Elements modifi�s, ajout�s ou supprim�s                           *
//*------------------------|-------------------------------------------------------------------*
//* 21/03/06 rff           |*la table 'massifs' devient 'polygones' dans la base 'refuges'     *
//*                        |*Insertion infos de session : utile pour gestion du cache & menu   *
//*                        | gestion. Ajout layer 'polygones'                                  *
//*                        |*Ajout instr. de lib�ration query sql                              *
//*                        | lib�ration query sql                                              *
//*                        |                                                                   *
//*                        |                                                                   *
// XX/03/08  jmb	| gros travaux en cours. suppr nl2br() et plein de nettoyage pour du HTML propre
// 21/04/08 jmb 	variable $ici r�par�e (affichait "Forum d�di� � " sans rien derrirer
//* 03/05/08 jmb    mise en place pub rotative (et fonctions_pubs.php)
// 03/07/08 jmb		remplacement P par BLOCKQUOTE dans le dernier mess forum
//**********************************************************************************************


require("./include/fonctions.php");
require("./include/fonctions_massifs.php");
require("./include/fonctions_points.php");
require("./include/fonctions_autoconnexion.php");
include("./include/fonctions_gmaps.php");
include("./include/fonctions_pubs.php");

$mysqlink=connexion_base();

/****************************************
  on peut acc�der au point par http://www.refuges.info/point/183/ce/quon/veut/ ( pour le n�183 )
 sly
 le top c'est que �a conserve aussi les anciens liens
****************************************/
$array=explode('/',$_SERVER['PATH_INFO']);
/******************************************
 on verifie si l'url ressemble � http://www.refuges.info/point/183/...
 sinon on prend le ?id=
 ******************************************/
if (isset($array[1]))
    $id_point=$array[1];

// Recupere les donnees du point concern�, centralis� dans une fonction maintenant sly 30/10/2008
$objrqpoint = infos_point($id_point);
if ($objrqpoint==-1)
    {include("./include/header.php");print("<h2>Le point que vous cherchez ne semble pas exister</h2>");include("./include/footer.php");exit();}

// le but c'est de cr�er le titre de la page
$ici = $objrqpoint->nom;
$titre_page="$objrqpoint->nom $objrqpoint->altitude m ($objrqpoint->nom_type)";
$description="fiche d'information sur : $objrqpoint->nom, $objrqpoint->nom_type, altitude $objrqpoint->altitude avec commentaires et photos";

//------------------------------------
//pr�paration de la page HTML renvoy�e
//------------------------------------


$if_javascript= "
	<!--  CHARGEMENT DES LIBS GOOG MAPS -->
	<!-- gros script google maps contenant toute l'API , avec notre clef d'enregistrement-->
	<script src='http://maps.google.com/maps?file=api&amp;v=2.x&amp;key=". $config["gmaps_key"] ."' type='text/javascript' charset='iso-8859-1'></script>

	<script type='text/javascript' charset='iso-8859-1'>
		// pr�-charge les IMAGES de points

		". GM_cree_icones_points() ."
	</script>

	<!-- les fonctions maison gmaps -->
	<script type='text/javascript' src='/include/gmaps.js' charset='iso-8859-1'></script>
";

$if_onloadscript=" onload=\"init_icones(); vignette(document.getElementById('mapvignette'),$objrqpoint->latitude, $objrqpoint->longitude );\"
					onunload=\"GUnload();\"";

include("./include/header.php"); //inclut l'en-t�te, le corps de message (body)
// je pr�f�re mettre le contenu dans un div afin de lui appliquer marges et autres
print("<div class=\"contenu\">");

//-------------------------------
//affichage de la fiche du point 
//-------------------------------
print(presentation_infos_general_point($objrqpoint));

//------ PUB --------
// 03/05/08 jmb, la V2 fait du rotatif (1/5 oxado, 4/5 tradedoubler divers)
// a voir, une semaine ou 2. voir le fonctions_pubs.php pour plus d'infos
// tout vu. Tradedoubler, 23 c en 1 mois via kelkoo (4ou5 leads), dont je pense 2 de moi.
// Clickintext depuis qq mois, mieux, 7-8 clics par jours
// 11/07/08: jmb: random clickintext entre le contextual ad et le XML
if ( ! isset($_SESSION['id_utilisateur']))
	echo bandeau_publicitaire(); 



/**********************************************************************
 on affiche les commentaires+photos en plus
***********************************************************************/

/*******************************************************
 Vu des photos en mignature avec lien
 <..>
TRANSFERE DANS presentation general point dans fonctions.php (jmb avril 07)
pour des histoire de styles principalement
*******************************************************/

/* je rajoute les first et last topic, apparement, si egaux, alors le topicest vide*/
$sql_query_last_text_forum="SELECT  *
    FROM phpbb_posts_text, phpbb_topics, phpbb_posts
    WHERE phpbb_posts_text.post_id = phpbb_topics.topic_last_post_id 
    AND phpbb_topics.topic_id_point = $id_point
	AND phpbb_posts.post_id = phpbb_posts_text.post_id";
$rq_message_forum_res=mysql_query($sql_query_last_text_forum);
$message_forum=mysql_fetch_object($rq_message_forum_res);

$lienforum=$config['forum_refuge'].$message_forum->topic_id;

/* je rajoute des div pour faire de la mise en page (yip) */
echo "\n
	<h5>Forum d�di� � $ici</h5>
	";

echo "<p><em>Pour les discussions, merci d'utiliser <a href='$lienforum'>le forum</a> afin de laisser ces pages pour apporter de l'information.\n</em></p>";

/* si first=last, alors 1 seul post donc topic vide: yip*/
if ( $message_forum->topic_first_post_id != $message_forum->topic_last_post_id ) 
{
	echo "
		Dernier message,
		le <em>" . strftime('%A %e %B %Y � %H:%M',$message_forum->post_time). "</em>: "
		."<blockquote cite='$lienforum'><div>".bbcode2html($message_forum->post_text)."</div></blockquote>";
} else
	echo "<p>Le forum est vide, n'h�sitez pas � y laisser le premier message! </p>\n";

// fin du div dernier message forum

/******************************************************
 COMMENTAIRES ET PHOTOS
 Zone commentaires et �ventuellement photos
 ****************************************/
// maintenant, pour chaque commentaire, le truc complet, comme dans l'ancienne methode
$sql_select_comment = "SELECT *,UNIX_TIMESTAMP(date) as date_affichage FROM commentaires WHERE id_point=$id_point ORDER BY date DESC";
$rq_select_comment = mysql_query($sql_select_comment) or die("mauvaise requete");

echo "\n\n	<h5>Commentaires</h5>\n";

echo " <ul class='comment2'> \n";

// PARCOURS DES COMMENTAIRES DANS CETTE BOUCLE while()
while ($commentaires=mysql_fetch_object($rq_select_comment))
{
    // ici l'id pour l'anchor des petites vignettes du haut
    echo "\n<li>
	
	<a id='C$commentaires->id_commentaire'></a>
	<div class='fauxfieldset'>";
    // juste apr�s la date du commentaire avec heure et en fran�ais, grace a LOCALE, avec la 1ere lettre en majuscule
    echo "\n <p class='fauxfieldset-legend'>" . ucfirst(strftime("%A %e %B %Y � %H:%M",$commentaires->date_affichage));
    if($commentaires->auteur) 
    {
		echo " par ";
		if ($commentaires->id_createur!=0) {
			$lien=$config['fiche_utilisateur'].$commentaires->id_createur;
			$lien_debut="<a href=\"".$lien."\">";
			$lien_fin="</a>";
		} else {
			$lien_fin="";$lien_debut="";
		}
    	echo $lien_debut . bbcode2html($commentaires->auteur) . $lien_fin ;
    }
	echo "</p>\n";
    	// ici le lien pour mod�rer ce commentaire
	if (isset($_SESSION['id_utilisateur']) AND ( ($_SESSION['niveau_moderation']>=1) OR ($_SESSION['id_utilisateur']==$commentaires->id_createur)))
	{
		$lien_commentaire="/gestion/?page=moderation&amp;id_point_retour=$commentaires->id_point&amp;id_commentaire=$commentaires->id_commentaire\"";
		$texte_lien_commentaire="Modifier";
	}
	else
	{
		// l'internaute, en cliquant ici va nous donner ce qu'il pense de ce commentaire
		$lien_commentaire="/gestion/avis-internaute-commentaire.php?id_commentaire=$commentaires->id_commentaire\"";
		$texte_lien_commentaire="Que pensez vous de ce commentaire ?";
	}

	echo "<a class='fauxfieldset-legend' style='display: block; float: right;' href=\"$lien_commentaire\">$texte_lien_commentaire</a>";
		
	echo "\n  <hr class='spacer' />"; // pour ne pas avoir la foto qui depasse

	// Si, selon la base une photo existe, on va l'afficher
    if ($commentaires->photo_existe) 
    {
		// si la photo originale est pr�sente ( apr�s avril 2007 en gros ) on pr�pare un lien vers la photo "en grand"
		// sinon tant pis on fait un lien vers elle m�me 
		// ( question d'�rgonomie, l'internaute ne pourrait pas comprendre que des fois �a clique des fois non )
		if (is_file($config['rep_photos_points'].$commentaires->id_commentaire."-originale.jpeg"))
			$fin_du_lien="-originale.jpeg";
		else
			$fin_du_lien=".jpeg";

        echo "\n 
			<a href='".$config['rep_web_photos_points'].$commentaires->id_commentaire.$fin_du_lien."'>
				<img
					src='".$config['rep_web_photos_points'].$commentaires->id_commentaire.".jpeg'
					style='float: left; margin: 2px;'
					alt='chargement de la photo'
				/>
			</a>";
	} // fin du if foto existe
	
	// TEXTE DU COMMENTAIRE
	if ( $commentaires->texte )
		echo "\n  <blockquote><p>" . bbcode2html($commentaires->texte) ."</p></blockquote>";
	echo "\n  <hr class='spacer' />"; // pour ne pas avoir la foto qui depasse
	echo "\n  </div>"; // fin du bloc foto-comment
	echo "\n</li>"; // fin du DIV "comment" !

}//end while

echo "\n </ul>\n";

// rff 21/03/06 : Maintenant, nous lib�rons le r�sultat et continuons notre script
mysql_free_result($rq_select_comment);

// avertissement / r�sponsabilit�
print("
	<p>
		<a class='lien_ajout_commentaire' href='/point_ajout_commentaire.php?id_point=$objrqpoint->id_point'>
			Ajouter un commentaire, une photo, une demande de correction
		</a>
	</p>
");
?>

	<p>
		<strong>
			Avertissement : Les informations fournies sont indicatives. 
			Elles ne sauraient engager la responsabilit� des gestionnaires ou des r�dacteurs dans l'hypoth�se o� les utilisateurs de ces informations 
			n'observeraient pas les r�gles de prudence que la montagne impose. 
			Soyez responsables
		</strong>
	</p>

	<em>Page sous licence :
	<a rel="license" href="http://creativecommons.org/licenses/by-sa/2.0/fr/">
		<img alt="Creative Commons License" src="http://i.creativecommons.org/l/by-sa/2.0/fr/88x31.png"/>
	</a>
	</em>

<!-- Fin de la DIV de contenu qui contient toute la page sauf le headerfooter (ce devrait plutot etre dans le footer.php ?)-->
</div>

<?php
include("./include/footer.php"); 
?> 
