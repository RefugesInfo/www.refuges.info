<?php
//-----------------------------------------------
// Modif des commentaires
//----------------------------------------

//Pas d'acc�s direct � la page !
if (AUTH!=1)
	die("<h3>vous tentez de pirater ?</h3>");

// si nous n'avons pas un mod�rateur, nous v�rifions si il s'agit bien de son commentaire
if ($_SESSION['niveau_moderation']<1)
{
$query_verif_utilisateur="SELECT * FROM commentaires 
				WHERE id_commentaire=".$_GET['id_commentaire']." 
				AND id_createur=".$_SESSION['id_utilisateur'];
$res=mysql_query($query_verif_utilisateur);
if (mysql_num_rows($res)==1)
	$autorisation=TRUE;
else
	$autorisation=FALSE;
}
else
	$autorisation=TRUE;


if ( !$autorisation )
	die ("<h3>Impossible d'acc�der � cette page vous n'y �tes pas autoris�</h3>");
else
	echo "<h3>Mod�ration des commentaires</h3>\n";

//if (test_autorisation_acces("moderateur",$_SESSION['is_admin']))
//{

$query_comment="SELECT *, UNIX_TIMESTAMP(date) AS date_ts
		FROM commentaires
		WHERE id_commentaire=".$_GET['id_commentaire'];
$res_comment=mysql_query($query_comment);
$commentaire=mysql_fetch_object($res_comment);

// on vient ici par 3 moyens:
//	  -type=transfert
//	  -type=modif
//	  -type=suppression
// 	  -on vient d'arriver: ya pas de type. default. on affiche le formulaire.

switch($_GET['type'])
{
  case "transfert_forum":
	// dabord on modifie pour prendre en compte les modifs
  	modification_commentaire($commentaire->id_commentaire,
				$_GET["comment"],
				$_GET["auteur"],
				$_GET["date"]);
	// puis on tranfert
	transfert_commentaire($commentaire->id_commentaire);
	suppression_commentaire($commentaire->id_commentaire);
	print("<h4>Le commentaire a �t� d�plac�</h4>");
  break;

  case "modification":
  	modification_commentaire($commentaire->id_commentaire,
				$_GET["comment"],
				$_GET["auteur"],
				$_GET["date"]);
	print("<h4>Le commentaire a �t� modifi�</h4>");
  break;

  case "suppression":
	suppression_commentaire($commentaire->id_commentaire);
	// appelle la fct qui va enregistrer tout
	//log_moderation($commentaire,
	//		$_GET["type"],
	//		$_GET["id_point_retour"],
	//		$_SESSION["id_moderateur"]);
	print("<h4>Le commentaire a �t� supprim�, une copie est conserv�e</h4>");
  // break; // en cas de suppression, on enchaine sur la foto

  case "transfert_autre_point":
	if ($_GET['id_autre_point']!="")
	{
		$point=infos_point($_GET['id_autre_point']);
		if ($point!=-1)
		{
			mysql_query("UPDATE commentaires set id_point=".$_GET['id_autre_point']." WHERE id_commentaire=$commentaire->id_commentaire");
			print("<h4>ce commentaire a �t� d�plac� sur la fiche de <a href='".lien_point($point->nom,$point->massif->nom_polygone,$point->id_point,$point->nom_type)."'>$point->nom</a></h4>");
		}
		else
			print("<h4>Vous avez demander un transfert vers un autre point qui n'existe pas !</h4>");
	}
	else
		print("<h4>Vous avez demander un transfert vers un autre point, mais sans remplir la case !</h4>");

	break;
  case "suppression_photo":
	// On vient ici par 2 cas:
	//   - on a cliqu� sur supression photo
	//   - on a cliqu� sur suppression tout court, et comme il est juste au dessus, il enchaine ici
	// finalement ANNULATION
	//if ($commentaire->photo_existe==1)
	//{
		//// copie dans le rep de sauvegarde
		//copy($config['rep_photos_points'].$commentaire->id_commentaire.".jpeg","./sauvegardes-photos/".$commentaire->id_commentaire.".jpeg");
		//// trace la chose
		//log_moderation("suppression de la photo associ�e au commentaire $commentaire->id_commentaire
				//(d�placement dans /sauvegardes-photos/)");
		//print("<h2>La photo a �t� supprim�e, une copie est conserv�e</h2>");
	//}
  break;

  default:
	// affichage du formulaire de modif
	echo "
	<p>
	Vous entrez dans la zone de mod�ration qui va vous permettre de modifier un commentaire ou de le d�placer vers le forum dans la section correspondant au point
	</p>
	<h4>le commentaire est :</h4>
	<blockquote>";
	if ($commentaire->photo_existe==1)
		echo "<img
				src='".$config['rep_web_photos_points'].$commentaire->id_commentaire.".jpeg'
				alt='photo li�e au commentaire'
				width='200px' /><br />\n";
	echo nl2br(stripslashes($commentaire->texte))."</blockquote>\n";
	// formulaire qui contient uniquement le comment
	echo "
	<form method='GET'>
		<input type='hidden' name='page' value='moderation' /> <!-- pour qu'il re appelle la page de moderation -->
		<label>
			auteur:
			<input type='text' name='auteur' value='$commentaire->auteur' />
		</label>
		<label>
			date:
			<input type='text' name='date' value='".date('d/m/Y H:i',$commentaire->date_ts)."' size='16'/>
		</label>
		<textarea name='comment' rows='10' cols='100'>".stripslashes($commentaire->texte)."</textarea>
		<br />

		<!-- tout cela n'est ptet pas necessaire -->
		<input type='hidden' name='id_commentaire' value='".$_GET['id_commentaire']."' />
		<input type='hidden' name='id_point_retour' value='".$_GET['id_point_retour']."' />

		<!-- 4 actions possible -->
		<input name='type' value='modification' type='submit' />
		<input name='type' value='transfert_forum' type='submit' />
		<input name='type' value='suppression' type='submit' />\n<br />
		<input name='type' value='transfert_autre_point' type='submit' />\n
		<input type='text' name='id_autre_point' value='' size='16'/>";
	//if ($commentaire->photo_existe==1)
		//echo "<input name='type' value='suppression_photo' type='submit' />\n";
	echo "
	</form>
	<p>
		<strong>Merci de ne modifier le texte qu'en cas de n�c�ssit� ! l'auteur ne le souhaiterait peut-�tre pas!</strong><br />
		'suppression' entraine la suppression de la photo.
		'transfert_forum' entra�ne le d�placement de la photo vers le forum ET prends en compte les modifications
	</p>
	<!--<a href=\"./?page=moderation&amp;type=suppression&amp;vider=1&amp;id_commentaire=".$_GET['id_commentaire']."&amp;id_point_retour=".$_GET['id_point_retour']."\">supprimer le commentaire</a>-->";

} // fin du switch

print("<a href=\"".lien_point_lent($_GET['id_point_retour'])."\">Retour au point</a>");

?>

	<!--<a href="./?page=moderation&amp;type=transfert&amp;id_commentaire=<?=$_GET['id_commentaire']?>&amp;id_point_retour=<?=$_GET['id_point_retour']?>">Transferer vers le forum concern� (directement)</a>-->
