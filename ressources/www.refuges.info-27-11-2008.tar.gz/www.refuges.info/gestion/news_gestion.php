<?php
//**********************************************************************************************
//* Nom du module:         | news_gestion.php                                                  *
//* Date :                 |                                                                   *
//* Cr�ateur :             |                                                                   *
//* R�le du module :       | Ecran de gestion des news g�n�rales.                              *
//*                        | Droits: admin & supermod�rateur.                                  *
//*                        | Acc�s par : "./gestion/?page=news_gestion"                        *
//*                        |                                                                   *
//*------------------------|-------------------------------------------------------------------*
//* Modifications(date Nom)| Elements modifi�s, ajout�s ou supprim�s                           *
//*------------------------|-------------------------------------------------------------------*
//* 21/03/06 rff           | correction bugs bloquants emp�chant le bon fonctionnement:        *
//*                        | -table comment incorrecte, param�tres GET non pris en compte,     *
//*                        | -renvoi page d'index gestion non fait (prise en compte AUTH=1)    *
//*                        |                                                                   *
//**********************************************************************************************


//v�rification des autorisations
if ( (AUTH ==1) AND ($_SESSION['niveau_moderation']>=1) )
{
   $mysqlink=connexion_base();

   //rff 21/03/06 : lecture du param�tre
   if (isset($_GET["page"]))
      $page = $_GET["page"] ;

   //rff 21/03/06 : lecture du param�tre
   if (isset($_GET["ajout"]))
      $ajout = $_GET["ajout"] ;

   //rff 21/03/06 : lecture du param�tre
   if (isset($_GET["faire_ajout"]))
      $faire_ajout = $_GET["faire_ajout"] ;

   //rff 21/03/06 : lecture du param�tre
   if (isset($_GET["texte"]))
      $texte = $_GET["texte"] ;
   else $texte = "";

   if ($delete==1)
   {
     echo "La news en page de garde est enlev�e<br>";
     $query_delete="DELETE FROM comment WHERE id=$id_news";
     mysql_query($query_delete);
   }

   if ($ajout==1)
   {
      echo "Ajout d'une news en page de garde :<br>";
//    echo "<form method=\"post\" action=\"news_gestion.php\">";  rff 21/03/06 : renvoyer � la page gestion
// pour ravoir les droits AUTH=1
      echo "<form method=\"get\" action='/gestion/'>";  //rff 21/03/06 : changer post en get
      echo "texte :<input size=\"50\" type=\"text\" name=\"texte\"><br>";
      echo "<input type=\"submit\" name=\"faire_ajout\" value=\"ajouter\">";
      echo "<input type=\"hidden\" name=\"page\" value=\"$page\">";
   }

   if ($faire_ajout=="ajouter")
   {

     //rff 21/03/06 : table 'comment' �volu�e en 'commentaires'
     $sql_query_ajout="INSERT INTO commentaires(id_point,texte,date) VALUES (".$config['numero_commentaires_generaux'].",\"".$texte."\",NOW())";
     mysql_query($sql_query_ajout)or die("insert_commentaires est mauvais");
     echo "News g�n�rale : \"".texte."\" ajout�e<br>";
   }
}
?>