<?php
//**********************************************************************************************
//* Nom du module:         | index.php                                                         *
//* Date :                 |                                                                   *
//* Cr�ateur :             |                                                                   *
//* R�le du module :       | Zone de contr�le d'acc�s des mod�rateurs                          *
//*                        |                                                                   *
//*                        | Acc�s par "http://www.refuges-info/gestion/                       *
//*                        |                                                                   *
//*------------------------|-------------------------------------------------------------------*
//* Modifications(date Nom)| Elements modifi�s, ajout�s ou supprim�s                           *
//*------------------------|-------------------------------------------------------------------*
//* 21/03/06 rff           |-r�attribution droits (v�rif inchang�(mod�rateur), caches+news+    *
//*                        | calcul appartenance massif>supermod., gest. mod�rateurs>admin     *
//*                        |-intro gestion des caches session                                  *
//*                        |-Correction ano.d�connexion ne permettant pas la reconnexion.      *
//*                        |                                                                   *
//* 14/09/2007 sly         | Profond changement dans la mani�re d'authentifier                 *
//*                        | fini le double login, la connexion se fait sur le forum et plus   *
//*                        | ici. Il n'y a plus de table mod�rateur, l'int�gration est faite   *
//*                        | dans la table des utilisateurs du forum ( voir :                  *
//*                        | ../include/fonctions_autoconnexion.php )                          *
//* 18/11/07 jmb     | ajout de "cree_icones_google" (icones en 32x32)     *
//* 20/11/07 jmb     | retrait de "cree_icones_google" (icones en 32x32)  , c'est de la daube.   *
//* 03/03/2008 jmb | re retrait, rajout de H4 et indent
// 31/05/08 jmb   | ajout de gestion pub
//**********************************************************************************************

//rff 21/03/06  : changements

require("../include/fonctions.php");
require("../include/fonctions_points.php");

require("../include/fonctions_autoconnexion.php");
include("./fonctions_gestion.php");

connexion_base();
$titre_page="Zone de gestion";
include("../include/header.php");
print("<div class=\"contenu\">");
// fonctions_autoconnexion.php ayant d�j� fait le boulot il n'y a plus qu'a v�rifier
// qu'on est avec quelqu'un du forum et ayant un niveau mod�rateur au minimum
// l'�volution est de permettre � tout utilisateur de venir ici en pr�sentant les 
// choix selon ces droits

if (isset($_SESSION['id_utilisateur']) )
{
	if ($_GET['page']=="")
	{//pas de param�tre 'page',

	//affichage des menus de gestion
	//----------------------------
	print("<h3>Zone de gestion</h3>");

	// Pour tous les utilisateurs
	if ($_SESSION['niveau_moderation']>=0)
	{
		print("
		<h4>Pour tout le monde</h4>
		<ul>
			<li><a href='./?page=mes_contributions'>Trouver tous mes commentaires sur le site</a></li>
			<li><a href='./?page=moderateurs'>Conna�tre les moderateurs du site</a></li>
		</ul>"); // pas de risque la page est mutante
	}
  	// pour tout mod�rateur
	if ($_SESSION['niveau_moderation']>=1)
	{
		print("
		<h4>Mod�rateurs</h4>
		<ul>
			<li><a href='./?page=commentaires_attente_correction'>Voir les commentaires en attente d'une correction</a></li>
			<li><a href='./?page=modifier_modeles'>Modifier les mod�les de points</a> (le pr�-remplissage des champs lors d'un ajout de point)</li>
			<li><a href='./?page=news_gestion&amp;ajout=1'>Ajout d'une news g�n�ral</a> ( En haut de la page nouvelles )</li>
		</ul>");
	}
	//pour les programmeurs
	if ($_SESSION['niveau_moderation']>=2)
	{ //rff 21/03/06 : intro gestion cache session
		print("
		<h4>Programmeurs</h4>
		<ul>
			<li><a href='./?page=verif_massif'>V�rification de la coh�rence des massifs</a> (le chevauchement des massifs)</li>
			<li><a href='./?page=calcul_appartenance_polygone'>Recalcul de l'appartenance de tous les points de la base � un ou plusieurs polygones (centaine de secondes)</a></li>
		</ul>
		");
	}
	// pour les admins
	if ($_SESSION['niveau_moderation']>=3)
		print("
		<h4>Administrateurs</h4>
		<ul>
			<li><a href='./?page=moderateurs'>Gestion des moderateurs</a></li>
			<li><a href='./?page=gestion_pub'>Gestion de la pub de ClickInText</a></li>
		</ul>");

	// pour tout le monde	
	print("<p><a href='".$config['lien_forum']."login.php?logout=true'>Se d�connecter</a></p>");

}
else
{//param�tre page pass�:
	echo "
		<h3>
			<a href=\"./\">Retour</a>&nbsp;
			Zone de gestion
		</h3>
		";
	DEFINE('AUTH',1);
	switch($page)
	{
		case "calcul_appartenance_polygone" : include("calcul_appartenance_polygone.php");break;
		case "moderateurs" : include("moderateurs.php");break;
		case "news_gestion" : include("news_gestion.php");break;
		case "gestion_caches_point" : include("gestion_caches_point.php");break;
		case "verif_massif" : include("verif_massif.php");break;
		case "moderation" : include("moderation.php");break;
		case "modifier_modeles" : include("modifier_modeles.php");break;
		case "gestion_pub" : include("gestion_pub.php");break;
		case "commentaires_attente_correction" : include("commentaires_attente_correction.php");break;
		case "mes_contributions" : include("mes_contributions.php");break;
	}
}
}
else
{//pas connect� ou pas de droit
	if (!isset($_SESSION['id_utilisateur']))
		print("<h3>Zone de gestion</h3><h4>Erreur</h4><p>Vous n'�tes pas connu du syst�me veuillez vous connecter d'abord</p>");
	else
		print("<h3>Zone de gestion</h3><h4>Erreur</h4><p>Vous n'avez pas les droits requis pour atteindre cette zone</p>");
}

echo "\n </div><!-- fin du DIV contenu -->";
include("../include/footer.php");
?>
