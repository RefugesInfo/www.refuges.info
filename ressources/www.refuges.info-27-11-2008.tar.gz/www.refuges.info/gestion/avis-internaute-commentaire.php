<?php
//**********************************************************************************************
//* Nom du module:         | avis-internaute-commentaire.php                                   *
//* Date :                 |                                                                   *
//* Cr�ateur :             |                                                                   *
//* R�le du module :       | Permettre � n'importe qui d'indiquer qu'un commentaire � peu      *
//*                        | d'int�r�t, un mod�rateur sera al�rt�                              *
//*                        |                                                                   *
//*                        | Acc�s par "http://www.refuges-info/gestion/                       *
//*                        |                                                                   *
//*------------------------|-------------------------------------------------------------------*
//* Modifications(date Nom)| Elements modifi�s, ajout�s ou supprim�s                           *
//*------------------------|-------------------------------------------------------------------*
//* 04/10/08 sly           |-cr�ation                                                          *
//**********************************************************************************************

require("../include/fonctions.php");
require("../include/fonctions_points.php");
require("../include/fonctions_autoconnexion.php");
include("../include/header.php");

connexion_base();
print('<div class="contenu">');

$query_commentaire="SELECT * FROM commentaires WHERE id_commentaire=".$_GET['id_commentaire'];
$res=mysql_query($query_commentaire);
$commentaire=mysql_fetch_object($res);
$point=infos_point($commentaire->id_point);

/**************************** l'action  ******************************/
if ($_POST['valider']!="")
{
if ($_POST['anti_robot']=="f")
{
if ($_POST['score']!="")
{
	if ($_POST['score']==2)
		$en_plus=",demande_correction=1";
	$query="UPDATE commentaires set qualite_supposee=(qualite_supposee+($_POST[score]))$en_plus where id_commentaire=".$_GET['id_commentaire'];
	mysql_query($query);
	print('<p>
	Merci pour votre aide au classement
	</p>');
}
}
else
	print("<p>Ouups ? la lettre anti_robot n'est pas la bonne</p>");
print('
<p>
Vous pouvez retourner sur <a href="'.lien_point_fast($point).'">la fiche de '.$point->nom.'</a>
</p>

');
}
/**************************** le formulaire  ******************************/
else
{
print('<p>
Merci de nous aider dans notre t�che de classement des commentaires peu ou pas utile.
</p>
<p>
Vous pouvez aussi en savoir un peu plus sur <a href="/statique/mode_emploi.php?page=que_mettre">que mettre ou ne pas mettre sur www.refuges.info</a>
</p>
<p>
Que pensez vous du commentaire suivant :<br />
(votre avis sera �tudi� par un mod�rateur qui prendra sa d�cision)
</p>
<p><b>
'.bbcode2html($commentaire->texte).'
</b>
</p>
<p>
	<form method="post" action="./avis-internaute-commentaire.php?id_commentaire='.$_GET['id_commentaire'].'">
	<ul>
		<li><input type="radio" name="score" value="2" />Tr�s utile : ses informations devraient �tre rajout�es dans la fiche en haut !</li>
		<li><input type="radio" name="score" value="1" />Utile : Il est bien l� o� il est, �a rajoute quelque chose</li>
		<li><input type="radio" name="score" value="-1" />Peu utile : Il est subjectif du style "Il est bien, pas bien, etc." autant le mettre ailleurs ou il fait doublons avec un autre</li>
		<li><input type="radio" name="score" value="-2" />Pas utile du tout : Il n\'a rien a voir avec le point dont il parle (photos de fleurs, chamois, copains entre eux,...)</li>
		<li>Finalement, je n\'en pense rien, je retourne sur <a href="'.lien_point_fast($point).'">la fiche de '.$point->nom.'</a></li>
		<br />
		<li>Contre les robots merci d\'�crire la lettre f ici :<input type="text" name="anti_robot" /></li>
	</ul>
	<input type="submit" name="valider" value="Valider mon avis" />
	</form>
</p>




');
}
print("</div>");
include("../include/footer.php");
?>
