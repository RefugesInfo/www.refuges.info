<?php
//**********************************************************************************************
//* Nom du module:         | verif_massif.php                                                  *
//* Date :                 |                                                                   *
//* Cr�ateur :             |                                                                   *
//* R�le du module :       | Ecran de gestion de v�rification de la coh�rence des massifs.     *
//*                        | Droits: moderateuradmin & programmeur                             *
//*                        | Acc�s par : "./gestion/?page=verif_massif"                        *
//*                        |                                                                   *
//*------------------------|-------------------------------------------------------------------*
//* Modifications(date Nom)| Elements modifi�s, ajout�s ou supprim�s                           *
//*------------------------|-------------------------------------------------------------------*
//* 21/03/06 rff           |                                                                   *
//* 19/09/07               | Ne donne plus d'alerte si un point d'un massif est confondu       *
//*                        | avec celui d'un autre                                             *
//**********************************************************************************************

if ( (AUTH ==1) AND ($_SESSION['niveau_moderation']>=1) )
{
 include("../include/fonctions_massifs.php");

 connexion_base();

 $err = false;

 $query_massifs="SELECT *
        FROM polygone_type,polygones
        WHERE polygone_type.poly_ouvert=0
	AND polygone_type.id_polygone_type=polygones.id_polygone_type
        AND polygones.id_polygone!='1'
	AND polygones.id_polygone_type=".$config['id_massif'];
//$query_massifs="SELECT * fROM polygones where id_polygone=4";
 $resultat_liste_massifs=mysql_query($query_massifs);

 $nb_massifs=mysql_num_rows($resultat_liste_massifs);

 print("<p>V�rification de la coh�rence des massifs : $nb_massifs massifs � consid�rer</p>");
print("<p>On cherche les points des sommets de massif qui serait inclus dans un autre massif, 
ce qui veut dire qu'il y a incertitude si un point se trouvait dans la surface d'intersection des deux.
D�sormais, un sommet de polygone peut �tre commun � plusieurs polygones</p>");
$nb_erreur=0;
 while($massif=mysql_fetch_object($resultat_liste_massifs))
 {  //boucle sur chaque massif
    $resultat_test=polygone_gps_2_array_pts(trim($massif->polygone_gps));

    if ($resultat_test==NULL)
        print("<strong>Erreur : le Massif  ($massif->id_polygone) $massif->article_partitif $massif->nom_polygone a un nombre impaire de coordonn�es ou sans coordonn�es</strong>");
    else 
    {

        $query_autres_massifs="SELECT *
        FROM polygone_type LEFT JOIN polygones
        ON polygone_type.id_polygone_type=polygones.id_polygone_type
        WHERE polygones.id_polygone!=$massif->id_polygone
        AND polygone_type.id_polygone_type=".$config['id_massif'];

        $res=mysql_query($query_autres_massifs);
        while($massif_autre=mysql_fetch_object($res))
	{//balayer l'ensemble des massifs sauf le massif courant
         $resultat_autre_massif=polygone_gps_2_array_pts(trim($massif_autre->polygone_gps));
		if ($resultat_autre_massif!=NULL)
		{
		foreach($resultat_test as $point)
		{
			// Nouvelle fonctionnalit� qui �vite de donner une alerte si le point � l'�tude
			// est confondu avec un des sommets du massif � l'�tude 
			$point_confondu=FALSE;
			foreach ( $resultat_autre_massif as $point_massif )
			{

				if ($point_massif->x==$point->x AND $point_massif->y==$point->y)
					$point_confondu=TRUE;

			}
		if (!$point_confondu)
		{
			if (is_point_dans_massif($point->x,$point->y,$resultat_autre_massif))
			{
				print("<strong>le point ($point->x,$point->y) de '$massif->nom_polygone' est inclus dans le massif : '$massif_autre->nom_polygone'</strong><br />");
				$err=TRUE;
				$nb_erreur++;
			}
		}
		}
		}
	}//end while

        mysql_free_result($res );

    }//end else
 }//end while

 mysql_free_result($resultat_liste_massifs );

 print("<br>Fin des tests : $nb_erreur erreurs trouv�es.<br>");
}
?>