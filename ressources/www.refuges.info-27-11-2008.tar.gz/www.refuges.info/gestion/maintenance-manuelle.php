<?php
require("../include/zip.lib.php"); // Librairie pour compresser en ZIP (phpfrance.com) 
require("../include/fonctions_exportations.php");

include ("../include/fonctions.php");
include ("../include/fonctions_massifs.php");
	
connexion_base();
/*
r�cup�rer pour chaque polygone son max longitude
a adapter au besoin
exemple :
lat 44.948, 
Lon: 5.9067

SELECT polygones.id_polygone,max(longitude)
FROM polygones,lien_polygone_gps,points_gps WHERE
polygones.id_polygone=lien_polygone_gps.id_polygone
and
lien_polygone_gps.id_point_gps=points_gps.id_point_gps
group by id_polygone
*/



?>