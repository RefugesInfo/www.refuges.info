<?php
//**********************************************************************************************
//* Nom du module:         | gestion_pub.php                                                  *
//* Date :                 |                               31/05/08                                    *
//* Cr�ateur :             |                                              jmb                     *
//* R�le du module :       | Ecran de gestion des motclef de pub    *
//*                        | Droits:  programmeur                             *
//*                        | Acc�s par : "./gestion/?page=gestion_pub"                        *
//*                        |                                                                   *
//*------------------------|-------------------------------------------------------------------*
//* Modifications(date Nom)| Elements modifi�s, ajout�s ou supprim�s                           *
//*------------------------|-------------------------------------------------------------------*
//**********************************************************************************************



if ( (AUTH == 1) AND ($_SESSION['niveau_moderation']>=3) )
{
	include("../include/fonctions_pubs.php");

	echo "<h4> G�re les motclef de la pub cibl�e ClickIntext</h4>";
	echo "<p>les login/pwd de ClickInText sont dans include_pub. <em>on peut laisser certains trucs meme si pour l'instant ils ne renvoient rien, de tt facon, la pub s'affiche toujours (changement automatic motcle en cas d echec)</em><br />id�alement, marche en rotation avec le truc automatique de clickintext.</p>";
	echo "<h5> NE PAS CLIQUER ! pour pas se faire jeter </h5>";

	// recup des motcles du fichier
	//$fichiermotcles = "http://www.refuges.info/include/motcles_pub.txt";
	$fichiermotcles = $config['document_root']."/include/motcles_pub.txt";

	$motclefs = preg_split('/(\r\n|\n|\r)/',file_get_contents($fichiermotcles));

	if ($_POST['asup']) // liste des lignes a supprimer
		foreach ( $_POST['asup'] as $cle )
			unset($motclefs[$cle]); // vire la ligne
	if ($_POST['newmotcles']) // il y a des nvx motcles
		$motclefs = array_merge(
								$motclefs,
								preg_split ('/(\r\n|\n|\r)/',$_POST['newmotcles']) ) ;

	// ecrit le fichier des motcles et relit pour pas etre perturbe par les index (ya mieux)
	file_put_contents( $fichiermotcles, join( "\n", $motclefs ) );
	$motclefs = preg_split('/(\r\n|\n|\r)/',file_get_contents($fichiermotcles));

	echo "
		<form action='' method='post'>
			<dl>";

	foreach ($motclefs as $ligne=>$motcle)
	{
		echo "
			<dt><label><input name='asup[]' value='$ligne' type='checkbox' />$motcle:</label> (ligne: $ligne)</dt>
				<dd>
		"; 
		$publicite = bandeau_publicitaireXML(10,array($motcle)) ;
		if ( ! $publicite )
			echo "<strong>RIEN</strong>";
		else
			echo $publicite ;
		echo "
				</dd>
		";
	}
	echo "
		</dl> RANDOM � 2 annonces(fonctionnement normal): ".bandeau_publicitaireXML(2)."
		<p>Nouveaux motcl� s�par�s par un retourchariot:
			<textarea name='newmotcles' rows='10' cols='60'></textarea>
		</p>
		<input type='submit' value='Supprimer la selection, et ajouter les nouveaux' />
	</form>
	";
}
?>