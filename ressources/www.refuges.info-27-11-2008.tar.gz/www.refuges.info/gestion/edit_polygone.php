<?PHP 
//**********************************************************************************************
//* Nom du module:         | edit_polygone.php                                                 *
//* Param�tre :            | ?polygone=123     id_polygone dans la base                        *
//* Date :                 | 15/11/2008                                                        *
//* Cr�ateur :             | Dominique cavailhez                                               *
//* R�le du module :       | Edition graphique des points d'un polygone					       *
//*                        |                                                                   *
//*------------------------|-------------------------------------------------------------------*
//* Modifications(date Nom)| Elements modifi�s, ajout�s ou supprim�s                           *
//*------------------------|-------------------------------------------------------------------*
//* 15/11/2008 Dominique   | Interface graphique sans modif de la base					       *
// A FAIRE : TRAITEMENT DU $_POST POUR METTRE A JOUR LA BASE
//**********************************************************************************************
// Utilise les fichiers : /images/flag.png & /images/bullet.png
// lL r�pertoire /gestion/polygone_gif/ ne contient que des fichiers temporaire. Il se reg�n�re tout seul

require ("../include/fonctions.php");
$mysqlink = connexion_base ();

/**********************************************************************************************/
// R�cup�ration du param�tre
/**********************************************************************************************/
$get_polygone = 
	isset ($_GET ['polygone'])
		?  $_GET ['polygone']
		:  4; // par d�faut : le Vercors
		
/**********************************************************************************************/
// Traitement des saisies
/**********************************************************************************************/
// ZONE A REMPLACER PAR LE TRAITEMENT DU $_POST POUR METTRE A JOUR LA BASE
if (isset  ($_POST ['action']))
	switch ($_POST ['action'])
{
	case 'Creer':
	case 'Deplacer':
	case 'Supprimer':
		print_r ('Argument $_POST � traiter : ');
		print_r ($_POST);
		print_r ('<BR>');
		break;
}
// FIN DE ZONE A REMPLACER PAR LE TRAITEMENT DU $_POST POUR METTRE A JOUR LA BASE	
/**********************************************************************************************/
// Lecture du nom du polygone concern�
/**********************************************************************************************/
$sql_select_poly = 
	"SELECT article_partitif, nom_polygone 
	 FROM polygones 
	 WHERE id_polygone = $get_polygone";
$rq_select_poly = mysql_query ($sql_select_poly ) or die( "mauvaise requete sql_select_poly");

if (mysql_num_rows ($rq_select_poly ) < 1)
	print ("Il n'y a pas de polygone d'id $get_polygone<BR>\n");
else if (mysql_num_rows ($rq_select_poly ) > 1)
	print ("Bizarre, il y a " .mysql_num_rows ($rq_select_poly) ." polygones d'id $get_polygone<BR>\n");
else
{
	$objrq_poly = mysql_fetch_object ($rq_select_poly);
	print ("Edition du polygone $objrq_poly->article_partitif $objrq_poly->nom_polygone<BR>\n");
}	
/**********************************************************************************************/
// Lecture de la liste des points du polygone
/**********************************************************************************************/
$sql_select_point = 
	"SELECT latitude, longitude 
	 FROM lien_polygone_gps, points_gps
	 WHERE  lien_polygone_gps.id_polygone = $get_polygone
		AND lien_polygone_gps.id_point_gps = points_gps.id_point_gps";
$rq_select_point = mysql_query ($sql_select_point ) or die( "mauvaise requete sql_select_point");

$poly = array ();
while ($objrq_point = mysql_fetch_object ($rq_select_point))
{
	$poly [] = array (
					'lat' => $objrq_point->latitude, 
					'lon' => $objrq_point->longitude,
					);
}
/**********************************************************************************************/
// Lecture des polygones adjacents
/**********************************************************************************************/
$sql_select_voisin = 
	"
	SELECT DISTINCT l2.id_polygone, nom_polygone, latitude, longitude
	 FROM points_gps, polygones,
		          lien_polygone_gps l1
       INNER JOIN lien_polygone_gps l2
       INNER JOIN lien_polygone_gps l3
             ON  l1.id_polygone  = $get_polygone
			 AND l1.id_point_gps = l2.id_point_gps
			 AND l2.id_polygone  = l3.id_polygone
		WHERE
			 l3.id_point_gps = points_gps.id_point_gps
			 AND polygones.id_polygone = l2.id_polygone
			 ";
$rq_select_voisin = mysql_query ($sql_select_voisin ) or die( "mauvaise requete sql_select_voisin");

$voisin = array ();
$voisin_poly = array ();
while ($objrq_voisin = mysql_fetch_object ($rq_select_voisin))
{
	$voisin [$objrq_voisin->id_polygone] ['nom'] = $objrq_voisin->nom_polygone;
	if (isset ($voisin_poly))
	{
		$voisin [$objrq_voisin->id_polygone] ['lat'] += $objrq_voisin->latitude;
		$voisin [$objrq_voisin->id_polygone] ['lon'] += $objrq_voisin->longitude;
	}
	else
	{
		$voisin [$objrq_voisin->id_polygone] ['lat'] = $objrq_voisin->latitude;
		$voisin [$objrq_voisin->id_polygone] ['lon'] = $objrq_voisin->longitude;
	}
	$voisin_poly [$objrq_voisin->id_polygone] [] = array (
				'lat' => $objrq_voisin->latitude, 
				'lon' => $objrq_voisin->longitude,
				);
}
/**********************************************************************************************/
// Lib�ration des requettes SQL
/**********************************************************************************************/
mysql_free_result ($rq_select_voisin);
mysql_free_result ($rq_select_point);
mysql_free_result ($rq_select_poly);

if (is_resource ($mysqlink))
    mysql_close ($mysqlink);
	
/**********************************************************************************************/
// On peut commencer le doc HTML
/**********************************************************************************************/
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml">
  <head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8"/>
    <title>Editeur de polygones</title>
    <script src="http://maps.google.com/maps?file=api&amp;v=2&amp;key=ABQIAAAAQ3l5Pw_ABnW9oWQY7dON-xQ9iFR7dHeM-ObyhFmfli343_zKshTGqkosADz7jBhYsZ2TAspGI_t56g"
            type="text/javascript"></script>
    <script type="text/javascript">
	
/**********************************************************************************************/
// Transfert du tableau de point de PHP au javascript
/**********************************************************************************************/
	var borne   = new Array ();
	var inter   = new Array ();
	var pvoisin = new Array ();
	var nvoisin = new Array ();

<?PHP
	foreach ($poly as $i => $p)
	{
		print ("borne [$i] = new GLatLng (" .$p ['lat'] .', ' .$p ['lon'] .");\n"); // Bornes
		$s = isset ($poly [$i + 1]) // Borne suivante
			? $poly [$i + 1]
			: $poly [0];
		// Point interm�diaire
		print ("inter [$i] = new GLatLng (" 
					.moy ($p ['lat'], $s ['lat']) .', ' 
					.moy ($p ['lon'], $s ['lon']) .");\n"); 
	}
	foreach ($voisin as $i => $p)
	{
		if (!is_dir ('polygone_gif')) mkdir ('polygone_gif');
		$nf = texte_gif ($p ['nom']); // Fabrication de l'icone contenant le nom du polygone
		$sz = getimagesize ($nf);
		print ("nvoisin ['$nf'] = new Array ();\n");
		print ("nvoisin ['$nf'] ['lonlat'] = new GLatLng (" 
					.$p ['lat'] / count ($voisin_poly [$i]) .', ' 
					.$p ['lon'] / count ($voisin_poly [$i]) .");\n");
		print ("nvoisin ['$nf'] ['size'] = new GSize  (" .$sz [0] .", " .$sz [1] .");\n"); // Taille de l'mage GIF
		print ("nvoisin ['$nf'] ['link'] = 'edit_polygone.php?polygone=$i';\n"); // Taille de l'mage GIF
	}
	foreach ($voisin_poly as $i => $p)
		if ($i != $get_polygone)
		{
			print ("pvoisin [$i] = new Array ();\n");
			foreach ($p as $ip => $pp)
				print ("pvoisin [$i] [$ip] = new GLatLng (" .$pp ['lat'] .', ' .$pp ['lon'] .");\n");
		}
?>

/**********************************************************************************************/
// Initialisation de googlemap
/**********************************************************************************************/
    function initialize () // Lanc�e quand le doc HTML est charg�
	{
		if (GBrowserIsCompatible ()) 
		{
	        var map = new GMap2 (document.getElementById ("map_canvas"));
			map.enableScrollWheelZoom (); // Contr�le de l'�chelle avec la molette
			map.enableContinuousZoom (); // Zoom fluide avec la molette
			map.addControl (new GSmallZoomControl()); // Un controle + et - en haut � gauche
			map.addControl (new GScaleControl ()); // L'�ch�le des cartes en bas � gauche

			// Types de cartes
			map.addControl (new GMapTypeControl ()); // Modes plan / satellite / mixte
			map.addMapType (G_PHYSICAL_MAP); // Ajout du mode relief
			map.setMapType (G_PHYSICAL_MAP); // Affichage par d�faut
			
			// Super carte dans le coin en bas a droite
			var ov = new GOverviewMapControl (new GSize (100, 100));
			map.addControl (ov);
			ov.hide (true); // Et elle est repli�e par d�faut
			
			// On encadre la carte autour des points du polygone
			var bounds = new GLatLngBounds;
			for (var p in borne)
				bounds.extend (borne [p]);
			map.setCenter (bounds.getCenter ());
			map.setZoom (map.getBoundsZoomLevel (bounds));
			
/**********************************************************************************************/
// Dessin des polygone voisins 
/**********************************************************************************************/
			// On les met avant pour que le polygone �dit� l'efface dans les parties comunes
			for (var p in pvoisin)
			{
				pvoisin [p] [1000] = pvoisin [p] [0]; // On ferme le polygone
				map.addOverlay (new GPolyline (pvoisin [p], "#0000ff", 2));
			}
/**********************************************************************************************/
// Dessin du polygone
/**********************************************************************************************/
			borne [1000] = borne [0]; // On ferme le polygone
			map.addOverlay (new GPolygon (borne, "#f33f00", 5, 1, "#ff0000", 0.2));
			
/**********************************************************************************************/
// Dessin des bornes
/**********************************************************************************************/
			// Construction de l'icone drapeau
			var flag = new GIcon ();
			flag.image            = '../images/flag.png';
			flag.iconSize         = new GSize  (32, 32);
			flag.iconAnchor       = new GPoint (11, 30);
			flag.infoWindowAnchor = new GPoint (16, 16);
			
			var options = new Array ();
			options ['title'    ] = 'Deplacer une borne';
			options ['icon'     ] = flag;
			options ['draggable'] = true;
			
			// G�n�ration des bornes
			for (var p in borne)
			{
				var marker = new GMarker (borne [p], options);
				marker.no = p;

		        GEvent.addListener (marker, 'dragstart', 
					function () 
					{
						map.closeInfoWindow ();
					});
					
				// Affiche la position courante lors du gliss� dans une balise <DIV id=position>
				GEvent.addListener (marker, 'drag', 
					function () 
					{
						document.getElementById ('position').innerHTML =
							this.getLatLng().toUrlValue() ;
					});

				GEvent.addListener (marker, 'dragend', 
					function () 
					{
						this.openInfoWindowHtml (
							'<FORM method=POST action=' + window.location + '>'+
							'<B>Deplacer cette borne:</B><BR>'+
							'<INPUT name="borne"  value="' + this.no + '" type="hidden">'+
							'<INPUT name="latlon" value=' + this.getLatLng().toUrlValue() + ' readonly style=background-color:#e0e0e0>'+
							'<INPUT type=submit name=action value=Deplacer>'+
							'<HR><B>Permuter avec la borne suivante:</B><BR>'+
							'<INPUT type=submit name=action value="Permuter">'+
							'<HR><B>Supprimer cette borne:</B><BR>'+
							'<INPUT type=submit name=action value="Supprimer">'+
							'</FORM>');
					});
				
		        map.addOverlay (marker);
			}
/**********************************************************************************************/
// Dessin des points interm�diaires
/**********************************************************************************************/
			// Construction de l'icone de points interm�diaire
			var bullet = new GIcon ();
			bullet.image            = '../images/bullet.png';
			bullet.iconSize         = new GSize  (15, 15);
			bullet.iconAnchor       =
			bullet.infoWindowAnchor = new GPoint ( 7,  7);
			
			var options = new Array ();
			options ['title'    ] = 'Inserer une borne';
			options ['icon'     ] = bullet;
			options ['draggable'] = true;
			
			// G�n�ration des bornes
			for (var p in inter)
			{
				var marker = new GMarker (inter [p], options);
				marker.no = p;

		        GEvent.addListener (marker, 'dragstart', 
					function () 
					{
						map.closeInfoWindow ();
					});
					
				// Affiche la position courante lors du gliss� dans une balise <DIV id=position>
				GEvent.addListener (marker, 'drag', 
					function () 
					{
						document.getElementById ('position').innerHTML =
							this.getLatLng().toUrlValue() ;
					});

				GEvent.addListener (marker, 'dragend', 
					function () 
					{
						this.openInfoWindowHtml (
							'<B>Creer une borne:</B><BR><BR>'+
							'<FORM method=POST action=' + window.location + '>'+
							'<INPUT name="borne"  value="' + this.no + '" type="hidden">'+
							'<INPUT name="latlon" value=' + this.getLatLng().toUrlValue() + ' readonly style=background-color:#e0e0e0>'+
							'<INPUT type=submit name=action value=Creer>'+
							'</FORM>');
					});
				
		        map.addOverlay (marker);
			}
/**********************************************************************************************/
// Implantation des noms des massifs voisins
/**********************************************************************************************/
			for (var nf in nvoisin)
			{
			
				// Construction de l'icone de points interm�diaire
				var nom = new GIcon ();
				nom.image            = nf;
				nom.iconSize         = nvoisin [nf] ['size'];
				nom.iconAnchor       =
				nom.infoWindowAnchor = new GPoint ( 7,  7);
				
				var options = new Array ();
				options ['title'    ] = 'Editer ce massif';
				options ['icon'     ] = nom;
				options ['clickable'] = true;
				
				var marker = new GMarker (nvoisin [nf] ['lonlat'], options);
				marker.link = nvoisin [nf] ['link']; // On l'embale dans le marker pour pouvoir l'utiliser dans le callback
				map.addOverlay (marker);
			
				GEvent.addListener (marker, 'click', 
					function () 
					{
						window.location.href = this.link; // Va sur le lien sp�cifier
					});
			}
/**********************************************************************************************/
// Fin du code java. On cr�e le conteneur HTML
/**********************************************************************************************/
		}
    }
    </script>
  </head>

  <body onload="initialize()" onunload="GUnload()">
    <div id="map_canvas" style="width: 800px; height: 600px"></div>
    <div id="position"></div>
  </body>
</html>

<?PHP
/**********************************************************************************************/
// Fonctions de base PHP
/**********************************************************************************************/
function moy ($a, $b) {return ($a + $b) / 2;};
/**********************************************************************************************/
function texte_gif ($txt) // Converti une chaine de caract�re en fichier GIF
{
	global $site;
	$nom = strtolower (str_replace (' ', '', strtr ($txt, // On purge le nom des caract�res qui ne peuvent pas �tre dans un nom de fichier
		"������������������������������������@�'&|!;:.,*+-/=#$%<>(){}[]_", 
		"aaaeeeeiiiooouuucnaaaeeeeiiiooouuucnae_________________________")));
	$nf = "./polygone_gif/$nom.gif";
	if (!is_file ($nf))
	{
		$sai = strtr ($txt, "�", "e"); // On purge des caract�res non trait�s par les fonctions GD de PHP
		$sai = strtr ($sai, "/", " ");
		$font_size = 3;
		$xpos = 2; // Zone avant et apr�s le texte
		$font_width = imagefontwidth  ($font_size);
		$img_height = imagefontheight ($font_size);
		$img_width  = $font_width * strlen ($sai) + $xpos * 2;
		$img   = imagecreate ($img_width, $img_height);
		$white = imagecolorallocate ($img,   0,   0, 255);
		$black = imagecolorallocate ($img, 255, 255, 255);
		while ($sai != "") // Ecriture dans l'image
		{
		   imagechar ($img, $font_size, $xpos, 0, $sai, $black);
		   $xpos += $font_width;
		   $sai = substr ($sai, 1);    
		}
		imagegif ($img, $nf);
		imagedestroy ($img);
	}
	return $nf;
}
?>	
