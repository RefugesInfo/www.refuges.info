<?php
//**********************************************************************************************
//* Nom du module:         | fonctions_gestion.php                                             *
//* Date :                 |                                                                   *
//* Cr�ateur :             |                                                                   *
//* R�le du module :       | fonctions de gestion                                              *
//*                        |                                                                   *
//*------------------------|-------------------------------------------------------------------*
//* Modifications(date Nom)| Elements modifi�s, ajout�s ou supprim�s                           *
//*------------------------|-------------------------------------------------------------------*
//* 21/03/06 rff           | test_autorisation_acces : intro droits supermod�rateur            *
//*                        |                                                                   *
//**********************************************************************************************


/*******************************************************/
// fonction qui loguera TOUT TYPE de moderation
// la plupart des champs sont connus lors de l'appel
// seul contenu est alors donn�
// 14/09/07 d�sactiv� car jamais eu de probl�me de r�cup�ration
/*******************************************************/
function log_moderation($contenu,
			$type_moderation,
			$idpoint,
			$moderateur)
			//$type_moderation=$_GET['type'],
			//$idpoint=$_GET['id_point_retour'],
			//$moderateur=$_SESSION['id_moderateur'])
{
	$query_sauvegarde="
		INSERT INTO logs_moderation
		SET 
			date_moderation=NOW(),
			id_moderateur=$moderateur,
			type_moderation='$type_moderation',
			id_point=$idpoint,
			contenu='".mysql_real_escape_string(stripslashes($contenu))."'";
	//mysql_query($query_sauvegarde) or die("erreur requete $query_sauvegarde");
	return true;
}



/*******************************************************/
// transfert le commentaire et la photo sur le forum
// la photo dans le repertoire $config['rep_forum_photos']
/*******************************************************/
function transfert_commentaire($id_commentaire)
{
    global $config;
    connexion_base();

    $query="SELECT * FROM commentaires WHERE id_commentaire=$id_commentaire";
    $res=mysql_query($query) or die("mauvaise requete: $query");
    $commentaire=mysql_fetch_object($res);

    //--------------------------
    // Debut gros merdier forum

    $querycom="SELECT * FROM phpbb_topics WHERE topic_id_point=$commentaire->id_point";
    $res=mysql_query($querycom) or die("mauvaise requete: $querycom");
    $forum=mysql_fetch_object($res);

    // dabord declarer le post
    $query_insert_post="
    	INSERT INTO phpbb_posts
	SET
		topic_id=$forum->topic_id ,
		forum_id=$forum->forum_id ,
		poster_id='-1',
		post_time=UNIX_TIMESTAMP('$commentaire->date') ,
		post_username='".mysql_real_escape_string(stripslashes($commentaire->auteur))."'";
    mysql_query($query_insert_post) or die("mauvaise requete: $query_insert_post");
    $postid=mysql_insert_id(); // recupere le post_id

    // ensuite entrer le texte du post
    // la folie bbcode: generer un rand sur 10 chiffres, et l'utiliser dans les balises...
    $bbcodeuid = mt_rand( 1000000000, 9999999999 );
    $query_post_text="
	INSERT INTO phpbb_posts_text
	SET
		post_id=$postid,
		bbcode_uid=$bbcodeuid, 
		post_text='";
    if ($commentaire->photo_existe) {
	// insere la balise bbcode pour la photo
	$query_post_text.="[img:$bbcodeuid]http://refuges.info/".$config['rep_web_forum_photos'].$commentaire->id_commentaire.".jpeg[/img:$bbcodeuid]\n";
	// et deplace la photo
	rename($config['rep_photos_points'].$commentaire->id_commentaire.".jpeg",
      		$config['rep_forum_photos'].$commentaire->id_commentaire.".jpeg");
    }
    // insere le texte du comment
    $query_post_text.=mysql_real_escape_string(stripslashes($commentaire->texte))."'";
    mysql_query($query_post_text) or die("mauvaise requete: $query_post_text");
    // Voila. le texte est rentr�.

    /*** remise � jour du topic ( alors ici c'est le bouquet, un champ qui stoque le premier et le dernier post ?? )***/
    $query_update_topic="UPDATE phpbb_topics
   			 SET
    				topic_last_post_id=$postid
    			 WHERE topic_id=$forum->topic_id
			 LIMIT 1";
    mysql_query($query_update_topic) or die("mauvaise requete: $query_update_topic");


    // Fin gros merdier forum
    //-------------------------

    log_moderation("Transfert du commentaire $id_commentaire vers le forum",
    			"transfert_forum",
			$commentaire->id_point,
			$_SESSION["id_moderateur"]);
}

/*******************************************************/
// modif  le commentaire
// en param:
// -id_commentaire
// -nouveau texte
// -nouveau auteur
/*******************************************************/
function modification_commentaire($id_commentaire, $nouveautexte, $nouveauauteur, $nouvelledate)
{
    connexion_base();

    $query="SELECT * FROM commentaires WHERE id_commentaire=$id_commentaire";
    $res=mysql_query($query) or die("mauvaise requete: $query");
    $commentaire=mysql_fetch_object($res);

    // arrange la date
    $date_ts = date_jjmmaaaa2TS($nouvelledate);

    $query_update="
    		UPDATE commentaires 
		SET
			texte='".mysql_real_escape_string(stripslashes($nouveautexte))."',
			auteur='".mysql_real_escape_string(stripslashes($nouveauauteur))."',
			date=FROM_UNIXTIME($date_ts)
    		WHERE id_commentaire=$id_commentaire
		LIMIT 1";
    $res=mysql_query($query_update) or die("mauvaise requete: $query_update");

    log_moderation("Modif du commentaire $id_commentaire :"
    				."\n---AVANT:"
  				."\nauteur: ".mysql_real_escape_string(stripslashes($commentaire->auteur))
				."\ndate: ".$commentaire->date ."\n"
				.mysql_real_escape_string(stripslashes($commentaire->texte))
    				."\n---APRES:\n"
  				."auteur: ".mysql_real_escape_string(stripslashes($nouveauauteur))."\n"
				."\ndate: ".$nouvelledate ."\n"
				.mysql_real_escape_string(stripslashes($nouveautexte)),
    			"modification",
			$commentaire->id_point,
			$_SESSION["id_moderateur"]);
}
?>
