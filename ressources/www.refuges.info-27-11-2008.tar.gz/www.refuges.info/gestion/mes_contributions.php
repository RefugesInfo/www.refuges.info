<?php
//**********************************************************************************************
//* Nom du module:         | verif_massif.php                                                  *
//* Date :                 |                                                                   *
//* Cr�ateur :             |                                                                   *
//* R�le du module :       | Ecran de gestion de v�rification de la coh�rence des massifs.     *
//*                        | Droits: moderateuradmin & programmeur                             *
//*                        | Acc�s par : "./gestion/?page=verif_massif"                        *
//*                        |                                                                   *
//*------------------------|-------------------------------------------------------------------*
//* Modifications(date Nom)| Elements modifi�s, ajout�s ou supprim�s                           *
//*------------------------|-------------------------------------------------------------------*
//* 21/03/06 rff           |                                                                   *
//* 19/09/07               | Ne donne plus d'alerte si un point d'un massif est confondu       *
//*                        | avec celui d'un autre                                             *
//**********************************************************************************************

if ( (AUTH ==1) )
{

 connexion_base();
print("Bient�t disponible !");
}
?>