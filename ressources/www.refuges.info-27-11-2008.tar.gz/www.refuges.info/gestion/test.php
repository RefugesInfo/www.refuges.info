<?php
require("../include/zip.lib.php"); // Librairie pour compresser en ZIP (phpfrance.com) 
require("../include/fonctions_exportations.php");

include ("../include/fonctions.php");
include ("../include/fonctions_massifs.php");
include ("../include/fonctions_points.php");

	
connexion_base();
print_r(infos_point(2610));
?>