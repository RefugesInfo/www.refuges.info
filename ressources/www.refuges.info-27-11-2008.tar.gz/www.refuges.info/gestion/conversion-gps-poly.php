<?php
require("../include/zip.lib.php"); // Librairie pour compresser en ZIP (phpfrance.com) 
require("../include/fonctions_exportations.php");

include ("../include/fonctions.php");
include ("../include/fonctions_massifs.php");
	
connexion_base();

// ATTENTION, �a ne marche que si latitude et longitude sont de type decimal en mysql sinon le test d'�galit� plante lamentablement
// cr�ant ainsi plein de points_gps doublon
// une autre m�hode serait un traitement par arrondies (round) ou par encadrement latitude>6.45676 and latitude<6.45677
// rappels : une pr�cision de 0.00001 degr� d�cimaux correspond � une longeure de 1m au niveau de l'�quateur, et moins
// encore chez nous, donc largement assez !


$query="select * FROM polygones";
$res=mysql_query($query);
while ($poly=mysql_fetch_object($res))
{
$polygone=polygone_gps_2_array_pts($poly->polygone_gps);
if ($polygone!=NULL)
{
$ordre=0;

foreach ($polygone as $point)
{

	$query_existe="select * from points_gps where latitude=$point->y and longitude=$point->x";
	$point_existe=mysql_query($query_existe);
	if (mysql_num_rows($point_existe)==0)
	{
	$query_insert="INSERT INTO points_gps set latitude=$point->y,longitude=$point->x,id_type_precision_gps=4";
	mysql_query($query_insert);
	$id_point_gps=mysql_insert_id();
	}
	else
	{
	print("point latitude=$point->y,longitude=$point->x d�j� dans la table<br>");
	$point_existant=mysql_fetch_object($point_existe);	
	$id_point_gps=$point_existant->id_point_gps;
	}
	$query_poly_ajout="INSERT into lien_polygone_gps set id_point_gps=$id_point_gps,id_polygone=$poly->id_polygone,ordre=$ordre";
	mysql_query($query_poly_ajout);
	$ordre++;
}


}
else
	print($poly->nom_polygone." est foireux<br />");
}

?>