<?php
require("../include/zip.lib.php"); // Librairie pour compresser en ZIP (phpfrance.com) 
require("../include/fonctions_exportations.php");

include ("../include/fonctions.php");
include ("../include/fonctions_massifs.php");
	
connexion_base();
/*
r�cup�rer pour chaque polygone son max longitude
a adapter au besoin
exemple :
lat 44.948, 
Lon: 5.9067

SELECT polygones.id_polygone,max(longitude)
FROM polygones,lien_polygone_gps,points_gps WHERE
polygones.id_polygone=lien_polygone_gps.id_polygone
and
lien_polygone_gps.id_point_gps=points_gps.id_point_gps
group by id_polygone
*/


$query="select * FROM points where id_point!=71";
$res=mysql_query($query);
$i=0;
while ($point=mysql_fetch_object($res))
{

	$query_existe="select * from points_gps 
			where round(latitude,6)=round($point->gps_lat,6) and round(longitude,6)=round($point->gps_long,6)";
	$point_existe=mysql_query($query_existe);
	if (mysql_num_rows($point_existe)==0)
	{
	$query_insert="INSERT INTO points_gps set 
			latitude=$point->gps_lat,longitude=$point->gps_long,
			id_type_precision_gps=$point->precision_gps,
			altitude=$point->altitude,
			acces='".addslashes($point->acces)."'";
	mysql_query($query_insert) or die ($query_insert);
	$i++;
	$id_point_gps=mysql_insert_id();
	print($id_point_gps." ins�r� en erreur ############################### $query_existe<br>");
	}
	else
	{
	$point_existant=mysql_fetch_object($point_existe);	
	$id_point_gps=$point_existant->id_point_gps;
	//print("$point->id_point ($point->nom latitude=$point->gps_lat,longitude=$point->gps_long d�j� dans la table<br>");
	}
	$query_update="update points set id_point_gps=$id_point_gps where id_point=$point->id_point";
	mysql_query($query_update);
}
print("$i points_gps ins�r�s<br>");

?>