<?php
//**********************************************************************************************
//* Nom du module:         | calcul_appartenance_polygone.php                                  *
//* Date :                 |                                                                   *
//* Cr�ateur :             |                                                                   *
//* R�le du module :       | Ecran de gestion du calcul d'appartenance des points (refuges,etc)*
//*                        | � un ou plusieurs polygones.                                      *
//*                        | Droits: admin & supermod�rateur.                                  *
//*                        | Acc�s par : "./gestion/?page=calcul_appartenance_polygone"        *
//*                        |                                                                   *
//*                        | On peut r�sumer sa fonction en disant qu'il pr�calcule les champs *
//*                        | de la table appartenance_polygone pour chaque point de la base    *
//*                        | le faire en temps r��l ne fonctionne pas car il faut au moins une *
//*                        | Minute par 1000 points !                                          *
//*                        | Imaginez un peu le temps d'une recherche : "tous les refuges de   *
//*                        | belledonne" alors que l� avec pr�calcul c'est tr�s rapide         *
//*------------------------|-------------------------------------------------------------------*
//* Modifications(date Nom)| Elements modifi�s, ajout�s ou supprim�s                           *
//*------------------------|-------------------------------------------------------------------*
//* 21/03/06 rff           |                                                                   *
//*                        |                                                                   *
//* 06/03/08	jmb	   | OK. devrait bein passer avec gmaps                                *
//* 31/10/08	sly	   | d�sormais on ne calcul plus que massif mais aussi Tous polygones  *
//*                  	   | TRES TRES long, optimisation en cours de recherche                *
//*             	   | Ou s�paration en plusieurs �tapes                                 *
//*             	   | 95 s au dernier bench, je n'ai pas d'autres id�es performance     *
//*             	   | je pourrais rajouter du pr�-calcul pour les tableaux polygones    *
//*             	   | Mais c'est relou car une fonction existe d�j�                     *
//**********************************************************************************************

//v�rification des autorisations

if ( (AUTH ==1) AND ($_SESSION['niveau_moderation']>=2) )
{
include("../include/fonctions_massifs.php");
print("<p>Calcul d'Appartenance Polygones</p>");

$query="SELECT id_point FROM points WHERE modele!=1";
$resultat_liste=mysql_query($query);
$nbpoints=mysql_num_rows($resultat_liste);

$t=microtime(true);
print("<p>$nbpoints points � recalculer d�but=0s</p>");
$bilan=array();

$query_polygones= "SELECT *
	FROM polygones WHERE id_polygone!=0";

$resultat_liste_polygones=mysql_query($query_polygones);
$nb_polygones=mysql_num_rows($resultat_liste_polygones);

print("<h4>$nb_polygones polygones � consid�rer</h4>");

mysql_query("TRUNCATE TABLE appartenance_polygone");
//balayage de la liste de points
// tout le boulot est dans cette fonction, et elle rame ! (genre 0.1s par points)
// pour 1, c'est rien, pour 2000 glups !
while ($point=mysql_fetch_object($resultat_liste))
	mettre_a_jour_appartenance_point($point->id_point);


print("Fin du calcul: ".(microtime(true)-$t)."s<br />Bilan :<br />");
$query_bilan="SELECT *,count(*) as nombre FROM polygones,appartenance_polygone 
		WHERE appartenance_polygone.id_polygone=polygones.id_polygone 
group by polygones.id_polygone 
ORDER by nombre desc";
$res=mysql_query($query_bilan);
while ($poly=mysql_fetch_object($res))
{
print("$poly->nom_polygone ($poly->id_polygone) : $poly->nombre points<br />");
}

}

?>