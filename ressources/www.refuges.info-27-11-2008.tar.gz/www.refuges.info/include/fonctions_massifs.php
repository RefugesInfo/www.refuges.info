<?php
//**********************************************************************************************
//* Nom du module:         | fonctions_massifs.php                                             *
//* Date :                 |                                                                   *
//* Cr�ateur :             |                                                                   *
//* R�le du module :       | Fonctions sp�cifiques massifs.                                    *
//*                        |                                                                   *
//*------------------------|-------------------------------------------------------------------*
//* Modifications(date Nom)| Elements modifi�s, ajout�s ou supprim�s                           *
//*------------------------|-------------------------------------------------------------------*
//* 10/03/06 rff           |-Lib�ration des r�sultats sql [mysql_free_result] ds les fonctions *
//*                        | [wms_massifs_image_map] & [calcul_selon_polygone]                 *
//*                        |-Retouche taille d'image polygonr dans [calcul_selon_polygone]     *
//* 21/03/06 rff           |-is_intersection: corr. anomalie>>gestion segments verticaux       *
//*                        |                    
//* 03/03/08	jmb	les 2 derni�res fct seront supprimable qd on passera sous google                                               *
//13/03/08	jmb	calcul_polygone �pur� cause gmaps
//**********************************************************************************************

// FIXME ; devrait �tre renomm� en fonctions_polygones.php car sa port�e est maintenant plus g�n�rale sly 29/10/08

/** 
fonction de r�cup�ration des sommets ordonn�s d'un polygone de la base
au format :
Array
(    [0] => Object
        (
            [x] => 4.2
            [y] => 6
        )
    [1] => Object
        (
            [x] => 7
            [y] => 8.3
        ) 
)
**/
function tableau_polygone($id_polygone)
{
$query="SELECT latitude,longitude,points_gps.id_point_gps 
		FROM points_gps,lien_polygone_gps
		where lien_polygone_gps.id_point_gps=points_gps.id_point_gps 
		and id_polygone=$id_polygone 
		order by ordre";
$re=mysql_query($query);
$i=0;
while($poly=mysql_fetch_object($re))
{
	$polygone_gps[$i]->x=$poly->longitude;
	$polygone_gps[$i]->y=$poly->latitude;
	$i++;
}
mysql_free_result($re);
return $polygone_gps;
}

// fonction temporaire pour rester retro-compatible, on lui donne l'id d'un polygone
// elle retourne une chaine du polygone au format : 4.2,6,7,8.3
// id�al pour �tre pass�e � la fonction suivante !
function chaine_polygone($id_polygone)
{
$polygone_gps=tableau_polygone($id_polygone);
$chaine="";
foreach ($polygone_gps as $point)
	$chaine.="$point->x,$point->y,";

$chaine=trim($chaine,",");
return $chaine;
}
/************************************************************
Voici une fonction qui transforme une chaine de charact�re du type
4.2,6,7,8.3
en un array plus simple � traiter du type :
( logique r�tro compatible, on peut d�sormais utiliser directement tableau_polygone )
Array
(    [0] => Object
        (
            [x] => 4.2
            [y] => 6
        )
    [1] => Object
        (
            [x] => 7
            [y] => 8.3
        ) 
)
elle retourne NULL quand le massif n'est pas cooh�rant
( nombre impaire de coordonn�es, nombre nul de coordon�e )
il faut utiliser cette fonction en analysant son retour.
Si NULL ne rien faire.
************************************************************/
function polygone_gps_2_array_pts($liste_points)
{
    // on met tout dans un premier tableau � la suite
    $tableau_brut=explode(",",$liste_points);
    
    //on v�rfie qu'on a bien un nombre pair et non nul de coordonn�es
    //nul �a existe m�me pour le n�0 qui sert actuellement � placer les points "non situ�s" ou en vall�e
    $nombre_elements=count($tableau_brut);
    if ( (round($nombre_elements/2)*2)!=$nombre_elements OR $nombre_elements==0)
        return NULL; // et non on a un nombre impair de coordonn�es inutile de rendre un tableau, �a n'aurait pas de sens
    for ($i=0;$i<$nombre_elements/2;$i++) // on rentre x et y a chaque passage donc le nombre de boucle � faire c'est $nombre_elements/2
    {
        $tableau_final[$i]->x=$tableau_brut[2*$i]; // l'element 2 x i c'est la coordonn�e en x du ieme point
        $tableau_final[$i]->y=$tableau_brut[2*$i+1]; // l'element 2 x i +1 c'est la coordon�e en y du ieme point
    }
return $tableau_final;
}

// fonction interne de test de l'appartenance d'une coordonn�e � un segment
function test_segment($a,$b,$atester)
{
    if ($a<$b)
    {
        if ( ($atester>=$a)&&($atester<=$b) )
            return 1;
    }
    else
    {
        if ( ($atester<=$a)&&($atester>=$b) )
            return 1;
    }
return 0;
}

//**********************************************************************************************
//* Nom de la fonction:    | is_intersection                                                   *
//* Date :                 |                                                                   *
//* Cr�ateur :             |                                                                   *
//* R�le de la fonction:   | Premi�re fonction avec des maths, elle determine si deux segments *
//*                        | sont s�cants: soit [($x1,$y1),($x2,$y2)] un premier segment S12   *
//*                        | soit [($x3,$y3),($x4,$y4)] un deuxi�me segment S34.               *
//*                        | cette fonction retourne 1 si il existe un point A qui appartient  *
//*                        | a S12 et S34, 0 sinon. ATTENTION BUG un bug peut se produire quand*
//*                        | un des segments est vertical (division par 0).                    *
//*                        |                                                                   *
//*------------------------|-------------------------------------------------------------------*
//* Param�tres(Nom E/S)    | R�le                                                              *
//*------------------------|-------------------------------------------------------------------*
//* $x1,$y1,$x2,$y2    E   | premier segment                                                   *
//* $x3,$y3,$x4,$y4    E   | second  segment                                                   *
//*                        |                                                                   *
//*------------------------|-------------------------------------------------------------------*
//* Modifications(date Nom)| Elements modifi�s, ajout�s ou supprim�s                           *
//*------------------------|-------------------------------------------------------------------*
//* 21/03/06 rff           |corr. anomalie: gestion des segments de polygone verticaux         *
//*                        |                                                                   *
//**********************************************************************************************

function is_intersection($x1,$y1,$x2,$y2,$x3,$y3,$x4,$y4)
{
/******* LES CAS PARTICULIERS POUR EVITER DIVISION PAR ZERO *****/

//21/03/06 rff: cas particulier de 2 segments verticaux : ils sont parall�les!!
if (($x1==$x2) && ($x3==$x4)) return 0; // donc pas d'intersection
//10/06/08 sly: cas particulier de 2 segments horizontaux : ils sont parall�les!!
if (($y1==$y2) && ($y3==$y4)) return 0; // donc pas d'intersection

//21/03/06 rff: cas particulier le segment S12 est vertical
if ($x1==$x2)
{
// calcul du point d'intersection
// �quation de S12 : x=a12 et �quation de S34 : y=a34*x+b34
  $a34=($y3-$y4)/($x3-$x4);
  $y=$a34*($x1-$x4)+$y4;
  $x=$x1;
  $res=test_segment($y3,$y4,$y)&&test_segment($x3,$x4,$x)&&test_segment($y2,$y3,$y);
  return $res;
}

//21/03/06 rff: cas particulier le segment S34 est vertical
if ($x3==$x4)
{
// calcul du point d'intersection
// �quation de S34 : x=a34 et �quation de S12 : y=a12*x+b12

  $a12=($y1-$y2)/($x1-$x2);
  $y=$a12*($x3-$x1)+$y1;
  $x=$x3;
  $res=test_segment($y1,$y2,$y)&&test_segment($x1,$x2,$x)&&test_segment($y3,$y4,$y);
  return $res;
}
/******* CAS GENERAL *****/

// etape 1, retour en troisi�me, calcul  du point d'intersection des droites
// de souvenir Y=aX+b et apr�s plein de calculs �a doit faire un truc genre :
$a12=($y1-$y2)/($x1-$x2); // si division par z�ro ici voir commentaire ci-dessus
$b12=$y1-$a12*$x1;
$a34=($y3-$y4)/($x3-$x4);// si division par z�ro ici voir commentaire ci-dessus
$b34=$y3-$a34*$x3;
// la on doit obtenir les coordonn�es du point d'intersection des deux droites
$x=($b34-$b12)/($a12-$a34);
$y=$a12*$x+$b12;

// testons ce point trouv� pour voir si il appartient au segments maintenant
$res=test_segment($x1,$x2,$x)&&test_segment($x3,$x4,$x)&&test_segment($y1,$y2,$y)&&test_segment($y3,$y4,$y);
return $res;

}


//**********************************************************************************************
//* Nom de la fonction:    | is_point_dans_polygone                                            *
//* Date :                 |                                                                   *
//* Cr�ateur :             |                                                                   *
//* R�le de la fonction:   | 2e fonction avec des maths, voici la fonction qui d�termine si un *
//*                        | point appartient ou non � un massif. Pour l'utiliser, on donne    *
//*                        | les coordonn�es du point gps. L'algorithme est dit "de parit�     *
//*                        | d'intersection pour un point externe". Prenez une feuille,        *
//*                        | dessinez un polygone, prenez un point au hazard et tracez un      *
//*                        | segment partant du point pour aller jusqu'a un bord de votre      *
//*                        | feuille. Comptez le nombre d'intersection avec les arr�tes de     *
//*                        | votre polygone. Pair ? le point est dehors, impaire ? le point    *
//*                        | est dedans.                                                       *
//*                        |                                                                   *
//*------------------------|-------------------------------------------------------------------*
//* Param�tres(Nom E/S)    | R�le                                                              *
//*------------------------|-------------------------------------------------------------------*
//* $x_point           E   | longitude du point                                                *
//* $y_point           E   | latitude du point                                                 *
//* $tableau_massif    E   | tableau converti par la fonction polygone_gps_2_array_pts         *
//* $tolerance         E   | param tolerance : 0=pas de tolerance (par defaut)                 *
//*                        |                                                                   *
//*------------------------|-------------------------------------------------------------------*
//* Modifications(date Nom)| Elements modifi�s, ajout�s ou supprim�s                           *
//*------------------------|-------------------------------------------------------------------*
//* 21/03/06 rff           |intro param tolerance. Une tol�rance non nulle corrige le pb de    *
//*                        |tangeante au polygone qui est un cas particulier.                  *
//*                        |                                                                   *
//**********************************************************************************************

function is_point_dans_polygone($x_point,$y_point,$tab_polygone, $tolerance=0)
{
// quelques tests de s�curit�
if ( ($x_point==0 ) OR ( $y_point==0 ) OR ($tab_polygone==NULL) )
    return -1;
    $points_polygone=count($tab_polygone);

    //rff 21/03/06 : introduction recherche l�che (autour du point) : on d�finit un losange de 4 pts suppl�mentaires
    //dont tolerance  repr�sente  la distance du centre (d�fini par $x_point, $y_point) � chacun des 4 pts du losange.

    if ($tolerance==0)
       $nb_points = 1 ;
    else $nb_points = 5;

    for ($i_point=1;$i_point<=$nb_points;$i_point++)
    {
        switch  ($i_point) {
          case 1:
               $x=$x_point;
               $y=$y_point;
               break;
          case 2:
               $x=$x_point+$tolerance;
               $y=$y_point;
               break;
          case 3:
               $x=$x_point-$tolerance;
               $y=$y_point;
               break;
          case 4:
               $x=$x_point;
               $y=$y_point+$tolerance;
               break;
          case 5:
               $x=$x_point;
               $y=$y_point-$tolerance;
               break;
        }

        $nb_intersection=0;

        for ($i=0;$i<$points_polygone-1;$i++)
        { // on test les n-1 premiers segments,( [01] [12] .... [(n-1)n]
           $nb_intersection+=is_intersection($x,$y,0,0,$tab_polygone[$i]->x,$tab_polygone[$i]->y,$tab_polygone[$i+1]->x,$tab_polygone[$i+1]->y);
        }

        // et on ferme la boucle ici pour le segment du dernier point au premier : segment [n0]
	// on pourrait tout mettre dans la m�me boucle, mais ce ne serait pas joli � lire ;-) sly
        $nb_intersection+=is_intersection($x,$y,0,0,$tab_polygone[0]->x,$tab_polygone[0]->y,$tab_polygone[$points_polygone-1]->x,$tab_polygone[$points_polygone-1]->y);

        if (round($nb_intersection/2)*2!=$nb_intersection)
           return TRUE;
    }//end for $i

    if (round($nb_intersection/2)*2==$nb_intersection)
       return FALSE;
}



/************************************************************
Cette fonction, profitant de toute les autres, mets � jour
pour un point la table d'appartenance polygone pour lui

Elle prend environ 0.1s pour 400 polygones, il seront bon d'am�liorer encore
car m�me si pour un point �a va, lorsqu'il faut recalculer
les 2000 points de la base �a commence � faire long !
sly 02/11/2008
************************************************************/
function mettre_a_jour_appartenance_point($id_point)
{
connexion_base();
global $config;
$infos_point=infos_point($id_point);
$query_polygones_potentiels="
	SELECT polygones.id_polygone
	FROM polygones,lien_polygone_gps,points_gps
	WHERE
	polygones.id_polygone=lien_polygone_gps.id_polygone
	AND
	lien_polygone_gps.id_point_gps=points_gps.id_point_gps
	GROUP BY polygones.id_polygone
	HAVING 
	(max(latitude)>$infos_point->latitude AND min(latitude)<$infos_point->latitude 
	AND max(longitude)>$infos_point->longitude AND min(longitude)<$infos_point->longitude)";
$res_poly_pot=mysql_query($query_polygones_potentiels) or die($query_polygones_potentiels);

// on enl�ve les anciens
mysql_query("DELETE FROM appartenance_polygone WHERE id_point_gps=$infos_point->id_point_gps");
// balayage de la liste des polygones candidats pour ce point
while($poly_possible=mysql_fetch_object($res_poly_pot))
{
	if (is_point_dans_polygone($infos_point->longitude,$infos_point->latitude,tableau_polygone($poly_possible->id_polygone)))
	{// il est dedans ce polygone !
		$query_insert="INSERT INTO appartenance_polygone 
				set id_point_gps=$infos_point->id_point_gps,
				id_polygone=$poly_possible->id_polygone";
		mysql_query($query_insert);
	}
}
unset($infos_point);
mysql_free_result($res_poly_pot);
return TRUE;
}
/***********************************************************************************
Cette fonction permet d'aller chercher toutes les infos d'un polygone
- Elle prend en param�tre l'id du polygone
- Elle renvoi un objet contenant :
*nom_polygone
*l'article partitif du polygone ( "de la" chartreuse ou "des" bauges...) pour un polygone 'massif'
*etc...
******************************************************************/
function infos_polygone($id_polygone)
{
 connexion_base();

 $sql_query_polygone="SELECT *
     FROM polygone_type LEFT JOIN polygones
     ON polygone_type.id_polygone_type = polygones.id_polygone_type WHERE id_polygone=$id_polygone";

 $rq_polygone=mysql_query($sql_query_polygone) or die("probl�me pour trouver le massif demand�");
 $infos_polygone=mysql_fetch_object($rq_polygone);

 mysql_free_result($rq_polygone);

 return $infos_polygone;
}

/********************************************
On g�n�re une url vers la carte d'un polygone
*********************************************/
function lien_polygone($nom_polygone,$id_polygone,$type="")
{
// sly 27/04/06 afin de pr�parer une url encore mieux au niveau r�f�rencement j'ajoute le type de polygone sur lequel on va centrer dans l'url
// option facultative, sinon ce sera "polygone" simplement
if ($type=="")
	$type="massif";
   return "/nav/".replace_url($type)."/$id_polygone/".replace_url($nom_polygone)."/";
}


/**************************************************
On g�n�re une url vers la carte d'un polygone � partir de son id
Attention c'est moins performant � ne pas trop utiliser
pour des longues listes ( car requete SQL oblige )
*************************************************/
function lien_polygone_lent($id_polygone)
{
  connexion_base();
  $rq_polygone=mysql_query("SELECT * FROM polygones,polygone_type
                					WHERE polygones.id_polygone_type=polygone_type.id_polygone_type 
							AND id_polygone=$id_polygone");
  if (mysql_num_rows($rq_polygone)!=1)
    return -1;
  // Recupere les donnees du massif concern�
  $polygone = mysql_fetch_object($rq_polygone);

  mysql_free_result($rq_polygone);

  return lien_polygone($polygone->nom_polygone,$id_polygone,$polygone->type_polygone);
}

?>
