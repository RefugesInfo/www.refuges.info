<?php
//**********************************************************************************************
//* Nom du module:         | fonctions_news.php                                                *
//* Date :                 |                                                                   *
//* Cr�ateur :             | sly                                                               *
//*------------------------|-------------------------------------------------------------------*
//* Modifications(date Nom)| Elements modifi�s, ajout�s ou supprim�s                           *
//*------------------------|-------------------------------------------------------------------*
//* 22/04/08 jmb	| modif de affiche_news, (bug des forums)  elle sert QUE dans news.php.
//* 04/07/08 jmb	modif de affiche news, forum, rajout de Post_id dans la requete, et chgt du lien forum
//				rajout du setlocale et d�placement dans un fichier config.php
//**********************************************************************************************


/****************************************
Fonction d'affichage de news
elle affiche :
- les commentaires ajout�s sur les points
- les points ajout�s avec un lien
- les news d'info g�n�rale sur le site
- les derniers messages sur les forums
- un mix (new)
- le titre de la liste (new) (pa pu faire autrement pour la liste)

elle prends 2 param�tres,$nombre news, categorie(s) de news a chercher 
les categories: s�par�es par "," comme "general" pour uniquement news general
    "forum,refuges" pour les nouveaux messages forum et les nouveaux refuges a la fois
    
Vu que j'ai voulu faire le malin dans les commentaires � ne plus utiliser le UNIX_TIME ( car ilisible )
j'ai donc cass� le fonctionnement de l'affichage des news.
Je serre les dents et je reprend le code de �a
au programme : ne pas demander � mysql de g�n�rer du HTML !
maintenir l'id�e de tout regrouper dans un tableau qu'on tri ensuite
***************************************/

function affiche_news($nombre,$type,$rss=FALSE)
{
 global $config;
 // tableau de tableau contiendra toutes les news toutes cat�gories confondues
 $news_array = array() ;

 $tok = strtok($type, ",");// le s�parateur des types de news. voir aussi tt en bas
 while ($tok) // vrai tant qu'il reste une categorie a rajouter
 {
  switch ($tok) 
  {
    case "commentaires":
    $type_news="nouveau_commentaire";
    $query_news=
		"SELECT commentaires.auteur,points.id_point,
			points.nom,commentaires.id_commentaire,commentaires.photo_existe,
			UNIX_TIMESTAMP(commentaires.date) as date
        FROM commentaires, points
        WHERE
			commentaires.id_point = points.id_point
		ORDER BY commentaires.date DESC
        LIMIT 0,$nombre";
 	$r_select_news = mysql_query($query_news);
	while ($news = mysql_fetch_object($r_select_news))
	{
		$point=infos_point($news->id_point);
		$categorie="Commentaire";
		$lien=lien_point($point->nom,$point->massif->nom_polygone,$point->id_point,$point->nom_type)."#C$news->id_commentaire";
		$titre=$news->nom;
		$texte="<i>$categorie </i>";
		if ($news->photo_existe)
			$texte.="+<img src='/images/icones/photo.png' /> ";
		if ($news->auteur!="")
			$texte.="de $news->auteur ";
		$texte.="sur <a href='$lien'>
			$titre</a> 
			dans le massif 
			<a href='".lien_polygone($point->massif->nom_polygone,$point->massif->id_polygone,"massif")."'>
			".$point->massif->article_partitif."
			".$point->massif->nom_polygone."</a>";
		$news_array[] = array($news->date,"texte"=>$texte,
				"date"=>$news->date,"categorie"=>$categorie,
				"titre"=>$titre,"lien"=>$lien); 
	}	
	mysql_free_result($r_select_news);
   break;
 
	case "refuges": $conditions->type_point=$config['tout_type_refuge'];
	case "points":
	$conditions->ordre="date_insertion DESC";
	$conditions->limite=$nombre;
	$conditions->avec_infos_massif=1;
	$points=liste_points($conditions);
	while($point=mysql_fetch_object($points->resultat))
	{
		$categorie="Ajout $point->article_partitif_point_type $point->nom_type";
		$lien=lien_point($point->nom,$point->nom_polygone,$point->id_point,$point->nom_type);
		$titre=$point->nom;
		$texte="$categorie : 
			<a href='$lien'>$titre</a>
			Dans le massif $point->article_partitif
			<a href='".lien_polygone($point->nom_polygone,$point->id_polygone,$point->type_polygone)."'>$point->nom_polygone</a>";
		$news_array[] = array($point->date_insertion,"texte"=>$texte,
				"date"=>$point->date_insertion,"categorie"=>$categorie,
				"titre"=>$titre,"lien"=>$lien); 
	}
   break;
    
    case "general":
    $query_news=
		"SELECT UNIX_TIMESTAMP(date) as date,
			id_commentaire,
			texte
		FROM commentaires
		WHERE
			commentaires.id_point = ".$config['numero_commentaires_generaux']."
		ORDER BY date DESC
		LIMIT 0,$nombre";
	$r_select_news = mysql_query($query_news);
	while ($news = mysql_fetch_object($r_select_news))
	{
		$categorie="G�n�rale";
		$titre=$news->texte;
		$texte="<i>$titre</i>";
		$lien="/news.php";
		$news_array[] = array($news->date,"texte"=>$texte,
				"date"=>$news->date,"categorie"=>$categorie,
				"titre"=>$titre,"lien"=>$lien); 
	}	
	mysql_free_result($r_select_news);
    break;
  
    case "forums":
	$type_news="nouveau_message_forum";
// Il y avait aussi �a mais je ne sais pas pourquoi ? sly 02-11-2008
//AND phpbb_topics.topic_first_post_id < phpbb_topics.topic_last_post_id
    $query_news=
		"SELECT
			max(phpbb_posts.post_time) AS date,
			phpbb_posts.topic_id,
			phpbb_topics.topic_title,
			phpbb_posts_text.post_text AS texte,
			max(phpbb_posts_text.post_id) AS post_id
		FROM phpbb_posts_text, phpbb_topics, phpbb_posts
    		WHERE
		phpbb_topics.topic_id = phpbb_posts.topic_id
		AND phpbb_posts_text.post_id = phpbb_posts.post_id
		GROUP BY topic_id
		ORDER BY date DESC
		LIMIT 0,$nombre";
	$r_select_news = mysql_query($query_news);
	while ($news = mysql_fetch_object($r_select_news))
	{
		$lien="/forum/viewtopic.php?p=$news->post_id#$news->post_id";
		$categorie="Sur le forum";
		$titre=$news->topic_title;
		$texte="$categorie : <a href='$lien'>$titre</a>";
		$news_array[] = array($news->date,"texte"=>$texte,
				"date"=>$news->date,"categorie"=>$categorie,
				"titre"=>$titre,"lien"=>$lien); 
	}
  	mysql_free_result($r_select_news);

		// 		AND (points.id_point_type=7 OR points.id_point_type=9 OR points.id_point_type=10)
    break;

    default:
	break;

  }


$tok = strtok(","); 
}

// ici je trie par ordre d�croissant toutes les news confondues
rsort($news_array);

 // AFFICHAGE
if (!$rss)
{
	for ($i = 0; $i < $nombre; $i++)
	{ // �videment pas de miracles, avant on pr�parait le format plus haut maintenant c'est ici !
		print("\n<li><em>".date("d/m/y", $news_array[$i]['date'])."</em>&nbsp;");
		print($news_array[$i]['texte']."</li>");
	
	}
// et le reste du tableau ben il sert a rien...
return 0;
}
else
	return $news_array;
}

?>
