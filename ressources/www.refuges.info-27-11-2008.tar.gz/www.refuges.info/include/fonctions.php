<?php
//**********************************************************************************************
//* Nom du module:         | fonctions.php                                                     *
//* Date :                 |                                                                   *
//* Cr�ateur :             | sly                                                               *
//* R�le du module :       | Voici un nouveau fichier qui va nous servir � ajouter les         *
//*                        | diff�rentes fonctions utiles � tout le site. j'�sp�re regrouper   *
//*                        | au f�r et � mesure toutes les fonctions sp�cifiques.              *
//*                        | Au moins ce sera propre. sly                                      *
//*                        |                                                                   *
//*                        | Changement l�ger de politique, maintenant j'essaye de vider ce    *
//*                        | Fichier pour mieux r�partir dans des fichiers fonctions_truc.php  *
//*------------------------|-------------------------------------------------------------------*
//* Modifications(date Nom)| Elements modifi�s, ajout�s ou supprim�s                           *
//*------------------------|-------------------------------------------------------------------*
//* 10/03/06 rff           |-Affichage l�gende de la vignette chang� pour affichage Firefox.   *
//*                        |-R�arrangement de la construction HTML.                            *
//*                        |-Correction bug pointage des 'points' de la vignette sur latitudes *
//*                        | basses.                                                           *
//* 21/03/06 rff           |-Intro var. conf: $config['polygone_massif']="Massifs"             *
//*                        |-Intro var. conf: $config['tolerance_bordure_massif']=0.001        *
//*                        |-les proc�dures lien_massif & lien_massif_lent sont renomm�es en   *
//*                        | lien_polygone & lien_polygone_lent                                *
//* 15/04/07 jmb           |-rajout de config[point type par defaut] pour point_formulaire_modification,
//*                        |-corrections diverses pour XHTML 1
//*                        |-presentationgeneralpoint: ajout auteur
//*                        |                                                                   *
//* 22/04/08 jmb	| modif de affiche_news, (bug des forums)  elle sert QUE dans news.php.
//* 04/07/08 jmb	modif de affiche news, forum, rajout de Post_id dans la requete, et chgt du lien forum
//				rajout du setlocale et d�placement dans un fichier config.php
//**********************************************************************************************


// jmb: pour suivre l'idee de sly: on deplace la conf
require($_SERVER["DOCUMENT_ROOT"] . "/include/config.php");

/****************************************
Fonction g�n�rique de connexion � la base
elle renvois un lien de connexion vers mysql
***************************************/
function connexion_base()
{
    $mysqlserver = 'localhost' ;
    $mysqluser = '';
    $mysqlpass = '';
    $mysqldb = '';
$link_mysql = mysql_connect ($mysqlserver,$mysqluser,$mysqlpass) or die("pb a la connection mysql");
mysql_select_db($mysqldb);
return $link_mysql;
}
/****************************************
Fonction de suppression des accents
***************************************/
function retrait_accents($str)
{
return (strtr($str,"�����������������������������������������������������'",
                      "AAAAAAaaaaaaOOOOOOooooooEEEEeeeeIIIIiiiiUUUUuuuuyNnCc "));
}

/****************************************
Fonction d'aide au r�f�rencement
les "-" c'est biens
***************************************/
function replace_url($str)
{
    $str = retrait_accents($str);
    $str = preg_replace('/[^a-z0-9_\.\s]/',' ',strtolower($str));

    $str = preg_replace('/[^a-z0-9_\s]\./','',trim($str));
    $str = str_replace('. ',' ',$str);
    $str = preg_replace('/[\s]+/','-',$str);

    return $str;
}

/****************************************
Fonction qui �crit en TIMESTAMP une
date venant JJ/MM/AAAA hh:mm:ss
***************************************/
function date_jjmmaaaa2TS($date_fr)
{
	//-----------------------
	// remplace la fonction strtotime, qui reconnait MM/JJ/AAAA
	list($jour, $mois, $annee, $heure, $minute) = split('[/ :-]', $date_fr) ;
	$ts = mktime($heure, $minute, 59, $mois, $jour, $annee);
	return ( $ts );
}


function redimensionnement_photo($chemin_photo)
{
global $config;
    $image=imagecreatefromjpeg($chemin_photo);//on chope le jpeg
    $x_image= ImageSX($image); // coord en X
    $y_image= ImageSY($image); //coord en Y

        if (($x_image/$y_image)>=($config['largeur_max_photo']/$config['hauteur_max_photo']))
            $zoom1=$config['largeur_max_photo']/$x_image;
        else
            $zoom1=$config['hauteur_max_photo']/$y_image;

    $image2=imagecreatetruecolor($x_image*$zoom1,$y_image*$zoom1);
    imagecopyresampled ($image2, $image, 0,0, 0, 0,$x_image*$zoom1 ,$y_image*$zoom1,$x_image,$y_image);

    imagejpeg($image2,$chemin_photo);//,$config['qualite_jpeg']);
    ImageDestroy($image2);
    ImageDestroy($image);
}

// fonction de bloquage par IP ou DNS des internautes chiants ( moustique pour l'instant )
// ------ 
// securite anti-moustique ( moustique �tant le pseudo d'un illustre chieur habitant de lyon, qui ne fait que remplir des conneries
// sur le site.) Une solution de v�rouillage par login mot de passe pourrait �tre envisageable mais je suis
// d�sireux de garder la soumission anonyme comme fondamentale, je place ici un bloquage des wanadoo lyonnais
// ayant r�cement chang� de connexion internet, je bloque la nouvelle

function bloquage_internaute($code="")
{
// n'ayant pour l'instant plus de probl�me, je ne bloque plus personne sly 23/03/08
return 0;
// sinon, on refuse tout les gaoland
$hostname = gethostbyaddr($_SERVER['REMOTE_ADDR']);
if (ereg("^(.*)\.rev\.gaoland\.net$",$hostname))
	return -1;
else
	return 0;

}

// fonction qui renvoi un texte invitant � se connecter si l'utilisateur n'est pas connect� sur le forum
function avertissement_connexion()
{
global $config;
if (!isset($_SESSION['id_utilisateur']))
	$message_non_connecte=$config['message_non_connecte'];
else
	$message_non_connecte="";
return $message_non_connecte;
}

function lien_mode_emploi($page="index")
{
	return "/statique/mode_emploi.php?page=".$page;
}

?>
