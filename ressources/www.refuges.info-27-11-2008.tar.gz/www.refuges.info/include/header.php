<?php

//**********************************************************************************************
//* Nom du module:         | header.php                                                        *
//* Date :                 |                                                                   *
//* Cr�ateur :             |                                                                   *
//* R�le du module :       | Pr�paration de l'en-t�te des fichiers HTML renvoy�s au client.    *
//*                        |                                                                   *
//*------------------------|-------------------------------------------------------------------*
//* Modifications(date Nom)| Elements modifi�s, ajout�s ou supprim�s                           *
//*------------------------|-------------------------------------------------------------------*
//* 10/03/06 rff           |-balise d'alignement vertical  pour les images navigateur.         *
//* 21/03/06               |-modif pr�sentation HTML l�g�re                                    *
//* 12/12/07 jmb           |-rajout de xmlns:v="urn:schemas-microsoft-com:vml dans la balise HTML, pour IE et googlemaps.
//*                        | ca reste standard pour le reste. on a le droit d'ajouter un namespace au besoin.
//*                        |                                                                   *
//* 13/01/08 jmb           | ajout du body et du html special gmaps
//* 03/05/08 jmb           | ajout du don, suite a la demande forum                            *
//* 24/07/08 jmb	| chgt du bandeau depuis un background css vers un IMG, mise en place $if_pub (pas utilis�)
//**********************************************************************************************



//pr�paration en-t�te fichier type XHTML

echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\">\n";
echo "<html\n";
echo "    xmlns=\"http://www.w3.org/1999/xhtml\"\n";
echo "    lang=\"fr\"\n";
echo "    xml:lang=\"fr\"\n";
// header speciaux Gmaps et Gmaps pour IE
if (isset($config["gmaps_key"]))
	echo "    xmlns:v=\"urn:schemas-microsoft-com:vml\"\n";
echo ">\n\n";

echo "
 <head>
	<link type=\"text/css\" rel=\"stylesheet\" href=\"/include/style.css\" />
	$style_forum
	<title>\n";
if (!isset($titre_page))
        echo "refuges, cabanes et abris de montagne dans les alpes";
else
        echo $titre_page;
echo "</title>\n";
?>

 <link rel="shortcut icon" href="/images/favicon.ico" />
 <meta name="robots" content="all" />
 <meta name="robots" content="index,follow" />
 <meta http-equiv="content-type" content="text/html; charset=iso-8859-1" />
 <?=$if_javascript?>

<?php
if ($description=="")
    $description="Base de donnee de refuges, abris, gites, sommets et divers points en montagne ...avec cartes satellite, descriptions et coordonnees GPS";

echo "       <meta name=\"description\" content=\".$description.\" />\n";//modif rff 7/3/06 : passer par echo car balises php anciennes
echo "</head>\n\n";
?>

<!-- le body "onload" est chang� en fct de la variable PHP $if_onloadscript  , surtout pour gmaps-->
<body<?=$if_onloadscript?>>


<div style='height: 50px;
			background-image: url("/images/titrehorizontal_ete.png");
			background-repeat: no-repeat;
			background-position: top left;'>

<!--	<img style="vertical-align: middle;" src="/images/titrehorizontal2.png" alt="logo" />  -->
<?php
	if(isset($if_pub))
		echo $if_pub;
	else
		echo "<a href='/statique/don.php' style='text-decoration: underline; margin-left: 450px;'><strong>faire un don</strong></a>";
?>
</div>

<ul class="menu">
  <li><a href="/" title="Retour � la page d'accueil et la carte des massifs">Cartes</a></li>
  <li><a href='/nav.php?lat=45&amp;long=6&amp;zoom=9'>Vue Satellite</a></li>
  <li><a href="/statique/mode_emploi.php" title="Mode d'emploi du site, informations pour les gestionnaires et propri�taires de refuges">Mode d'Emploi</a></li>
  <li><a href="/news.php" title="Derni�res nouvelles du site et informations ajout�es sur les refuges">Nouvelles</a></li>
  <li><a href="/point_formulaire_recherche.php" title="Formulaire de recherche dans la base de donn�es de refuges">Recherche</a></li>
  <li><a href="/forum" title="Forums de discussion sur les refuges et sur la gestion communautaire du site">Forum</a></li>
  <li><a href="<?=$lien_gestion?>" title="Zone de gestion pour les mod�rateurs"><?=$texte_connexion?></a></li>
</ul>

<!--
<div class="page">
	 COMMENCEMENT DE LA PAGE, fin du header -->

