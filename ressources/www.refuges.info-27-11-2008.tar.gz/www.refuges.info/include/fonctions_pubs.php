<?php
//**********************************************************************************************
//* Nom du module:         | fonctions_pubs.php                                                         *
//* Date :                 |                       03/05/2008                                            *
//* Cr�ateur :             | jmb                                                            *
//* R�le du module :       | Pubs rotatives
//*------------------------|-------------------------------------------------------------------*
//* Modifications(date Nom)| Elements modifi�s, ajout�s ou supprim�s                           *
//*------------------------|-------------------------------------------------------------------*
//*22/05/2008 jmb	essai en basculant tout sur clickintext (au CPC, genre oxado/adsense)
// 31/05/08	jmb 	ajout du XML de clickintext (login yip-wri, mdp de la bdd)
// 11/07/08	jmb	la pub XML est maintenant dans le random des pubs, pour voir.
//**********************************************************************************************

//=============================================
// 2 fonctions:
//
// bandeau_publicitaire  :   affiche la pub ClickInText ou autre, contextuelle. au hasard.
//
// bandeau_publicitaireXML   :  affiche la pub ClickInText via le flux XML, avec des motclefs
//=============================================

//===============================================
// affichage du bandeau plublicitaire ( google ou oxado ou autre ou ClickinText )
// mode par d�faut "normal" = large 4 pubs
function bandeau_publicitaire($taille = "normal")
{
	// pub google
	// 13/06/07 sly, ayant �t� banni de google il y a au moins un an,
	// je laisse une trace ici des fois que, mais �a risque bien de sauter un jour

	// 13/06/07 sly, les pubs oxado ne rapportant que peanuts ( 2-3 euros /mois ) je tente de changer encore un fois
	// s�rieux �a me saoul, c'est mon dernier essais avant le "no pub" et se sera mieux comme �a

	// 13/06/07 bon et ben voil�, c'est fini ! nadinoumouk, click4france c'est de la pire daube en flash, manquait plus que �a
	// je vire tout, et fini les pubs jusqu'a ce qu'une solution sorte du lot

	// bon, on y retourne, il faudra bien un jour que nous nous remboursions une certaine somme importante perdue.

	// pour yip  si tu me lis: si je trouve un truc qui rapporte (enfin!) un peu on fera moitier/moitier comme convenu
	// sly 31/10/2007

	// retour donc chez oxado

	// 02/2008 jmb: re essai chez google
	// 03/2008 jmb : re banni juste avant qu'ils paient...
	
	//====================================================================//
	//======================= GOOGLE ADSENSE encul�s ====================//

	if ( $taille=="petit") // google_ad_slot = '0374462036';
		$google_ad_type="
			google_ad_slot = '0374462036';
			google_ad_width = 468;
			google_ad_height = 60;
		";
	elseif ($taille=="normal")
		$google_ad_type="
			google_ad_slot = '7206588061';
			google_ad_width = 728;
			google_ad_height = 90;
		";

	$pub_google="
		<script type='text/javascript'>
			google_ad_client = 'pub-4530275603907691';
			/* bandeau horizontal TEXTE */
			$google_ad_type
		</script>
		<script type='text/javascript'
			src='http://pagead2.googlesyndication.com/pagead/show_ads.js'>
		</script>
	";

	//====================================================================//
	//========================OXADO======================//
	// 08/02/2008 jmb: passage en minuscule et je vire "language=" pour etre conforme Xhtml strict
	// adresse : https://admin.oxado.com/
	// j'ai l'impression que c'�tait moins pire que click-text... essai sly 05/10/2008
	// les gains oxado depuis le d�but s'�l�vent � 100.36 euros ( cf admin oxado )
	if ($taille=="normal")
		$pubs[]='<script type="text/javascript" src="http://pub.oxado.com/insert_ad?pub=131634"></script>';
	else 
		$pubs[]='<script type="text/javascript" src="http://pub.oxado.com/insert_ad?pub=131590"></script>';


	return $pubs[array_rand($pubs)];
}

//==================================================
// affiche des pubs en fct des motclefs.
//voir le fichier des motclefs dans /include/, ou en donner en parmaetre
// nb annonces, 2 par defo
// CLICKINTEXT uniquement. login yip-wri, modepass habituel de la BDD
//-----------------------------------------
// motclefs doit etre un TABLO de motcles Possibles ! (la fct en prendra qu'un seul au pif)
function bandeau_publicitaireXML($nbannonces = 2, $motclefs = "", $hauteur=60, $largeur=300 )
{
	global $config;
	/*======================= ANNONCES XML ClickInTextt ==================*/
	//
	// Clickintext peut fournir des annonces en fct d'un mot cle, en XML.
	// ce script va les afficher.

	if( ! $motclefs )
	{ // il faut rechercher un motcle
		$fichiermotcles = $config['document_root']."/include/motcles_pub.txt";
		$motclefs = split("\n",@file_get_contents($fichiermotcles));
	}
	//==== conf de ClickIntext
	$ip = $_SERVER['REMOTE_ADDR'] ; // Clickintext demande l'IP du client ... pour son comptage
	

	/*-------------------------   FORMAT   XML    Unicode UTF8-----------------------------
		<results>
			<informations time="2008-05-22 22:59" query="refuge" numresults="1" exectime="254">
			</informations>
			<data>
				<result>
					<title>Pagesjaunes.fr: trouvez les refuges de montagne</title>
					<description>
						Les coordonn�es que vous cherchez sont sur pagesjaunes.fr : informations, plans d'acc�s et itin�raire personnalis� pour y aller. Pages Jaunes : source de r�ussites.
					</description>
					<image>http://image.espotting.com/fr/pagesjaunes(21).gif</image>
					<site>www.pagesjaunes.fr</site>
					<url>	
						http://fr.xml.clickintext.net/c/?k=%3D%3DAaLEjUiBQJAUUA8EgaF80Wv5gXLEGArNVMAEmAuFQYXdzC1YlMDAjVHRANDojAksgbIcWB2B1GWZFARcgQUFTBGtAQS5CA2AAdBoTA3UQQbZjD4sQbAc2UEBgaCAWAtd1MLQkVzMwZWdEBnNQaCE2C4gwNFYDUqZFMA82B&go=http%3A%2F%2Fsearch.FR.miva.com%2Fsearch%2Fredirector.asp%3Furl%3Dhttp%253a%252f%252fwww.pagesjaunes.fr%252ftrouverlesprofessionnels%252frechercheClassique.do%253fquoiqui%253drefuge%252bde%252bmontagne%2526portail%253dmiva%26bidid%3D604179344%26searchguid%3D%25D5%25AB%2587%259B%2586%25E0%259D%25E8%2593%25BE%258D%25BD%25EA%25D3%25EE%25F1%25DE%25B0%25EC%25AD%25D8%25E8%25FD%25A8%25AE%2599%25B6%25D7%2594%25E0%2585%25C1%25EE%25E8%25FA%259A%26domain%3DFR%26affiliateid%3D2020%26position%3D1%26query%3Drefuge%26searchdate%3D22%2BMay%2B2008%2B21%253a59%253a15%253a07%26edh%3D0SGCUr2XMSCXmL4hV0ze%252b8b2BsY%253d%26ed%3Ddj0xJm10PTY%253d
					</url>
				</result>
				<...>
			</data>
		</results>
	------------------------------------------------------*/	
	// la syntaxe PHP simpleXML est donc $xmlobj->data->result[0]->title

	$i = 0 ; // protection au cas ou clickintext envoie de la merde, pour pas boucler a linfini
	do
	{
		$motcle = trim( $motclefs[array_rand($motclefs)] ) ; // on prends un motckef au pif
		$urlCiT = "http://fr.xml.clickintext.net/?v=1.0&a=5878&is=9948&ip=$ip&q=$motcle" ;
		//$listingxml = file_get_contents("$urlCiT") or die("Erreur lecture XML ClickInText: $urlCiT.");
	
		// attention, il faut que le module "simpleXML" soit activ� dans PHP5..... et on s'economise 100 lignes de code
		// incroyable ce que le parsing XML en php est compliqu�... 
		//$xmlobj = new SimpleXMLElement($listingxml);
		
		//$xmlobj = simplexml_load_file($urlCiT);
		$xmlobj = simplexml_load_file($urlCiT, $quedale, LIBXML_NOWARNING | LIBXML_NOERROR);
		
		$nbresultats = (int) $xmlobj->informations['numresults'];
		$i++;
	} while( (! $nbresultats) && $i < 4 );


	if ($nbresultats) // on a au moins 1 annonce .....
	{
		//converti l'OBJ en array , pour pouvoir le melanger
		foreach ( $xmlobj->data->result as $xmlannonce )
			$tabloannonces[] = $xmlannonce ;
	
		shuffle($tabloannonces) ; // pour varier les pub ...
		//on coupe le tablo au nb d'annonces max, ou nb d'annonce trouv�es, le plus faible:
		$tabloannonces = array_slice($tabloannonces, 0, min( $nbannonces, $nbresultats), TRUE ) ;
	
		$pubXML = "
			<!-- PUBLICITE motclef: $motclef , nb tentative: $i -->
			<table class='pub'>
				<tr>
					<td><img src='/images/pub/liens_sponso_vertic.gif' alt='pub'></td>
		";

		//$largeurannonce = round( $largeurbandeau / count($tabloannonces) ) ;
		foreach ( $tabloannonces as $xmlannonce )
		{
			$annonce['titre'] = trim(utf8_decode($xmlannonce->title));
			$annonce['image'] = trim(utf8_decode($xmlannonce->image));
			$annonce['description'] = trim(utf8_decode($xmlannonce->description));
			$annonce['site'] = trim(utf8_decode($xmlannonce->site));
			$annonce['url'] = trim(utf8_decode($xmlannonce->url));

			$pubXML .= "
				<td>
					<div style='height: ".$hauteur."px; width: ".$largeur."px;'>
						<a href='".$annonce["url"]."' alt='" .$annonce["titre"]. "' onclick='window.open(this.href); return false;'>
							<img src='".$annonce["image"]."' />
							<span class='pubannonceur'>". $annonce["site"] ."</span>
							<span class='pubtitre'>". $annonce["titre"] ."</span>
							<br />
							<span class='pubdescri'>". $annonce["description"] ."</span>
						</a>
					</div>
				</td>
			";
		
		}
		$pubXML .= "
					</tr>
				</table>
			</div>
		";
		//echo $pubXML;
		//var_dump($tabloannonces);
		return $pubXML;
	} else {
		return FALSE;
	}
}
