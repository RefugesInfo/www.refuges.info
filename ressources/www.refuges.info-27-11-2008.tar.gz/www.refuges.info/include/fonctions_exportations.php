<?php

//**********************************************************************************************
//* Nom du module:         | fonctions_exportations.php                                        *
//* Date :                 |                                                                   *
//* Cr�ateur :             |                                                                   *
//* R�le du module :       |                                                                   *
//*                        | ensemble de fonctions utilisables pour exporter des points de la  *
//*                        | base dans diff�rents formats                                      *
//*------------------------|-------------------------------------------------------------------*
//* Modifications(date Nom)| Elements modifi�s, ajout�s ou supprim�s                           *
//*------------------------|-------------------------------------------------------------------*
//* 05/11/07 sly           | Et rangement dans des fonctions et modularisation du tout         *
//* 17/11/2007 jmb         | tvx compatibilit� feedvalidator.org, dans le but d'importer le    *
//*                        | format KML dans le nav sat                                        *
//*                        | modif fct c() et rajout de cette fct c() un peu partout           *
//*                        | rajout d'un ID dans Placemark                                     *
//*                        | passage des styles dans l'entete pour accelerer                   *
//* 27/11/2007 jmb         | entete GPX pass� de ISO-8859 a utf8                               *
//* 04/12/07 sly           | re-passage en iso-8859-1 pour le kml et le gpx                    *
//* 04/12/07 sly           | les formats gpx sont maintenant mieux support� un peu partout     *
//**********************************************************************************************

// fonction plus rapide pour convertir les caract�res "non xml-copain"
function c($contenu)
{
return (htmlspecialchars($contenu,ENT_NOQUOTES));
}

// retourne l'ent�te xml pour un kml de googleearth
function entete_kml()
{
// En-tete du fichier kml   
global $config;

$_xml_tete  ="<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?>
<kml xmlns=\"http://earth.google.com/kml/2.1\">
<Document>
	<name>refuges-info.kml</name>
	<description>Points provenants du site www.refuges.info</description>
	<open>1</open>
	<!-- Fin de l'entete KML ! -->
	<!-- Place a la liste des Styles : -->
";

	// recup la liste des icons. les styles sont ici, au debut, et sont appel� apr�s par chaque point,
	// ce devrait etre plus rapide que de les definir a chq fois
	$sql = "SELECT * FROM point_type";
	$resultat_sql=mysql_query($sql) or die("Erreur inconnue sur $sql");
	//$nombre_resultat=mysql_num_rows($resultat_total);
	while ($point_type=mysql_fetch_object($resultat_sql))
	{
        $lien_icone = "http://www.refuges.info".$config['url_chemin_icones'].$point_type->nom_icone . '.png';

		$_xml_tete .= "
	<Style id='icone_$point_type->id_point_type'>
		<IconStyle>
		<hotSpot x='0.5' y='0.5' xunits='fraction' yunits='fraction' />
		<scale>0.5</scale>
			<Icon>
				<href>$lien_icone</href>
				<x>64</x>
				<y>192</y>
				<w>32</w>
				<h>32</h>
			</Icon>
   		</IconStyle>
   	</Style>";
	}

	$_xml_tete .= "
	<!-- Fin des Styles ! -->
	<!-- Place a la liste des POINTS : -->";

	return $_xml_tete;
}

//retourne une entit� xml correspondante � un point
// $row est un objet contenant toute les propri�t�s du point
function placemark_kml($row)
{
global $config;
	 $lien_url = lien_point($row->nom,$row->nom_polygone,$row->id_point,$row->nom_type);
         //CAMERA : basique pour le moment, � am�liorer
         $lon_cam = $row->longitude+0.0002;     //on se decale un peu
         $lat_cam = $row->latitude+0.0008;
         $range_cam = $row->altitude + 5500; // on se place 5500mau dessus du point
         $tilt_cam  = 40;              // on prend de l'angle autour de la verticale
         $heading_cam  = 50;           // on prend de l'angle autour de l'horizontale
                  
         //Creation du XML pour un point 
         $_xml ="\n  <Placemark id='$row->id_point'>\n";

         $_xml .="    <name>".c($row->nom)." $row->altitude m </name>\n";
		 //$_xml .="<visibility>1</visibility>\n"; // c'est la checkbox de Googlearth. 1 par defo.
		 //$_xml .="<open>0</open>\n"; // C'est le "+" de googlearth This element applies only to Document, Folder. dixit la doc.
         $_xml .="    <description><![CDATA[
			<img src='http://www.refuges.info".$config['url_chemin_icones'].$row->nom_icone.".png' />
			(<em>".c($row->nom_type)."</em>) <br />
			<center><a href='$lien_url'>".c('D�tails')."</a></center>
			]]></description>\n";

         $_xml .= "    <LookAt>\n";
         $_xml .= "     <longitude>$lon_cam</longitude>\n";
         $_xml .= "     <latitude>$lat_cam</latitude>\n";
         $_xml .= "     <range>$range_cam</range>\n";
         $_xml .= "     <tilt>$tilt_cam</tilt>\n";
         $_xml .= "     <heading>$heading_cam</heading>\n";
         $_xml .= "    </LookAt>\n";

		 // pointeur vers l'icone defini dans l'entete
         $_xml .= "    <styleUrl>#icone_$row->id_point_type</styleUrl>\n";
         
         $_xml .= "    <Point>\n";
         $_xml .= "     <coordinates>$row->longitude,$row->latitude,0</coordinates>\n";
         $_xml .= "    </Point>\n";

         $_xml .= "   </Placemark>\n\n";
return $_xml;
}
// retourne une ligne d'export CSV
// avec $point �tant un objet disposant de toutes les caract�ristiques d'un point de la base
function csv_export_line($point)
{
$separateur=";";
$nom=str_replace($separateur,"\\".$separateur,$point->nom);
$nom_type=str_replace($separateur,"\\".$separateur,$point->nom_type);
$nom_polygone=str_replace($separateur,"\\".$separateur,$point->nom_polygone);
$nom_precision_gps=str_replace($separateur,"\\".$separateur,$point->nom_precision_gps);

$ligne=$point->id_point.$separateur.$nom.$separateur.$nom_type.$separateur.$nom_polygone;
$ligne.=$separateur.$point->altitude.$separateur.$point->latitude.$separateur.$point->longitude;
$ligne.=$separateur.$nom_precision_gps.$separateur.$point->places."\r\n";
return $ligne;
}
//retourne une ligne d'export au format csv pret pour les POI garmin ( Point Of Interest )
// le format de la ligne est :
// long,lat,nom,description
// 02.61444,45.07694,Buron de Cabrespine (Can,Acces : En flanc N de l'arete descendant de Cabres
// s�parateur ",", taille du champ nom 25 caract�res, taille du champ description 50 caract�res
function poi_export_line($point)
{
$separateur=",";
$nom=str_replace($separateur,"\\".$separateur,$point->nom);
$nom_type=str_replace($separateur,"\\".$separateur,$point->nom_type);

$nom_long=substr($nom."-".$nom_type,0,30);
$ligne=$point->longitude.$separateur.$point->latitude;
$ligne.=$separateur.substr($nom,0,10).$separateur.$nom_long."\r\n";
return $ligne;
}
//retourne l'ent�te g�n�rique du gpx
function entete_gpx()
{
$output='<?xml version="1.0" encoding="iso-8859-1" standalone="no"?>
<gpx xmlns="http://www.topografix.com/GPX/1/1" creator="refuges.info" version="1.1" 
    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" 
    xsi:schemaLocation="http://www.topografix.com/GPX/1/1 http://www.topografix.com/GPX/1/1/gpx.xsd">
<metadata>
	<name>refuge-info.gpx</name>
	<desc>Tout ou partie de la base de donn�e de point GPS de www.refuges.info, contenant des points d\'int�r�ts du massif des alpes</desc>
	<author>
		<name>Contributeurs refuges.info</name>
	</author>
	<copyright author="Contributeurs refuges.info">
		<year>2002</year>
		<license>http://creativecommons.org/licenses/by-sa/2.0/deed.fr</license>
	</copyright>
	<link href="http://www.refuges.info/">
		<text>http://www.refuges.info/</text>
		<type>text/html</type>
	</link>
</metadata>
';
return $output; 
}

// retourne un waypoint au format xml gpx
// la variable niveau permet de moduler la sortie
// pour l'instant il existe "garmin" et "complet"
// va savoir pourquoi le mode complet fait planter gpsbabel...
// GPX documentation : http://www.topografix.com/GPX/1/1/
function waypoint_gpx($point,$niveau)
{
// si le point GPS est mauvais on le vire
if ($point->latitude<-90 OR $point->latitude>90 OR $point->longitude<-180 OR $point->longitude>180 )
	return "";

if ($niveau=="complet")
{
$lien=lien_point($point->nom,$point->nom_polygone,$point->id_point,$point->nom_type);
$version_complete="
<cmt>Acces : ".c($point->acces)."</cmt>
<desc>".c($point->remark)."</desc>
<src>".c($point->nom_precision_gps)."</src>
<link href=\"$lien\">
	<text>".c($point->nom)." sur www.refuges.info</text>
	<type>text/html</type>
</link>
<type>".c($point->nom_type)."</type>
<extensions>
	<id_point>$point->id_point</id_point>
	<massif>".c($point->nom_polygone)."</massif>
	<id_massif>$point->id_massif</id_massif>
	<id_qualite_gps>$point->precision_gps</id_qualite_gps>
	<id_type_point>$point->id_point_type</id_type_point>
	<nombre_place>$point->places</nombre_place>
	<renseignements>".c($point->proprio)."</renseignements>
</extensions>";
$nom="$point->nom";
}
else if($niveau=="garmin")
{
$version_complete="
<cmt>".$point->altitude."m : ".c($point->acces)."-".c($point->remark)."</cmt>
<desc>".c($point->remark)."</desc>";
$nom="$point->nom ($point->nom_type)";
}


$waypoint="
<wpt lat=\"$point->latitude\" lon=\"$point->longitude\">
<ele>$point->altitude</ele>
<name>".c($nom)."</name>$version_complete
</wpt>
";

return $waypoint;
}

// retourne un MASSIF au format xml gpx
// la variable niveau permet de moduler la sortie
// pour l'instant il existe "garmin" et "complet"
// GPX documentation : http://www.topografix.com/GPX/1/1/
function massif_gpx($poly,$niveau)
{
	// seul le nivo complet est operationnel

	if ($niveau=="complet")
	{
		$aretes_poly = split(",",chaine_polygone($poly->id_polygone));
		while ( $aretes_poly )
		{
			//$coord = split(",", $pt);
			$version_complete .= "			<wpt lon='" . array_shift($aretes_poly) . "' lat='" . array_shift($aretes_poly) . "' />\r\n";
		}
	
		$massif="
<rte>
	<name>".c($poly->nom_polygone)."</name>
	<desc>Contour du massif</desc>
	<rtept>
$version_complete
	</rtept>
</rte>
";
	
		return $massif;
	
	} else {
		return "";
	}
}
?>
