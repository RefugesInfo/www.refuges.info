<?php
//**********************************************************************************************
//* Nom du module:         | config.php                                                     *
//* Date :                 |                                                                   *
//* Cr�ateur :             | jmb                                                               *
//* R�le du module :       | stocker la conf a part.         *
//*                        | ce fichier est appel� par fonctions.php (et c tout)         *
//*------------------------|-------------------------------------------------------------------*
//* Modifications(date Nom)| Elements modifi�s, ajout�s ou supprim�s                           *
//*------------------------|-------------------------------------------------------------------*
//* 04/07/08   jmb         | creation
//*------------------------|-------------------------------------------------------------------*


/*************************************************
Variables de configuration, plus propre qu'en dur
*************************************************/

// voici les mensurations des taille des photos afficher sur le site ( pour �viter une guirlande )
$config['largeur_max_photo']=700;
$config['hauteur_max_photo']=600;
$config['qualite_jpeg']=80;

//sly 27/04/06 quelques variable afin d'�viter de mettre des chemins un peu partout
$config['document_root']=$_SERVER['DOCUMENT_ROOT'];
$config['rep_web_photos_points']="/photos_points/";
$config['rep_photos_points']=$config['document_root'].$config['rep_web_photos_points']; 

$config['url_chemin_icones']="/images/icones/";
$config['chemin_icones']=$config['document_root'].$config['url_chemin_icones'];

//jmb 04/07 on continue avec des rep de moderation
$config['rep_moder_photos_backup']=$config['document_root']."/gestion/sauvegardes-photos/"; 
$config['rep_forum_photos']=$config['document_root']."/forum/photos-points/"; 
$config['rep_web_forum_photos']="/forum/photos-points/"; 

// sly  27/04/06 je pr�f�re me baser sur l'id pour le retrouver plut�t que son type ( que je viens d'ailleurs de modifier )
$config['id_massif']="1"; //rff 21/03/06 : nom officiel du type de polygone correspondant aux 'massifs'
$config['id_carte']="3"; //sly : nom officiel du type de polygone correspondant aux 'cartes papier'


// Cat�gorie "tout type de refuges"
// certes une gestion par cat�gorie directement dans la base serait pr�f�rable, mais on a au plus 1 ou 2 cat�gorie donc, bon,
// � la main dans la config : ( ce sont les id des refuges gard�s, non gard�s et gites
$config['tout_type_refuge']="7,9,10";

// ces trois variables sont les param�tes tels que on arrive � voir les alpes de l'ouest dans leur ensemble
//rff 10/03/06 : agrandir hauteur de 550 � 680
//rff 10/03/06 : d�placer y de 45.122 � 44.800
//rff 10/03/06 : d�placer �chelle de 550 � 600
//              ceci modifie le cache, ancien cache supprim� manuellement
$config['alpes_centre'] = array( "x" =>  6.5,"y" =>44.800 );
$config['alpes_pix_image'] = array( "width" => 500,"height" => 680);
$config['alpes_echelle'] = 600;

// les num�ros d'id sp�ciaux qu'on trouve dans les bases
// avec �a c'est une news g�n�rale
$config['numero_commentaires_generaux']=-2;
// �a, c'est le polygone "qui n'existe pas" et qui contient les points dans aucuns polygone de m�me type, 
// on pourrait appeler �a "la vall�e" pour les massif, le n�ant pour les cartes
$config['numero_polygone_fictif']=$config['numero_massif_fictif']=0;

//rff 21/03/06 : tol�rance point de massif en bordure de massif
$config['tolerance_bordure_massif']=0;//.001;//tol�rance point de massif en bordure

//nombre maximum de point que peut sortir la recherche
$config['max_points_recherche']=40;
// c'est l'id pour lequel les coordonn�es gps donn�es sont volontairement fausses
$config['id_coordonees_gps_fausses']=5;
// c'est l'id pour lequel les coordonn�es gps donn�es sont approximatives
$config['id_coordonees_gps_approximative']=4;
// des fois qu'on d�cide de re-bouger le forum, on ne le changera qu'ici
$config['lien_forum']="/forum/";
// lien direct pour se connecter, ou cr�er un compte sur le forum
$config['connexion_forum']=$config['lien_forum']."login.php";
// lien vers le profil d'un utilisateur
$config['fiche_utilisateur']=$config['lien_forum']."profile.php?mode=viewprofile&amp;u=";
$config['forum_refuge']=$config['lien_forum']."viewtopic.php?t=";
// message texte repris plusieur fois qui invite � se connecter
$config['message_non_connecte']="<p>Nous remarquons que <strong>vous n'�tes pas connect�</strong> sur le site ou le Forum.
Bien que nous autorisons les contributions anonymes, ils vous est fortement recommand� de vous connecter sur le forum et/ou de cr�er un compte
afin de pouvoir revenir faire des modifications ult�rieures <a href=\"".$config['connexion_forum']."\">Connexion</a></p>";


$config['message_licence']="
<p>
	L'information que vous allez rentrer <a href=\"".lien_mode_emploi("restriction_licence")."\">sera soumise � la licence creative commons by-sa</a>
</p>
";
$config['lien_syntaxe']="<a href=\"".lien_mode_emploi("syntaxe_bbcode")."\">Syntaxe possible</a>";

// indispensable pour avoir les affichage de date en french 
setlocale(LC_TIME, "fr_FR");
