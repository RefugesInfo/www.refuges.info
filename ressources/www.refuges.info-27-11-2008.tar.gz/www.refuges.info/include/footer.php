<?php
//**********************************************************************************************
//* Nom du module:         | footer.php                                                        *
//* Date :                 |                                                                   *
//* Cr�ateur :             |                                                                   *
//* R�le du module :       | Pr�paration du pied de page des fichiers HTML renvoy�s au client. *
//*                        |                                                                   *
//*------------------------|-------------------------------------------------------------------*
//* Modifications(date Nom)| Elements modifi�s, ajout�s ou supprim�s                           *
//*------------------------|-------------------------------------------------------------------*
//* 21/03/06               |-modif pr�sentation HTML l�g�re                                    *
//*                        |                                                                   *
//* 23/11/07      jmb         |-modif pour rajout de la valid W3C                                   *
//*03/08	jmb	| modif pub et don
// 05/04/08	jmb	modif mail en �, trop de spam
// 22/04/08	jmb	virage de la saloperie de pub google
//**********************************************************************************************

//------------
// fermeture cnx mysql
if (is_resource($mysqlink))
    mysql_close($mysqlink);

?>

<div id="basdepage"> <!-- Remplacement ici de certains blocs par des "inline" pour un meilleur affichage (jmb)-->

	<ul id="racourcismenus">
		<li><a href="/exportations/formulaire_exportations.php">Exportations</a></li>
		<!-- c'est pourri <li><a href="/statique/pret.php">Pr�cautions et conseils</a></li> -->
		<li><a href="/rss/choixrss.php">Flux RSS</a></li>
		<li><a href="/statique/mode_emploi.php?page=liens">Liens</a></li>
		<li><a href="/statique/mode_emploi.php?page=licence">Licence des contenus</a></li>
	</ul>

	<ul> <!-- liste des items de bas de page, boutons, liens ... en horizontal ! -->

		<li>
			<a id="mails" href="mailto:jm_@A@@_refuges_point_info">jm&nbsp;(�)&nbsp;refuges.info</a>
		</li>
		<li>
			<form action="https://www.paypal.com/cgi-bin/webscr" method="post">
				<div style='display: inline;'>
					<input type="hidden" name="cmd" value="_s-xclick" />
					<input type="image" src="https://www.paypal.com/fr_FR/FR/i/btn/btn_donate_LG.gif" name="submit" alt="Don pour le site refuges.info" />
					<input type="hidden" name="encrypted" value="-----BEGIN PKCS7-----MIIImQYJKoZIhvcNAQcEoIIIijCCCIYCAQExggEwMIIBLAIBADCBlDCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb20CAQAwDQYJKoZIhvcNAQEBBQAEgYCIQm/TGI8Xm9OK8nL0YcXrNO0/Hz02tt5RjWqmcI8IjhBs0bYOoQHhBeByThis31JLtWDM9AdxdREgthW8W818Vg1RXkoe46xcqvz6ty8E8T0gtdIC16mcnpclqayMKcx1RamOKr8KC3R2Eh9jZpLI7AkpGwHYQCVOUzqUq0fnNjELMAkGBSsOAwIaBQAwggIVBgkqhkiG9w0BBwEwFAYIKoZIhvcNAwcECNaskLh/8UoJgIIB8DhBLNGq8f2RFL04ImayBBIY7LCOs648sR4TF04nsBm1E/QQcZ11DCExvEVqkF9fRZsSKFOEyZcfcXQ202hdtvq0C9PGr3CSks8tyv35cuZqSmqBZphmwspfJcKwOyOJe4UWuLzlMa4tsQCmXg2Q+nXKSeRvM96Efd+HcX2zKTecAREZ2g2/BNGjC1yyn4Z8nHLLEF7sQvbZnH04x2s4020FdYj38DQF58ulG0ovfRftViGtIzwRoXgM8HC4UB0/g3Gv2pEDQ1IGANRt3UQlGnoEq1YxgTDRt0IN+LX98olGp94Xs7ze9B1Vmg2xepr3tmS9R8361OEPUuQt0Cr3ESncQ9dXGaXH7+OSiL/kk+tkM++NZIyZ2mhHmbXPtsFYvWZcFA5NnuuJk0bAPqQIQw5tfzGYUW3nOZfrbTjn0oXnQY3MVMhh/cSwNx8uU+wru5I61LNE8uvnS12oBtZSrzXZ/OP/K1B6Kbz3DsuHldyBBCag2uLhdVJYI0+/miNVIsqBkHtrhY4+FnevW0PYgRsz3amRma/OUnONg/lafwKONllmnhTFOKjFRd+Bz0obMwfUfHsA6dxfXx/YFM0XSYI2+7aThwfGQ64gOazWfYZZC8rPJRYZPeL6GqQtrh9LnieATSPUVj++Y/jT/9pniwygggOHMIIDgzCCAuygAwIBAgIBADANBgkqhkiG9w0BAQUFADCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb20wHhcNMDQwMjEzMTAxMzE1WhcNMzUwMjEzMTAxMzE1WjCBjjELMAkGA1UEBhMCVVMxCzAJBgNVBAgTAkNBMRYwFAYDVQQHEw1Nb3VudGFpbiBWaWV3MRQwEgYDVQQKEwtQYXlQYWwgSW5jLjETMBEGA1UECxQKbGl2ZV9jZXJ0czERMA8GA1UEAxQIbGl2ZV9hcGkxHDAaBgkqhkiG9w0BCQEWDXJlQHBheXBhbC5jb20wgZ8wDQYJKoZIhvcNAQEBBQADgY0AMIGJAoGBAMFHTt38RMxLXJyO2SmS+Ndl72T7oKJ4u4uw+6awntALWh03PewmIJuzbALScsTS4sZoS1fKciBGoh11gIfHzylvkdNe/hJl66/RGqrj5rFb08sAABNTzDTiqqNpJeBsYs/c2aiGozptX2RlnBktH+SUNpAajW724Nv2Wvhif6sFAgMBAAGjge4wgeswHQYDVR0OBBYEFJaffLvGbxe9WT9S1wob7BDWZJRrMIG7BgNVHSMEgbMwgbCAFJaffLvGbxe9WT9S1wob7BDWZJRroYGUpIGRMIGOMQswCQYDVQQGEwJVUzELMAkGA1UECBMCQ0ExFjAUBgNVBAcTDU1vdW50YWluIFZpZXcxFDASBgNVBAoTC1BheVBhbCBJbmMuMRMwEQYDVQQLFApsaXZlX2NlcnRzMREwDwYDVQQDFAhsaXZlX2FwaTEcMBoGCSqGSIb3DQEJARYNcmVAcGF5cGFsLmNvbYIBADAMBgNVHRMEBTADAQH/MA0GCSqGSIb3DQEBBQUAA4GBAIFfOlaagFrl71+jq6OKidbWFSE+Q4FqROvdgIONth+8kSK//Y/4ihuE4Ymvzn5ceE3S/iBSQQMjyvb+s2TWbQYDwcp129OPIbD9epdr4tJOUNiSojw7BHwYRiPh58S1xGlFgHFXwrEBb3dgNbMUa+u4qectsMAXpVHnD9wIyfmHMYIBmjCCAZYCAQEwgZQwgY4xCzAJBgNVBAYTAlVTMQswCQYDVQQIEwJDQTEWMBQGA1UEBxMNTW91bnRhaW4gVmlldzEUMBIGA1UEChMLUGF5UGFsIEluYy4xEzARBgNVBAsUCmxpdmVfY2VydHMxETAPBgNVBAMUCGxpdmVfYXBpMRwwGgYJKoZIhvcNAQkBFg1yZUBwYXlwYWwuY29tAgEAMAkGBSsOAwIaBQCgXTAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqGSIb3DQEJBTEPFw0wODAzMDgxOTMyMTNaMCMGCSqGSIb3DQEJBDEWBBT7gII1ygZVCwMfNwW5PXv+MLFrDTANBgkqhkiG9w0BAQEFAASBgLWPeGNg45NsPS5vBU59Q6XhM7yldHCie8dZVxFJ9xcJRvXB07bLX40cgMFUEw1NCdrcY5mrbBOrNTcx1BZjmGQTQ15QgRvGsWsaYrG+Jx6WA3FWiv5CvRphyplvx4tBsBL3eKDglM0c1e2YIXXAqiWyIsXjabBOBxI0c3cxRvGu-----END PKCS7-----" />
				</div>
			</form>
			<a href="/statique/don.php">Pourquoi ?</a>
		</li>
		<li>
			<a href="http://validator.w3.org/check?uri=referer">
				<img
					src="/images/valid-xhtml10-blue.png"
					alt="Valid XHTML 1.0 Strict"
					height="31"
					width="88" />
			</a>
		</li>

	</ul>


</div> <!-- fin du basdepage -->


<!--</div> fin de la page ENTIERE -->

</body>
</html>