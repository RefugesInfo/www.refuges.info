<?php
//**********************************************************************************************
//* Nom du module:         | fonctions_autoconnexion.php                                       *
//* Date :                 |                                                                   *
//* Cr�ateur :             | sly                                                               *
//* R�le du module :       | fonctions de gestion  permettant de coupler le forum et le site   *
//*                        | Fichier � inclure si besoin d'auto-loger sur une page             *
//*                        | comme une session est d�marr�e, c'est � faire avant tout affichage*
//*                        |                                                                   *
//*                        | Afin de simplifier grandement la gestion des utilisateurs         *
//*                        | Il n'y a plus de table moderateur, le niveau de moderation        * 
//*                        | d'un utilisateur est r�cup�r�e dans la table phpbb_users          *
//*                        | Ensuite sont stock� dans la session ( accessible par toutes       * 
//*                        | les pages ):                                                      *
//*                        | $_SESSION['login_utilisateur']                                    *
//*                        | $_SESSION['password_utilisateur'] (en md5 )                       *
//*                        | $_SESSION['id_utilisateur'] ( celui de la table phpbb_users )     *
//*                        | $_SESSION['niveau_moderation'] ayant pour signification           *
//*                        | 0 = utilisateur normal                                            *
//*                        | 1 = mod�rateur g�n�ral du site                                    *
//*                        | 2 = programmeur du site                                           *
//*                        | 3 = administrateur du site                                        *
//*                        |                                                                   *
//*                        | REMARQUE :                                                        *
//*                        | En lisant ce code vous allez vous dire qu'il est dommage          *
//*                        | d'inclure si souvent dans les pages, la raison est qu'il          *
//*                        | faut v�rifier � chaque fois que l'utilisateur ne s'est pas        *
//*                        | d�connect� du forum.                                              *
//*                        | l'id�al serait s�rement de vider la session un niveau du forum    *
//*------------------------|-------------------------------------------------------------------*
//* Modifications(date Nom)| Elements modifi�s, ajout�s ou supprim�s                           *
//*------------------------|-------------------------------------------------------------------*
//* 29/08/2007 sly         | cr�ation initiale gestion de la connexion par cookie permanent    *
//* 03/09/2007 sly         | gestion du cas de la connexion temporaire par session phpBB       *
//* 14/09/2007 sly         | remplissage plus logique et plus complet de la session            *
//**********************************************************************************************

/*** 
	fonction de reconnaissance d'un utilisateur d�j� connect� sur le forum, on lui �pargne le double login 
	On peut �tre connect� � phpBB de deux fa�on :
	1) avec leur syst�me interne de session ( Ils-n'auraient pas pu faire comme tout le monde chez phpBB ?? )
	2) avec le cookie permanent
***/
// on vide les traces qu'on a sur l'utilisateur
function vider_session()
{
unset($_SESSION['login_utilisateur']);
unset($_SESSION['password_utilisateur']);
unset($_SESSION['id_utilisateur']);
unset($_SESSION['niveau_moderation']);
}
function auto_login_phpbb_users()
{
session_start();
$mysqlink=connexion_base();

// etape 1) v�rifions si la session est correct
// je suis s�r qu'au niveau s�curit� c'est pas top, mais franchement, qui irait pirater le compte d'un utilisateur du forum ?
if (isset($_COOKIE['phpbb2mysql_sid']))
{
	$query_connexion_temporaire="SELECT * FROM phpbb_sessions WHERE session_id='".$_COOKIE['phpbb2mysql_sid']."'";
	$res=mysql_query($query_connexion_temporaire);
	if (mysql_num_rows($res)==1)
	{
		$authentifie=TRUE;
		$user=mysql_fetch_object($res);
		$user_id=$user->session_user_id;
	}
	else
		$authentifie=FALSE;

}
if (!$authentifie AND isset($_COOKIE['phpbb2mysql_data']))
{
// Etape 2) si c'est une connexion de type permanente avec le cookie phpbb2mysql_data, on v�rifie que c'est bien lui
$phpbb_user_data=unserialize(stripslashes($_COOKIE['phpbb2mysql_data']));
if (!isset($phpbb_user_data['autologinid']) OR !isset($phpbb_user_data['userid']) )
	$authentifie=FALSE;
else
{
	$query_verif="SELECT * FROM phpbb_users where user_id=".$phpbb_user_data['userid']." AND user_password=\"".$phpbb_user_data['autologinid']."\"";
	$res=mysql_query($query_verif);
	if (mysql_num_rows($res)!=1 )
		$authentifie=FALSE;
	else
		{$user_id=$phpbb_user_data['userid'];$authentifie=TRUE;}
}
}
if (!$authentifie OR ($user_id==-1) )
// cet utilisateur n'est pas ou plus connu du forum phpBB ou alors connect� en anonyme sur le forum
	{vider_session();return FALSE;}
// allons chercher les infos de cet utilisateur
$query_infos="SELECT * FROM phpbb_users where user_id=$user_id";
$res=mysql_query($query_infos);

// �a ne devrait pas �tre possible puisqu'on � r�ussi � l'identifier, mais dans le doute
if (mysql_num_rows($res)!=1)
	{vider_session();return FALSE;}

$user=mysql_fetch_object($res);
/* on rempli notre session */

$_SESSION['password_utilisateur']=$user->user_password;
$_SESSION['login_utilisateur']=$user->username;
$_SESSION['id_utilisateur']=$user->user_id;


// Attention, Fusion des droit forum avec droit du site
// Sauf que phpBB utilise une classification pas croissante
// chez phpBB :
// 0 = rien
// 1 = admin
// 2 = mod�rateur
// chez nous :
// 0 = rien
// 1 = mod�rateur
// 2 = programmeur
// 3 = admin
// sly 16/10/2008
switch ($user->user_level)
{
	case 0:$_SESSION['niveau_moderation']=0;break;
	case 1:$_SESSION['niveau_moderation']=3;break;
	case 2:$_SESSION['niveau_moderation']=1;break;
// programmeur �a n'existe plus pour l'instant
}


return TRUE;
}

if (auto_login_phpbb_users())
{
	// ici se trouve une petite alerte marqu�e par une �toile indiquant que dans le menu gestion y'a du boulot pour les mod�rateurs
	// � regrouper � l'occassion dans une jolie fonction qui r�capitule les diff�rents besoin de mod�ration sly 24/03/2008
	$query="select * from commentaires
		where (demande_correction!=0) OR (qualite_supposee<0) LIMIT 0,1";
	$res=mysql_query($query);
	if (mysql_num_rows($res)!=0)
		$etoile=" *";

	$texte_connexion="Zone Gestion [".$_SESSION['login_utilisateur'].$etoile."]";
	$lien_gestion="/gestion/";
}
else
	{$texte_connexion="Se connecter";$lien_gestion=$config['lien_forum']."login.php";}
?>
