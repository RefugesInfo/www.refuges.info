<?php
//**********************************************************************************************
//* Nom du module:         | fonctions_gmaps.php                                             *
//* Date :                 |                  10/11/2007                                                 *
//* Cr�ateur :             |                 jmb                                                  *
//* R�le du module :       | Fonctions sp�cifiques google maps.                                    *
//*                        |                                                                   *
//*------------------------|-------------------------------------------------------------------*
//* Modifications(date Nom)| Elements modifi�s, ajout�s ou supprim�s                           *
//* 07/03/2008	jmb	Nettoyage, free results
//*------------------------|-------------------------------------------------------------------*
//**********************************************************************************************


$config["gmaps_key"]="ABQIAAAAoB95UD1QkB41lW_FQfqr0RQDREnAL82o3PpQIQAJ4vsi_z1IzBREkfr_eRXtdSpzaacqidgpsTNaog";

//==========================================================
// construit la legende de gauche du navigateur, est appel� par le nav
function GM_cree_legende_POI()
{
	global $config ; // pour "url_chemin_icones"
	$leg= "\n<fieldset><legend>Points</legend><ul>\n";
	
    // numero_point_type_fictif renvoie 1
	$q_select_type= "SELECT * FROM point_type ORDER BY importance DESC";
	$r_select_type= mysql_query($q_select_type) or die("mauvaise requete: $q_select_type");

	while ($ptype = mysql_fetch_object($r_select_type))
	{
		$url_icone=$config['url_chemin_icones'].$ptype->nom_icone.".png";
		$leg .= "
			<li>
			<label><input
						name='id_point_type[]'
						value='$ptype->id_point_type'
						type='checkbox'
						".(($ptype->importance > 62) ? "checked='checked'" : "" )."
						onclick=\"MAJ_carte(document.getElementsByName('id_point_type[]') );\"
						/>
				<img
					id='icone_$ptype->id_point_type'
					src='$url_icone'
					alt=\"icone de $ptype->nom_type\"
					/>
				$ptype->nom_type
			</label>
			</li>
	 ";
	}
	mysql_free_result($r_select_type);

	$leg .= "</ul></fieldset>\n";
	return $leg;
}

//===========================================
// La mise en place des icones se fait en 2 temps
// d'abord la creation des Image() javascript dans le header de la page
// puis la transformation de ces Image() en GIcon plus tard.
// pourkoi ?  googlemaps necessite des images deja charg�es pour pouvoir afficher les icones....
// cette fct doit etre appelee dans le HEADER html ...
function GM_cree_icones_points()  // en fait cree les Image pas les icones
{
	global $config ;  // pour "url_chemin_icones"
	$leg="\n //liste des icones\n";
	$leg.="\n var icones = new Array(); // stockera les GIcon plus tard (qd la page sera chargee)";
	$leg.="\n var images = new Array(); // load les images tt de suite";

    // numero_point_type_fictif renvoie 1
	$q_select_type= "SELECT * FROM point_type ORDER BY importance DESC";
	$r_select_type= mysql_query($q_select_type) or die("mauvaise requete: $q_select_type");

	while ($ptype = mysql_fetch_object($r_select_type))
	{
		$url_icone=$config['url_chemin_icones'].$ptype->nom_icone.".png";
		$leg.="
			images[$ptype->id_point_type] = new Image();
			images[$ptype->id_point_type].src = '".$url_icone."' ;
		";
	}

	mysql_free_result($r_select_type);
	return $leg ;
}

//======================================================
// Cree un gros tablo JAVASCRIPT contenant la liste des massifs ou le massif pass� en param
// est utilis� par exemple sur la page d'accueil pour dessiner les polygones (tous les massifs)
// aussi sur le NAV pour dessiner le massif (idmassif = X)
function GM_cree_massifs($que_massif,$id_polygone="") {
	global $config ;

	if ($que_massif)
		$condition="id_polygone_type=".$config["id_massif"];
	else
		$condition="1=1";
	$q_select_mass= "SELECT *
					FROM polygones
					WHERE $condition";
			if ( $id_polygone )
				$q_select_mass .= " AND id_polygone IN ($id_polygone) ";
			else // si $id_polygone=0, on met tout
				$q_select_mass .= "	AND id_polygone > ".$config['numero_polygone_fictif'] ;

	$r_select_mass= mysql_query($q_select_mass) or die("mauvaise requete dans GMcreemassifs: $q_select_mass");

	$retour = "var listemassifs = new Array();" ;
	while ($massif = mysql_fetch_object($r_select_mass))
	{
		// d'abord , recuperer les sommets du polygon
		$retour .= "var aretes = new Array();\r\n" ;

		// r�cup�ration du polygone avec la nouvelle fonction sly 01/11/2008
		$polygone=tableau_polygone($massif->id_polygone);

		// cree toutes les arretes du massif en code Gmaps.
		foreach ($polygone as $sommet_polygone)
			$retour .= "	aretes.push( new GLatLng( $sommet_polygone->y, $sommet_polygone->x ) );\r\n" ;

		// et on remet la 1ere arete pour boucler le polygone (bug gmaps sinon)
		$retour .= "	aretes.push( new GLatLng( ".$polygone[0]->y.", ".$polygone[0]->x." ) );\r\n" ;

		// couleur attribu�e au hasard (c'est commode !)
		$couleur = "#".rand(10,99).rand(10,99).rand(10,99) ;

		// ne fait pas la gestion du click si on a demand� qu'un seul massif. c'est le navigateur, pas de click du massif
		if ( ! $id_polygone )
			$clic = "true" ;
		else
			$clic = "false" ;
		
		$retour .= "var massif = new GPolygon( aretes, '#000000', 1, 1, '$couleur', 0.3 , {clickable:$clic} ) ;\r\n" ;

		// COMPTAGE
		// pour chaque massif qu'on ajoute, fait aussi un comptage des refuges
		// un poil plus compliqu� avec le fait qu'un point puisse appartenir � plusieurs polygone mais bon :
		$query_massif="SELECT count(id_point)
				FROM points,appartenance_polygone,points_gps
				WHERE 
				appartenance_polygone.id_polygone=$massif->id_polygone	
				AND id_point_type IN ($config[tout_type_refuge])
				AND points.id_point_gps=points_gps.id_point_gps
				AND appartenance_polygone.id_point_gps=points_gps.id_point_gps";

		$nb = mysql_result($rq=mysql_query($query_massif),0);
		mysql_free_result ( $rq ) ;

		// variables du massif utilis� pour la cr�ation du bouton, plus tard en JS
		$retour .= "massif.mylink = \"".lien_polygone($massif->nom_polygone,$massif->id_polygone,"Massif")."\" ; \r\n";
		$retour .= "massif.nb_refuges = $nb ;\n";
		$retour .= "massif.nom = '".addslashes($massif->nom_polygone)."' ;\n";

		// on empile les massifs dans listemassifs
		$retour .= "listemassifs.push( massif ); \r\n" ;
	}

	// lib�re la boucle des massifs, listemassifs est plein. (avec un seul element si on est dans le nav)
	mysql_free_result ( $r_select_mass ) ;

	return $retour ; 
} 
?>