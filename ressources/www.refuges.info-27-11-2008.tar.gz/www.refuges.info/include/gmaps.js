//**********************************************************************************************
//* Nom du module:         | gmaps.js                                                          *
//* Date :                 |       11/2007                                                     *
//* Cr�ateur :             |          jmb                                                      *
//* R�le du module :       | fonctions diverses JAVASCRIPT pour google maps                    *
//*------------------------|-------------------------------------------------------------------*
//* Modifications(date Nom)| Elements modifi�s, ajout�s ou supprim�s                           *
//*------------------------|-------------------------------------------------------------------*
//* ../11/07 jmb           | v1.0                                                              * 
//*                        | creation ...                                                      *
//*			   | Attention: google maps repose sur l'exportation de GPX !          *
//*  20/10/2008            | Tentative d'ajout d'un fond de carte openstreet map               *
//**********************************************************************************************

// objet GMap2 (objet CENTRAL de google maps)
// Variable ULTRA globale.
// beaucoup de fonctions s'en servent tel quel
var map;

//----------------------------------------------------------------------------------
// fonction d�di�e nav.php avec le grand div qui contiend la map
function navigateur(div) {
	// initialise la carte google.
	// navigateur satellite UNIQUEMENT (j'ai essaye de regouper, pas reussi)
	
	// TODO: tester browser
	if ( ! GBrowserIsCompatible()) {
		alert("Selon Google, votre navigateur affichera mal les cartes. mais on va essayer quand m�me.");
	}

	//----------CREATION DE LOBJET MAP-------------------
	map = new GMap2(div);

	//---------- CHOPE LE BON FOND DE CARTE ------------------
	map.removeMapType(G_HYBRID_MAP); // Vire le type "Mixte"
	map.addMapType(G_PHYSICAL_MAP); // ajoute la possibilit� RELIEF (v2.94)
	//map.setMapType(G_PHYSICAL_MAP); // par defo, le type relief

/************* CODE SLY 20/10/2008 tentative d'ajout d'un fond de carte openstreetmap.org *********/

var copyCollection = new GCopyrightCollection('Topographique');
var copyright = new GCopyright(1, new GLatLngBounds(new GLatLng(-90, -180), new GLatLng(90, 180)), 10, "�openstreetmap.org and contributors");
copyCollection.addCopyright(copyright);

// help to add credit message to the map for osm would be appreciated !


var OSM = new GMapType(
	[ new GTileLayer(
		copyCollection,
		1, 
		17,
		{
			// osmarender
			//tileUrlTemplate: 'http://c.tah.openstreetmap.org/Tiles/tile/{Z}/{X}/{Y}.png', 
			//open cycle map
			tileUrlTemplate: 'http://c.andy.sandbox.cloudmade.com/tiles/cycle/{Z}/{X}/{Y}.png', 
			//mapnik
			//tileUrlTemplate: 'http://tile.openstreetmap.org/{Z}/{X}/{Y}.png', 
			isPng: true,
			opacity: 1.0
		})],
	new GMercatorProjection(18),
	'Topographique',
	{
		maxResolution: 17,
		minResolution: 1,
		shortName: 'OSM'
	}
);
var OSM_osmarender = new GMapType(
	[ new GTileLayer(
		copyCollection,
		1, 
		17,
		{
			// osmarender
			tileUrlTemplate: 'http://beta.letuffe.org/tiles/renderer.py/hiking/{Z}/{X}/{Y}.jpeg', 
			//open cycle map
			//tileUrlTemplate: 'http://c.andy.sandbox.cloudmade.com/tiles/cycle/{Z}/{X}/{Y}.png', 
			//mapnik
			//tileUrlTemplate: 'http://tile.openstreetmap.org/{Z}/{X}/{Y}.png', 
			isPng: true,
			opacity: 1.0
		})],
	new GMercatorProjection(18),
	'Rando',
	{
		maxResolution: 17,
		minResolution: 1,
		shortName: 'Carte rando'
	}
);
map.addMapType(OSM);
map.addMapType(OSM_osmarender);



/************* FIN CODE SLY *********/

	// si idmassif existe, c'est que le nav concerne q'un massif, 
	//ce qui devrait Toujours etre le cas maintenant qu'il n'y a plus d'acces direct au navigateur
	if ( ! (typeof idmassif=='undefined') ) {
			var massif = listemassifs[0] ;
			var zoom = map.getBoundsZoomLevel( massif.getBounds() ) ;
			var centre = massif.getBounds().getCenter();
			map.setCenter( centre , zoom , G_PHYSICAL_MAP );
	}
	else
	{
		if (choix_layer=='OSM')
			var choix=OSM;
		else
			var choix=G_PHYSICAL_MAP;
		map.setCenter(new GLatLng(lat, long), taille_zoom, choix);
	}

	//----------CONFIGURE LES CONTROLES-------------------
	map.addControl(new GScaleControl()); // echelle en bas a gauche
	map.addControl(new GLargeMapControl()); // controle en haut a gauche
	map.addControl(new GMapTypeControl()); // choisit le fond de carte
	map.enableScrollWheelZoom(); // autorise le zoom a la molette

	//-----------MASQUAGE DES CONTROLES SI INACTIF--------------------
	map.hideControls(); // au depart, cache les controles
	GEvent.addListener(map, "mouseover", function(pointgps){
		map.showControls();
	});
	GEvent.addListener(map, "mouseout", function(pointgps){
		map.hideControls(); 
		document.getElementById('gps_lat').value = ""; // on sort de la map
		document.getElementById('gps_lng').value = ""; // donc on efface les coordonnees
	});

	//--------MAJ des COORD GPS DANS LA LEGENDE-------------------
	GEvent.addListener(map, "mousemove", function( pointgps ){
		document.getElementById('gps_lat').value = Math.round( pointgps.lat() * 10000 ) / 10000 ;
		document.getElementById('gps_lng').value = Math.round( pointgps.lng() * 10000 ) / 10000 ;
	});
	
	//--------------------
	// Mouvement de la map
	// attends un mouvement de la map, pour recharger les icones
	GEvent.addListener(map, 'moveend', function() {
		MAJ_carte( document.getElementsByName('id_point_type[]') );
	});

	//----------------------
	// Click sur un truc (n'importe quoi sur la map, faut gerer)
	// j'utilise ceci au lieu d'un eventListener attach� au Marker comme pr�conis� par google
	// paske il parait que ca gagne du temps de chargement
	GEvent.addListener(map, 'click', function(overlay, point) {
		if (overlay) {
			// we now need a check here in case the overlay is the info window
			// only our markers will have a .myhtml property
			if (overlay.myhtml) {
				// overlay.openInfo... march pas, chais pas pkoi, donc :
				map.openInfoWindowHtml(overlay.getLatLng(), overlay.myhtml);
			}
		} 
		if (point) {
			// Si on a coch� "autoriser l'ajout", c'est un clic d'enregistrement!
			if ( document.getElementById("mode_ajout").checked ) {
				var lat= ( Math.round(point.lat()*10000) /10000 );
				var lon= ( Math.round(point.lng()*10000) /10000 );
				
				map.openInfoWindowHtml(point, 
										"<em>Insertion d'un point (�tape 1/3)</em><br />coordonn�es WGS84: "
										+lat+", "+lon+"<br />"
										+"<p>Les coordonn�es,<br />ainsi que tous les autres renseignements,<br /> seront pr�cis�s aux �tapes suivantes</p>"
										+"<a href='/point_ajout_etape2.php?y="+lat+"&x="+lon+"'>Continuer � l'�tape 2</a>"
										);
			} // fin du if ajout == true
		} // fin de la gestion du clic
	}); // fin du Event Listener de clic 
	// et enfin, on affiche les points 
	MAJ_carte( document.getElementsByName('id_point_type[]') );
}

//------------------------------------------------------------------------------------------------
// transforme un tableau d'Image() en GIcon().    Pkoi ? pour etre sur qu'a la fabrication des Gicones, les images sont pretes. autrement rien ne s'affiche
// ATTENTION : le tablo images doit exister !!! (il a servi a charger les icones)
function init_icones() {
	// transforme un tablo d'images, en tablo de GIcon (gmaps) , a lancer dans le body=onload, pour etre sur que tt les images sont pretes
	// juste avant la creation de la map.

	// d�clar� en global dans fonctions gmaps.php
	//var icones = new Array();

	for (ptype in images)
	{
		icones[ptype] = new GIcon();
		icones[ptype].image = images[ptype].src ;
		icones[ptype].iconSize = new GSize(images[ptype].width, images[ptype].height);
		icones[ptype].iconAnchor = new GPoint(images[ptype].width/2, images[ptype].height/2);
	}

}

//----------------------------------------------------------------------
// PREPARE LE LIEN vers le fichier GPX qui contiendra tous les points a afiicher.
// en param le tablo des checkboxes a inclure dans le GPX
function MAJ_carte(poitypes) {
	// Met a jour les icones et polys de categorie "types" sur la carte.

	// recupere la BBOX (les longitudes et latitudes extremes)
	var bbox = limites_bbox( map, 100 );

	// si il y a bien les champ de formulaire pour recevoir la bbox (en hidden), on les remplit, sinon on fait rien.
	if(document.getElementById('bbox_latmin') != null) {
		document.getElementById('bbox_latmin').value = bbox['latmin'];
		document.getElementById('bbox_latmax').value = bbox['latmax'];
		document.getElementById('bbox_lngmin').value = bbox['lngmin'];
		document.getElementById('bbox_lngmax').value = bbox['lngmax'];
	}

	// prepare le lien GPX correspondant via la moulinette d'exportation de sly et tivincent
	// inclut la fenetre de tir (bbox) pour limiter la recherche
	// ne pas mettre w.r.i car sinon, l'acces par ref.info (sans www) ne marche plus ...
	var gpx_url = '/exportations/exportations.php?';
	gpx_url += 'format=gpx';
	gpx_url += '&bbox_latmin=' + bbox['latmin'] ;
	gpx_url += '&bbox_latmax=' + bbox['latmax'] ;
	gpx_url += '&bbox_lngmin=' + bbox['lngmin'] ;
	gpx_url += '&bbox_lngmax=' + bbox['lngmax'] ;

	if ( ! (typeof poitypes=='undefined') ) {
		gpx_url += "&liste_id_point_type=0" ;
		for ( var i=0; i < poitypes.length; i++) {
			if (poitypes[i].checked) {
				gpx_url += "," + poitypes[i].value ;
			}
		}
	}	

	if ( ! (typeof idmassif=='undefined') ) {
		gpx_url += '&liste_id_massif=' + idmassif ;
	}

	// lance le download du fichier GPX correspondant , une fois charg�, il sera lu par la fct parse_xml.
//gpx_url=prompt("URL:",gpx_url);
	GDownloadUrl( gpx_url, parse_xml ) ;

} // fin MAJ_carte()

gpx = new Array () ; // infos generales sur le fichier desc, metadata ...

//-----------------------------------------------------------------------------------------
//PARSE UN FICHIER GPX !!! (le fichhiers qui contiendra tous les points a afficher dans la map)
// ATTENTION: le fichier provient directement des routines d'exportation de Sly !!	
// potentiels probl�mes dans le code DOM javascript ci dessous ...
function parse_xml(data, erreur) {
	// si error, c'est que il y a eu probleme lors de la recup du fichier
	// 200, c'est le code OK du protocol http.

	if ( erreur != '200' ) {
		alert('erreur retournee lors du GdownloadURL: '+erreur+' Merci de le signaler si le probleme persiste');
	}

	// recupere les donnees ( voir le resultat du fichier en direct)

	var xmlp = GXml.parse(data);
	// xmlp.async = false ; // march pas.il faudrait le passer avant pour IE ...
	// xml est maintenant un objet DOM XML, avec toutes les fct standards
	
	var xmlgpx = xmlp.documentElement.childNodes ;
	var overlays = new Array () ; // TOUS LES POINTS SERONT EMPILES LA dedans
	
	//----------------------------------
	// info generales sur le fichier r�cup�r�
	// parcourt toute l'arborescence GPX
	for(var j=0;j<xmlgpx.length;j++){
		// en fonction du tag GPX, fait differentes actions
		// ATTENTION, le text d'un node est toujours a un niveau au dessous ( d'ou l'uitilsation de firstChild)
		// TOUS LES TAGS GPX de 1er niveau doivent etre ici !
		
		if ( /^#/.test(xmlgpx.item(j).nodeName) ) {
			// ce sont les #text, #comment ... on en fait rien.
			continue ;
		}

		if ( xmlgpx.item(j).childNodes.length == 1 ) {
			// si 1 seul enfant, c'est  en fait un "name" ou "desc", pas un wpt ou trk ...
			// a utiliser plus tard comme gpx['desc'] ...
			gpx[xmlgpx.item(j).nodeName] = xmlgpx.item(j).firstChild.nodeValue ;
			continue ;
		}
		
		// DECODAGE DES POINTS (les rte et trk ne seront pas traites)
		// voir la doc du format GPX pour plus d'infos, choisi car c'est le plus facile a decoder
		switch(xmlgpx.item(j).nodeName) {
			case 'wpt':
				var latlon = new GLatLng( xmlgpx.item(j).getAttribute('lat'),
											xmlgpx.item(j).getAttribute('lon') );
				
				// recupere le ID point_type (3=abri 7=lac ...)
				var ptype = xmlgpx.item(j).getElementsByTagName("id_type_point").item(0).firstChild.nodeValue ;
				// .item(0) car il peut y avoir +ieurs id_type_point en theorie, .firstChild pour aller jusqu'au "noeud texte" implicite
				
				var nom = xmlgpx.item(j).getElementsByTagName("name").item(0).firstChild.nodeValue ;
				var alti = xmlgpx.item(j).getElementsByTagName("ele").item(0).firstChild.nodeValue ;
				var url = xmlgpx.item(j).getElementsByTagName("link").item(0).getAttribute("href") ;

				var markerOptions = { icon: icones[ptype],
									title: nom + " (" + alti + "m)" } ;
				var marker = new GMarker ( latlon, markerOptions ) ;
					marker.url = url ; // necessaire, sera utilisr apres pour la gestion du lien
				overlays.push( marker ); // un de plus, on empile
			break;
			//case 'rte':
			//	// MASSIFS: abandonn�
			//	// d'abord , recuperer les sommets du polygon
			//	var aretes = xmlgpx.item(j).getElementsByTagName("wpt");
			//	var sommets = new Array () ;
			//		for ( var i=0; i < aretes.length ; i++ ) {
			//			sommets.push( new GLatLng (
			//					aretes.item(i).getAttribute("lat"),
			//					aretes.item(i).getAttribute("lon") ) ) ;
			//		}
			//	overlays.push( new GPolygon(sommets,"#BB0000",2,.5) );
			//break ;
		} // fin du switch WPT TRK ...
	} // fin du FOR (parcours des items GPX 1er niveau)
	
	// nettoyage de map QUE si on est g�re le mouvement, sinon pas de nettoyage.
	// ainsi, la d�co qu'on peut rajouter pour les vignettes ne disparait pas.
	// normalemennt, les vignette passent 1 SEULE FOIS ici, tandis que le nav, a chaque mouvement
	if ( map.draggingEnabled() ) {
		map.clearOverlays(); // gros nettoyage avant le depilage de tout ce qu'on a trouv�
	}

	if ( ! ( typeof idmassif == 'undefined' ) ) {
		//var contour = listemassifs[0] ;
		//map.addOverlay( contour ) ;
		var massif;
		for( massif in listemassifs ) {
			map.addOverlay( listemassifs[massif] ) ;
		}
	}

	while(overlays.length > 0) {
		//var nouveaupoint = overlays.pop() ;
		map.addOverlay( overlays.pop() ) ;
				// en cas de clic sur le point, redirige direct. simplifie bocoup le code de pas afficher une bulle google

	}

	GEvent.addListener(map, 'click', function(point) {
		if(point.url) {
			window.location.href = point.url ;
			//alert(point.url);
		}
	}); // fin du Event Listener de clic 

}

//---------------------------------------------------------------------------------------------
// initialise la "vignette", c'est la mini-carte dans les fiches
// en param le div qui la contiendra, et le centrage
function vignette(div, lat, lng ) {
	// initialise la carte google.
	
	if ( ! GBrowserIsCompatible()) {
		alert("Selon Google, votre navigateur affichera mal les cartes. mais on va essayer quand m�me.");
	}

	//----------CREATION DE LOBJET MAP-------------------
	map = new GMap2(div);

	//---------- CHOPE LE BON FOND DE CARTE ------------------
	map.removeMapType(G_HYBRID_MAP); // Vire le type "Mixte"
	map.addMapType(G_PHYSICAL_MAP); // ajoute la possibilit� RELIEF (v2.94)

	map.setCenter( new GLatLng(lat,lng) , 11, G_PHYSICAL_MAP );


	map.disableScrollWheelZoom(); // interdit le zoom a la molette
	map.disableDragging();

	map.hideControls(); // au depart, cache les controles

	map.addControl( new GScaleControl() ) ; // Echelle

	// charge les icones
	MAJ_carte();

	// affiche le carre rouge autour du point
	var mise_en_valeur= new GPolyline([
			new GLatLng(lat + 0.01, lng + 0.01),
			new GLatLng(lat + 0.01, lng - 0.01),
			new GLatLng(lat - 0.01, lng - 0.01),
			new GLatLng(lat - 0.01, lng + 0.01),
			new GLatLng(lat + 0.01, lng + 0.01) ]
			, '#ff0000', 3, 0.3, {clickable:false} );

	map.addOverlay(mise_en_valeur);


} // fin vignette

//----------------------------------------------------
// renvoie un tablo contenant les 4 coordonn�es extr�mes de la map en param�tre.
// nb de d�cimales en param�tre FACULTATIF
function limites_bbox(map, precision )
{
	// param facultatif
	if('undefined' == typeof precision) {precision = 100;}

	// chope les coins de la bbox
	var coin_NE = map.getBounds().getNorthEast();
	var coin_SO = map.getBounds().getSouthWest();

	var bbox = new Array();
	// recupere la BBOX (les longitudes et latitudes extremes)
	bbox['latmin'] = Math.round( coin_SO.lat() * precision ) / precision;
	bbox['latmax'] = Math.round( coin_NE.lat() * precision ) / precision;
	bbox['lngmin'] = Math.round( coin_SO.lng() * precision ) / precision;
	bbox['lngmax'] = Math.round( coin_NE.lng() * precision ) / precision;
	
	return bbox ;
}

//-----------------------------------------------------------------------------------
// ajoute un bouton avec certaines infos au milieu d'un polygone-massif
// utilis� uniquement par la page d'accueil
function boutonmassif( carte, massif, infobulle ) {
	var position = massif.getBounds().getCenter(); //le bouton sera au centre de la bbox du massif
	var btIcon = new GIcon();
		btIcon.image = "/images/icones/bullet.png";
		btIcon.shadow = "";
		btIcon.iconSize = new GSize(15, 15); // INDISPENSABLE pour eviter les cmpts aleatoires
		btIcon.iconAnchor = new GPoint(7, 8); // le bouton est centr� par rapport a son icone
	var btoptions = new Object();
		btoptions.icon = btIcon ;
		btoptions.title= massif.nom + " : " + massif.nb_refuges + " refuges" ; // infobulle
	var bouton = new GMarker(position, btoptions );
	GEvent.addListener(bouton, "click", function() {
		// Cet event listener sert pour les clic de massifs. redirige direct vers le navigateur
		window.location.href = massif.mylink ;
	});
	carte.addOverlay( bouton ); // ajoute le bouton sur la carte.
}

// ================ DEBUG fonction ============
function print_r(theObj){
  if(theObj.constructor == Array ||
     theObj.constructor == Object){
    document.write("<ul>")
    for(var p in theObj){
      if(theObj[p].constructor == Array||
         theObj[p].constructor == Object){
document.write("<li>["+p+"] => "+typeof(theObj)+"</li>");
        document.write("<ul>")
        print_r(theObj[p]);
        document.write("</ul>")
      } else {
document.write("<li>["+p+"] => "+theObj[p]+"</li>");
      }
    }
    document.write("</ul>")
  }
}