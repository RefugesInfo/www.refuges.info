<?php
//**********************************************************************************************
//* Nom du module:         | fonctions_points.php                                              *
//* Date :                 | 23/01/2008                                                        *
//* Cr�ateur :             | sly                                                               *
//* R�le du module :       | Fonctions en rapport avec les points de la base                   *
//*------------------------|-------------------------------------------------------------------*
//* Modifications(date Nom)| Elements modifi�s, ajout�s ou supprim�s                           *
//*------------------------|-------------------------------------------------------------------*
//* 23/01/08 sly           |-cr�ation initiale d'une fonction pour supprimer un point          *
//*                        | proprement ( commentaires, photos, forum, point lui m�me )        *
//*                        |                                                                   *
//*                        |- On trouve aussi les fonctions li�es aux points                   *
//*                        | ( affichage, cr�ation forum, modifications, etc.)                 *
// 21/04/08 jmb 	changements dans presentation info generale point 'pour les coord en particulier)
//**********************************************************************************************


/*****************************************************
Depuis la plus grande complexist�e du stockage des points
GPS (voir fichier a_lire.txt sur la structure de la base)
il est fortement recommand� de n'utiliser plus que les fonctions
ci-apr�s pour r�cup�rer les infos des points, en ajouter
ou en modifier
*****************************************************/


/*****************************************************
Cette fonction r�cup�re sous la forme d'un object
toutes les caract�ristiques d'un point
retourne -1 si le point n'est pas trouv�
on acc�de sous la forme $infos_point->champ
un array est disponible sous la forme 
$infos_point->polygones[$i]->champ
( polygones tri�s par importance pays>d�partement>massif>carte>parc
pour obtenir la liste des polygones auquels ce point appartient
Pour simplifier $infos_point->massif contient les infos du polygone massif auquel le
point appartient
*****************************************************/
function infos_point($id_point)
{
global $config;
// inutile de faire tout deux fois, j'utilise la fonction liste_points()
$conditions->liste_id_point=$id_point;
$conditions->modele=-1;
$res_point=liste_points($conditions);
if ($res_point->nombre_point!=1)
	return -1;
$infos_point=mysql_fetch_object($res_point->resultat);

// recherche des diff�rents polygones auquels appartienne le point
$query_polygones="SELECT polygones.*,polygone_type.* FROM polygones,appartenance_polygone,points,points_gps,polygone_type
			WHERE points.id_point=$id_point
			AND polygone_type.id_polygone_type=polygones.id_polygone_type
			AND appartenance_polygone.id_point_gps=points_gps.id_point_gps
			AND polygones.id_polygone=appartenance_polygone.id_polygone
			AND points.id_point_gps=points_gps.id_point_gps
			ORDER BY polygone_type.ordre_taille DESC";
$res=mysql_query($query_polygones);

$infos_point->latitude=round($infos_point->latitude,5);
$infos_point->longitude=round($infos_point->longitude,5);
if (mysql_num_rows($res)==0)
	{mysql_free_result($res);return $infos_point;}
while ($polygones_du_points=mysql_fetch_object($res))
{
	$infos_point->polygones[]=$polygones_du_points;

	// pour se simplifier la vie, si on tombe sur un massif, on en garde les infos dans $infos_point->massif
	if ($polygones_du_points->id_polygone_type==$config['id_massif'])
		$infos_point->massif=$polygones_du_points;
}
mysql_free_result($res);
return $infos_point;
}

/*****************************************************
Cette fonction r�cup�re sous la forme de plusieurs objet un peu � la mani�re de
la fonction infos_point mais cette fois avec possibilit� de conditions !
J'aurais p� fusionner les deux, mais ce serait vraiment ilisible 
( a voir si je ne les fusionnerais pas dans l'avenir, ou du moins que l'une fasse usage de l'autre )
retourne un object contenant le r�sultat mysql et le nombre de ligne :
on acc�de sous la forme 
$liste_points->resultat (retour SQL)
$liste_points->nombre_point (le nombre de r�sultat issue de la requ�te sans le LIMIT)

c'est une fonction de centralisation utilisable pour l'instant par 
l'exportation, la recherche, les nouvelles et le flux RSS
d'autre pourrons venir ensuite.

plut�t que de lui passer 50 champs, on ne lui passe qu'un seul, un object contenant les crit�res
de conditions et donc plus facilement extensible
voici les param�tres attendus de recherche :
(tous facultatifs)
$conditions->nom (recherche de type LIKE sur le champ)
$conditions->altitude_maximum
$conditions->altitude_minimum
$conditions->places_maximum
$conditions->places_minimum
$conditions->type_point (liste d'id dans notre base des points type ex: 12 ou 12,13,14)
$conditions->latitude_minimum
$conditions->latitude_maximum
$conditions->longitude_minimum
$conditions->longitude_maximum
$conditions->id_polygone (points appartenant � ce polygone)
$conditions->liste_id_point (liste restreinte � ces id_point l�, attention, si d'autres condition les int�rdisent, ils ne sortiront pas)
$conditions->precision_gps (liste des qualit�s GPS souhait�es, 1 ou 2,4,5)

$conditions->modele (1 si on veut acc�der aux mod�les, -1 si on s'en fiche, sinon on ne les veux pas)
$condition->avec_infos_massif (1 si on veut les infos du massif auquel le point appartient) ou "" sinon )
$condition->limite (nombre maximum d'enregistrement � aller chercher)
$conditions->ordre (clause ORDER BY, sans le "ORDER BY" )

sly 31/10/08
*****************************************************/
function liste_points($conditions)
{
global $config;
// condition de limite en nombre
if ($conditions->limite!="")
	$limite="\nLIMIT 0,$conditions->limite";
if ($conditions->ordre!="")
	$ordre="\nORDER BY $conditions->ordre";

/******** Liste des conditions de type WHERE *******/
$conditions_sql="";
$tables_en_plus="";

// conditions sur le nom du point
if($conditions->nom!="")
	$conditions_sql .= " AND points.nom LIKE \"%".$conditions->nom."%\" \n";

// condition sur l'appartenance � un polygone
if($conditions->id_polygone!="")
{
$tables_en_plus.=",appartenance_polygone,polygones";
$conditions_sql .= "AND appartenance_polygone.id_point_gps=points_gps.id_point_gps 
AND appartenance_polygone.id_polygone=polygones.id_polygone
AND polygones.id_polygone IN ($conditions->id_polygone)";
}
elseif ($conditions->avec_infos_massif!="")
{
// FIXME !! cette partie de la requ�te a un gros d�faut :
// FIXME !! si le point n'appartient � aucun massif, on ne le trouve pas
// FIXME !! un JOIN truc bidule qui autorise une liaison vide serait top sly 03/11/2008
$tables_en_plus.=",appartenance_polygone,polygones";
$conditions_sql .= "AND appartenance_polygone.id_point_gps=points_gps.id_point_gps 
AND appartenance_polygone.id_polygone=polygones.id_polygone
AND polygones.id_polygone_type=($config[id_massif])";
}

// condition sur le type de point (on s'attend � 14 ou 14,15,16 )
if($conditions->type_point!="")
	$conditions_sql .="\n AND points.id_point_type IN ($conditions->type_point) \n";

// conditions sur le nombre de places
if($conditions->places_minimum!="")
	$conditions_sql .= "\n AND points.places >= ".$conditions->places_minimum;
if($conditions->places_maximum!="")
	$conditions_sql .= "\n AND points.places <= ".$conditions->places_maximum;

// conditions sur l'altitude
if($conditions->altitude_minimum!="")
	$conditions_sql .= "\n AND points_gps.altitude >= ".$conditions->altitude_minimum;
if($conditions->altitude_maximum!="")
	$conditions_sql .= "\n AND points_gps.altitude <= ".$conditions->altitude_maximum;

//veut-on cacher les points dont les coordonn�es sont cach�es ?
if($conditions->pas_les_points_caches!="")
	$conditions_sql .= "\n AND points_gps.id_type_precision_gps != ".$config['id_coordonees_gps_fausses'];

//quelle condition sur la qualit� suppos�e des GPS
if($conditions->precision_gps!="")
	$conditions_sql .= "\n AND points_gps.id_type_precision_gps IN ($conditions->precision_gps)";

// conditions g�ographique sur les coordonn�es GPS
if($conditions->latitude_minimum!="")
	$conditions_sql.="\n AND points_gps.latitude>" . $conditions->latitude_minimum;
if($conditions->latitude_maximum!="")
	$conditions_sql.="\n AND points_gps.latitude<" . $conditions->latitude_maximum;
if($conditions->longitude_minimum!="")
	$conditions_sql.="\n AND points_gps.longitude>" . $conditions->longitude_minimum;
if($conditions->longitude_maximum!="")
	$conditions_sql.="\n AND points_gps.longitude<" . $conditions->longitude_maximum;

// condition restrictive sur des id_points particuliers
if($conditions->liste_id_point!="")
	$conditions_sql.="\n AND points.id_point IN ($conditions->liste_id_point)";

//conditions sur la description (champ remark)
if($conditions->description!="")
	$conditions_sql.="\n AND points.remark LIKE '%$conditions->description%'";

// cas sp�cial sur les mod�le
if ($conditions->modele==1)
	$conditions_sql.="\n AND modele=1";
elseif($conditions->modele=="")
	$conditions_sql.="\n AND modele!=1";
else
	$conditions_sql.="";


// recherche des infos "g�n�riques" d'un point
$query_liste_points="
select SQL_CALC_FOUND_ROWS *,UNIX_TIMESTAMP(date_derniere_modification) as date_modif_timestamp
FROM points,point_type,type_precision_gps,points_gps$tables_en_plus
WHERE 
1=1
AND 	points_gps.id_point_gps = points.id_point_gps
AND	points.id_point_type=point_type.id_point_type
AND	points_gps.id_type_precision_gps=type_precision_gps.id_type_precision_gps
$conditions_sql $ordre $limite
";
//print("$query_liste_points");
$res=mysql_query($query_liste_points);
//print("<!-- $query_liste_points -->");
// On va chercher le nombre de ligne qu'il y aurrait eu sans la LIMIT
$nombre_point = mysql_result( mysql_query( "SELECT FOUND_ROWS();") , 0 );
$liste_points->nombre_point=$nombre_point;
$liste_points->resultat=$res;
return $liste_points;
}
/****************************************
On g�n�re une url "propre" vers le point
***************************************/
function lien_point($nom_point,$nom_massif,$id_point,$type = "")
{
 // jmb: j'essaie de virer les reference au nom pour que ca reste dynamique
 return "http://".$_SERVER["HTTP_HOST"]."/point/$id_point/".replace_url($type)."/".replace_url($nom_massif)."/".replace_url($nom_point)."/";
}

/****************************************
Lien plus simple � utiliser maintenant ! sur la base
de l'objet point "habituel" et plus rapide que celui du dessous
car requ�te de moins
***************************************/
function lien_point_fast($point)
{
 // jmb: j'essaie de virer les reference au nom pour que ca reste dynamique
 return "http://".$_SERVER["HTTP_HOST"]."/point/$point->id_point/".replace_url($point->type_point)."/".replace_url($point->massif->nom_polygone)."/".replace_url($point->nom)."/";
}



/****************************************
On g�n�re une url vers le point juste � partir de son id
Attention c'est moins performant � ne pas trop utiliser
pour des longues listes ( car requete SQL oblige )
***************************************/
function lien_point_lent($id_point)
{
  connexion_base();
  $infos_point=infos_point($id_point);
  if ($infos_point==-1)
    return -1;
  return (lien_point($infos_point->nom,$infos_point->massif->nom_polygone,$id_point,$infos_point->nom_type));
}


/*****************************************************
Dans le cas d'un nouveau point, creation d'un topic dans forum correspondant.
(C'est du copier coller de ce qu'il y avait dans point.php)
id et nom du point en question (nouveau point ?)
renvoie le topic_id
Non, vous ne r�vez pas, il y'a bien 5 requ�tes l� o� je pense
que une devrait suffir !
phpBB serait il un brontosaure du web ? mal programm� mais finalement
tr�s utilis� ?
********************************************/
function forum_point_ajout( $id, $nom )
{
        /*** mise � jour des stats du forum - un sum() vous connaissez pas chez phpBB ? ***/
        $query_update="UPDATE `phpbb_forums` SET
                        `forum_topics` = forum_topics+1,
                        `prune_next` = NULL
                        WHERE `forum_id` = '4'";
        mysql_query($query_update);
        /*** rajout du topic sp�cifique au point ( Le seul qui me semble logique ! )***/
        $query_insert="INSERT INTO `phpbb_topics` (
                `topic_id` , `forum_id` , `topic_title` , `topic_poster` , `topic_time` ,
                `topic_views` , `topic_replies` , `topic_status` , `topic_vote` ,
                `topic_type` , `topic_first_post_id` , `topic_last_post_id` ,
                `topic_moved_id` , `topic_id_point` )
                VALUES (
                        '', '4', '$nom', '-1', unix_timestamp() ,
                        '0', '0', '0', '0',
                        '0', '0', '0',
                        '0', '$id' )";
        mysql_query($query_insert);
        $topic_id=mysql_insert_id();

        /*** rajout d'un post fictif pour d�buter le truc - je vois pas en quoi c'est n�cessaire, le topic devrait pouvoir �tre vide**/
        $query_insert_post="INSERT INTO `phpbb_posts` (
                `post_id` , `topic_id` , `forum_id` , `poster_id` , `post_time` ,
                `poster_ip` , `post_username` , `enable_bbcode` , `enable_html` ,
                `enable_smilies` , `enable_sig` , `post_edit_time` , `post_edit_count` )
                VALUES (
                        '', '$topic_id', '4', '-1', UNIX_TIMESTAMP( ) ,
                        '00000000', 'refuges.info' , '1', '0',
                        '1', '1', NULL , '0' )";
        mysql_query($query_insert_post);
        $last=mysql_insert_id();

        /*** rajout d'un post avec texte pour d�buter le truc ( phpBB mal cod� ? non ? ) ha �a oui ! **/
        $query_texte="INSERT INTO `phpbb_posts_text` (
                `post_id` , `bbcode_uid` , `post_subject` , `post_text` )
                VALUES (
                        '$last', '', '',
                        '')";
        mysql_query($query_texte);
        /*** remise � jour du topic ( alors ici c'est le bouquet, un champ qui stoque le premier et le dernier post ?? )***/
        $query_update_topic="UPDATE phpbb_topics SET
                topic_first_post_id=$last,topic_last_post_id=$last
                WHERE topic_id=$topic_id";
        mysql_query($query_update_topic);

    return $topic_id ;
}

/********************************************************
Pour simplifier encore la maintenance, si on met � jour
le nom d'un point du site, on met aussi � jour le topic forum
correspondant.
Certes un joli id de liaison serait plus propre, mais il faudrait bidouiller salement
le phpBB, donc duplication
********************************************************/

function forum_mise_a_jour_nom($id_point,$nom)
{
$query="UPDATE `phpbb_topics`
			SET `topic_title`='$nom'
			WHERE `topic_id_point`=$id_point";
mysql_query($query);
}
/********************************************************
Fonction qui permet, en fonction de l'object $point_gps pass�
en param�tre la mise � jour OU la cr�ation si :
$point->id_point_gps==""
Les champs attendus sont :
id_point_gps,longitude,latitude,altitude,access et id_type_precision_gps

Tout est facultatif, ne sera mis � jour que ce qui est pr�sent
le reste sera pr�supos� si non pr�sent
en cas d'ajout : longitude,latitude sont obligatoires
sly 02/11/2008
********************************************************/
function modification_ajout_point_gps($point_gps)
{
global $config;
$champs=array("longitude","latitude","altitude","acces","id_type_precision_gps");

// si latitude ou longitude vide, on ne peut rien faire
if ($point_gps->longitude=="" OR $point_gps->latitude=="")
	return -1;

// si aucune pr�cision gps, on les suppose approximatives
if ($point_gps->id_type_precision_gps=="")
	$point_gps->id_type_precision_gps=$config['id_coordonees_gps_approximative'];
foreach ($champs as $champ)
{
	if (isset($point_gps->$champ))
	$champs_sql.="\n$champ='".ucfirst(mysql_real_escape_string(stripslashes($point_gps->$champ)))."',";
}
// fait-on un updater ou un insert ?
if ($point_gps->id_point_gps!="")
	{$insert_update="UPDATE";$condition="WHERE id_point_gps=$point_gps->id_point_gps";}
else
	$insert_update="INSERT INTO";

$champs_sql=trim($champs_sql,",");

$query_finale="$insert_update points_gps set $champs_sql $condition";
mysql_query($query_finale);
if ($point_gps->id_point_gps!="")
	$id_point_gps=$point_gps->id_point_gps;
else
	$id_point_gps=mysql_insert_id();

return $id_point_gps;
}
/********************************************************
Fonction qui permet, en fonction de l'object $point pass�
en param�tre la mise � jour OU la cr�ation si :
$point->id_point==""
Les autres champ, classiques, comme la sortie de la fonction 
infos_point($id_point) servirons pour la cr�ation ou la mise �
jour.
Le minimum vital est que $point->nom ne soit pas vide
tout est facultatif mais si :
$point->champ est vide ("") il sera remis � z�ro
si
$point->champ n'existe pas (isset()=FALSE on y touche pas)
sly 02/11/2008
********************************************************/

function modification_ajout_point($point)
{
if (trim($point->nom)=="")
	return "erreur_nom";
if ($point->id_point!="")
{
	$infos_point_avant=infos_point($point->id_point);
	if ($infos_point_avant==-1) // oulla on nous demande une modif mais il n'existe pas
		return "erreur_point_inexistant";

if ($point->id_point_gps=="")
	$point->id_point_gps=$infos_point_avant->id_point_gps;
}

/********* les coordonn�es du point dans la table points_gps *************/
// dans $point tout ne lui sert pas mais �a m'�vite de cr�er un nouvel objet uniquement
$point->id_point_gps=modification_ajout_point_gps($point);
	

/********* Les caract�ristiques propres du point *************/
// champ ou il faut juste un set=nouvelle_valeur
$champs_classiques=array("nom","places","remark","proprio","id_point_type","id_auteur_derniere_modification","modele","id_point_gps");
foreach ($champs_classiques as $champ)
{
	if (isset($point->$champ))
	$champs_sql.="\n$champ='".ucfirst(mysql_real_escape_string(stripslashes($point->$champ)))."',";
}

//cas pour la beaut�, ne transformons pas la premi�re lettre du pseudo en majuscule
if (isset($point->auteur_derniere_modification))
	$champs_sql.="\nauteur_derniere_modification='".mysql_real_escape_string(stripslashes($point->auteur_derniere_modification))."',";

// si on a voulu mettre � jour le dernier mod�rateur, alors on change la date aussi
if (isset($point->id_auteur_derniere_modification))
	$champs_sql.="\ndate_derniere_modification=NOW(),";

// fait-on un updater ou un insert ?
if ($point->id_point!="")
	{$insert_update="UPDATE";$condition="WHERE id_point=$point->id_point";}
else
	{$insert_update="INSERT INTO";$champs_sql.="date_insertion=UNIX_TIMESTAMP(),";}

$champs_sql=trim($champs_sql,",");

$query_finale="$insert_update points set $champs_sql $condition";
mysql_query($query_finale);
if ($point->id_point=="")
	$point_en_cours=mysql_insert_id();
/********* la cr�ation ou mise � jour du forum point *************/
if ($point->id_point=="")
	forum_point_ajout( $point_en_cours, $point->nom);
else
	forum_mise_a_jour_nom($point->id_point, $point->nom);

/********* A quels polygones ce point appartient-t-il ? *************/
if ($point->id_point=="")
	$point->id_point=$point_en_cours;
mettre_a_jour_appartenance_point($point->id_point);

// on retoure l'id du point (surtout utile si cr�ation)
return $point->id_point;
}

/********************************************************
Toujours pour simplifier encore la maintenance, si on supprime un point, on nettoye
le topic du forum qui correspond, �a reprend casi la m�me chose que l'ajout 
mais en inverse ;-)
********************************************************/

function forum_supprime_topic($id_point)
{

	/*** on va chercher l'id du topic qu'on veut virer ***/
	$query_recherche="SELECT * FROM `phpbb_topics` where topic_id_point=$id_point";
	$res=mysql_query($query_recherche);
	$topic=mysql_fetch_object($res);
	        
	/*** vu que chez phpBB un post est dans deux tables, juste avant de les virer je vais virer leurs "contenus" ***/
	$query_recherche="SELECT * FROM `phpbb_posts` WHERE topic_id=$topic->topic_id";
	$res=mysql_query($query_recherche);
	while($posts_a_supprimer=mysql_fetch_object($res))
		mysql_query("DELETE FROM `phpbb_posts_text` where post_id=$posts_a_supprimer->post_id");
	
        /*** Suppression des posts du topic**/
        $query_supprime_post="DELETE FROM `phpbb_posts` WHERE topic_id=$topic->topic_id";
        mysql_query($query_supprime_post);
	
	/*** Suppression du topic sp�cifique au point***/
        $query_supprime="DELETE FROM `phpbb_topics` where topic_id=$topic->topic_id";
        mysql_query($query_supprime);
	
       /*** et pour finir mise � jour des stats du forum ***/
        $query_update="UPDATE `phpbb_forums` SET
                        `forum_topics` = forum_topics-1,
                        `prune_next` = NULL
                        WHERE `forum_id` = '4'";
        mysql_query($query_update);	
}
/******************************************************
FIXME
on lui passe un $id_commentaire et �a supprime le commentaire et la photo

Comme vous pouvez le voir, il n'y a strictement aucune sauvegarde , c'est un peu dangereux en cas de vandalisme, 
mais tout copier � tout copier � cot�, c'est lourd. Je pense �voluer vers un champ nomm� "suppression" 
qui contiendra 1 ou 0. Et que l'ensemble du site ignorera ( sauf zones de maintenance ) 
On peut aller plus loin et imaginer un champ id_nouveau_commentaire qui contient 0 si c'est le commentaire actif, et X si c'est
une ancienne version du commentaire d'id X... disons pas une priorit� ;-) sly - 27-06-2008 
*******************************************************/
function suppression_commentaire($id_commentaire)
{
	global $config;
	connexion_base();
	$query="SELECT * FROM commentaires WHERE id_commentaire=$id_commentaire";
    $res=mysql_query($query) or die("mauvaise requete: $query");
    $commentaire=mysql_fetch_object($res);
    /****** en prime on supprime la photo si elle existe, autant nettoyer ******/
    if ($commentaire->photo_existe)
	{
     		unlink($config['rep_photos_points'].$commentaire->id_commentaire.".jpeg");
		unlink($config['rep_photos_points'].$commentaire->id_commentaire."-originale.jpeg");
	}
      //unlink($config['rep_photos_points'].$commentaire->id_commentaire.".jpeg");
	//copy($config['rep_photos_points'].$commentaire->id_commentaire.".jpeg","./sauvegardes-photos/".$commentaire->id_commentaire.".jpeg");
    $query_delete="DELETE FROM commentaires WHERE id_commentaire=$id_commentaire LIMIT 1";
    mysql_query($query_delete) or die("mauvaise requete: $query_delete");
return TRUE; // pas d'�checs possibles ?
}
/*******************************************************
 * on lui passe un $id_point et �a supprime tout proprement
 * commentaires, photos, forum, points, points_gps 
*******************************************************/
function suppression_point($id_point)
{
connexion_base();

// a supprimer le refuge ET ses commentaires ET photos ! bug corrig� par sly
$query_recherche_commentaires="SELECT id_commentaire FROM commentaires WHERE id_point=$id_point";
$commentaires_a_supprimer=mysql_query($query_recherche_commentaires) or die("$query_recherche_commentaires est mauvais");
while ($commentaire_suppr=mysql_fetch_object($commentaires_a_supprimer))
	suppression_commentaire($commentaire_suppr->id_commentaire);
// suppression dans le forum
forum_supprime_topic($id_point);

// suite � la modification dans la base sur les coordonn�es GPS, on va supprimer aussi des tables :
// appartenance_polygone & point_gps si le point_gps n'est plus utilis� du tout
$infos_point=infos_point($id_point);
$query_plusieurs="SELECT id_point FROM points WHERE id_point_gps=".$infos_point->id_point_gps;
$res=mysql_query($query_plusieurs);
if (mysql_num_rows($res)==1) // il n'y a qu'un seul point de la base donc on fait le nettoyage
{
mysql_query("DELETE FROM appartenance_polygone WHERE id_point_gps=".$infos_point->id_point_gps);
mysql_query("DELETE FROM points_gps WHERE id_point_gps=".$infos_point->id_point_gps);
}

$query_delete="DELETE FROM points WHERE id_point=$id_point";
mysql_query($query_delete);

return TRUE; // pas d'�checs possibles ?
}

// fonction simple qui renvois une chaine avec liens au format :
// Pays > Massif > D�partement > carte topographique
function localisation($polygones)
{
$html="";
if(!isset($polygones))
	return "";
foreach ($polygones as $polygone)
{
	$lien=lien_polygone($polygone->nom_polygone,$polygone->id_polygone,$polygone->type_polygone);
	if ($polygone->url_exterieure!="" AND $polygone->source!="")
		$lien_externe="(<a href='$polygone->url_exterieure'>$polygone->source</a>)";
	$html.=" <a href=\"$lien\">$polygone->type_polygone $polygone->article_partitif $polygone->nom_polygone$lien_externe</a> >";
}
return trim($html,">");
}

//**********************************************************************************************
//* Nom de la fonction:    | presentation_infos_point_court                                    *
//* Date :                 |                                                                   *
//* Cr�ateur :             |                                                                   *
//* R�le de la fonction:   | Utilis�e dans la recherche pour afficher une ligne par point      *
//*------------------------|-------------------------------------------------------------------*
//* Param�tres(Nom E/S)    | R�le                                                              *
//*------------------------|-------------------------------------------------------------------*
//* $rqpoint           E   | objet contenant les informations du point ( sortir les infos par  *
//*                        | un SELECT * FROM points,point_type,polygones=massifs)             *
//*------------------------|-------------------------------------------------------------------*
//* Modifications(date Nom)| Elements modifi�s, ajout�s ou supprim�s                           *
//*------------------------|-------------------------------------------------------------------*
//* 27/06/2008 sly         | FIXME un avis ?                                                   *
//* 30/10/2008 sly         | Oui ! voici la version simple, recherche only                     *
//**********************************************************************************************

function presentation_infos_point_court($rqpoint)
{
	global $config;
	$lien_point_debut="<a href=\"".lien_point($rqpoint->nom, $rqpoint->nom_polygone, $rqpoint->id_point, $rqpoint->nom_type)."\">";$lien_point_fin="</a>";

	// lien de modif  uniquement si le visiteur est un mod�rateur 
	// ou si c'est cet utilisateur du forum qui a rentr� le point
	$html_construct .= "	<div class='fiche_cadre'> \n";

	$html_construct .= "<dl style='margin: 2px;'>
	";
	// rajout d'un bloc identit� principale ( nom, massif, type )
		$html_construct .="
		<dd class='condense'><em>";

	$html_construct.="<a href=\"".
		lien_point($rqpoint->nom,$rqpoint->nom_polygone,$rqpoint->id_point,$rqpoint->nom_type).
		"\">".bbcode2html($rqpoint->nom)."</a>";

	// Un bouton "modifier" cette fiche pour : les mod�rateurs, ou celui qui a rentr� cette fiche si elle n'a pas �t� modifi�e depuis
	if (isset($_SESSION['id_utilisateur'])
				AND ( ($_SESSION['niveau_moderation']>=1) OR ($_SESSION['id_utilisateur']==$rqpoint->id_auteur_derniere_modification))
		)
		$lien_modifier="<a class='groupir' style='font-size: smaller ;' href='/point_formulaire_modification.php?id_point=".$rqpoint->id_point."'>[Modifier]</a>";
	else
		$lien_modifier="";
		$html_construct .="</em> $lien_modifier, </dd>
			<dd class='condense'>".bbcode2html($rqpoint->nom_type)."</dd>
			";
			
		//afficher un lien vers le massif comprenant le point
		if ($rqpoint->id_polygone!=$config['numero_massif_fictif'])
			$html_construct .= "<dd class='condense'>dans le <a href=\"".lien_polygone($rqpoint->nom_polygone,$rqpoint->id_polygone,"Massif")
			."\">Massif ".$rqpoint->article_partitif." ".$rqpoint->nom_polygone
			."</a><br /></dd>";
		
	//------------- FIN DES INFOS --------
	$html_construct .= "</dl>
	";


	// FIN DU DIV de l'ENCADRE
	$html_construct .= "\n </div>\n"; 
	return $html_construct; 
}
//**********************************************************************************************
//* Nom de la fonction:    | presentation_infos_general_point                                  *
//* Date :                 |                                                                   *
//* Cr�ateur :             |                                                                   *
//* R�le de la fonction:   | Afin de r�duire la taille de la fiche point                       *
//*------------------------|-------------------------------------------------------------------*
//* Param�tres(Nom E/S)    | R�le                                                              *
//*------------------------|-------------------------------------------------------------------*
//* $rqpoint           E   | objet contenant les informations du point ( sortir les infos par  *
//*                        | un SELECT * FROM points,point_type,polygones=massifs)             *
//*------------------------|-------------------------------------------------------------------*
//* Modifications(date Nom)| Elements modifi�s, ajout�s ou supprim�s                           *
//*------------------------|-------------------------------------------------------------------*
//* 10/03/06 rff           |                                                                   *
//*                        |-la checkbox �tiquette d�plac�e depuis wms_nav.php                 *
//* 21/03/06 rff           |-param�tre $point construit � partir tables polygones &points      *
//*                        | (proc�dure lien_polygone)                                         *
//* 15/04/07 jmb           |- ajout auteur du point (nouveau champ)                            *
//*                        |                                                                   *
//* 14/03/08 jmb	   |	passage en _OLD, remplac� par la version avec Gmaps            *
//* 21/03/08 sly           | l'id�e de r�utilisation recherche<->fiche me semble de plus en    *
//*                        | plus idiote quand je vois le nombre de "if" je vais donc s�parer  *
//*                        | ou peut-�tre pas, y'a quand m�me des bout de code en commun       *
//* 27/06/2008 sly         | FIXME un avis ?                                                   *
//* 30/10/2008 sly         | Oui ! voici la version compl�te, fiche point                      *
//**********************************************************************************************

function presentation_infos_general_point($rqpoint)
{
	global $config; // sert pour gmaps, avec la clef d'authentif

	$lien_point_debut="";$lien_point_fin="";

	// lien de modif  uniquement si le visiteur est un mod�rateur 
	// ou si c'est cet utilisateur du forum qui a rentr� le point
	$html_construct .= "	<div class='fiche_cadre'> \n";

	if ( $_GET["static"] == 1 )
	{
		// USINE A GAZ debut.... vraiment trop compliqu�
		// Gmaps est l� justement pour eviter tout le bordel de projection. mercator ...
		//  NE PAS UTILISER
		//
		// ca suffit pas, distorsion due a mercator
		//$degreesparpixelzoom0["lat"] = 0.703125 ;
		$degreesparpixelzoom0 = 1.40625 ;
		$radiansparpixelzoom0 = 0.0122718462890625 ;
		// Pour connaitre le nb de degree par pixel:
		// $degreeparpixelzoom0 / (2^zoom)
		// car	 a chaque niveau de zoom, googlmaps multiplie par 2
		// attention, ca fait des paquets de decimales!
	
		$w = 500;
		$h = 500;
		$zoom = 10;

		$degreesparpixel = $degreesparpixelzoom0 / pow(2,$zoom) ;
		$radiansparpixel = deg2rad($radiansparpixelzoom0) / pow(2,$zoom) ;

		// donc limite minimum = $center - ($w/2 x $degreesparpixel) 
		$minlat= $rqpoint->latitude - ($h/2 * $degreesparpixel);
		$maxlat= $rqpoint->latitude + ($h/2 * $degreesparpixel);
		$minlong= $rqpoint->longitude - ($w/2 * $degreesparpixel);
		$maxlong= $rqpoint->longitude + ($w/2 * $degreesparpixel);

		$req= " SELECT * FROM points
				WHERE
					latitude BETWEEN $minlat AND $maxlat
					AND longitude BETWEEN $minlong AND $maxlong";
		$res = mysql_query($req);
		
		$areas="";
		echo "<pre>";
		while ( $point = mysql_fetch_object($res) )
		{ 
			// donc  200 pixels,  � $degreeparpixel / 2^zoom

			$markers[] = $point->latitude.",".$point->longitude ;
			//selon Wikipedia, projection mercator:
			// x = lon - lon_centre
			// y = atanh( sin( lat ) )
			// imprecision y = ln ( (1/cos(lat)) + tan(lat) )
			echo (deg2rad( $point->longitude) - deg2rad( $rqpoint->longitude));
			$x = deg2rad( $point->longitude ) ; // entre 0 et 1
			$y = atanh( sin( deg2rad($point->latitude) ) );// / $radiansparpixel; // entre 0 et 1
			$impy = log( 1/cos(deg2rad($point->latitude)) + tan(deg2rad($point->latitude)) );
			// on multiplie par W et H pour avoir des pixels
			var_dump("$x           $y    $impy    $point->nom");
			$y = round( ($maxlat - $point->latitude) / $degreesparpixel ) ;
			$x = round( ($point->longitude - $minlong) / $degreesparpixel );
			$areas .= "<area
						href='/index.php'
						alt='blah' title=\"$point->nom\"
						shape='circle'
						coords='$x,$y,8' />\n";
		}
		echo"</pre>";

		$url = "http://maps.google.com/staticmap?";
		$url .= "center=$rqpoint->latitude,$rqpoint->longitude";
		$url .= "&amp;zoom=$zoom";
		$url .= "&amp;size=$w"."x$h";
		$url .= "&amp;markers=". join("|",$markers) ;
		$url .= "&amp;key=".$config["gmaps_key"] ;
		echo "
			<div class='gmaps' style='overflow: hidden; float: right;'>
				<img src='$url' usemap='#vignet' alt='carte de vignette' />
				<map id='vignet' name='vignet'>
					$areas
				</map>
			</div>
		";
	} // fin static map
	// FIN USINE A GAZ pas utilis�e... on vire donc ??? FIXME SLY 21/03/08 // 21/04 JMB: pas encore, si le static maps s'ameliore cot� gg, ca peu devenir interessant pour les temps de chargements
	// Ok, je te laisse g�rer sly 16/05/08

	//-------------------DEBUT VIGNET
	//coordonn�es du point en x:longitude et y:latitude
	$centre = array( "x" => $rqpoint->longitude, "y" => $rqpoint->latitude );
	// insertion du DIV qui contient la vignette gmaps, et inclusion des fichiers javascript
	$html_construct .="
	<div style='float: right;'>
		<div
			class='gmaps'
			id='mapvignette'
			style='width: 200px; height: 300px; overflow: hidden; '>
		</div>
		<a href='/nav.php?lat=$rqpoint->latitude&amp;long=$rqpoint->longitude&amp;zoom=14'>Voir sur la carte</a>
	</div>
	";
	//-------------------------FIN VIGNETTE

	//--------DEBUT ENCADRE-----
	// pass� en liste DD/DL pour la logique (jmb 03 08)
	$html_construct .= "\n\n
	<!-- ========= DEBUT DE LA LISTE d'INFOS =======  -->
	<dl style='margin: 2px;'>
	";
	// rajout d'un bloc identit� principale ( nom, massif, type )


		$html_construct .="
		<dt class='condense'>Fiche de :</dt>
		<dd class='condense'><em>";

	$html_construct.=bbcode2html($rqpoint->nom);

	// Un bouton "modifier" cette fiche pour : les mod�rateurs, ou celui qui a rentr� cette fiche si elle n'a pas �t� modifi�e depuis
	if (isset($_SESSION['id_utilisateur'])
				AND ( ($_SESSION['niveau_moderation']>=1) OR ($_SESSION['id_utilisateur']==$rqpoint->id_auteur_derniere_modification))
		)
		$lien_modifier="<a class='groupir' style='font-size: smaller ;' href='/point_formulaire_modification.php?id_point=".$rqpoint->id_point."'>[Modifier]</a>";
	else
		$lien_modifier="";
		$html_construct .="</em> $lien_modifier, </dd>
			<dd class='condense'>".bbcode2html($rqpoint->nom_type)."</dd>
			";
		$html_construct.="<br/>";
		
	// rajout de +ieurs blocs que si cest le format complet (proprio, acces, remark, pub, photos...)
	// rajout d'un bloc "nb places" si necessaire
	if ($rqpoint->equivalent_places!="") {
		$html_construct .="
		<dt class='condense'>$rqpoint->equivalent_places:</dt>
			<dd class='condense'>".bbcode2html($rqpoint->places)."<br /></dd>
		";
	}
	// localisation du point
	$html_construct.="<dt class='condense'>Localisation :</dt>
				<dd class='condense'>".localisation($rqpoint->polygones)."<br /></dd>";

	$html_construct .="
			<dt class='condense'>Sur le site depuis:</dt>
				<dd class='condense'>".date("d/m/Y",$rqpoint->date_insertion)."</dd>
		";
	// rajout d'un bloc derni�re modification si le champ derni�re modification ou id n'est pas vide
	if ($rqpoint->auteur_derniere_modification != "" OR $rqpoint->id_auteur_derniere_modification!=0) 
	{
		if ($rqpoint->id_auteur_derniere_modification!=0) 
		{ // si le visiteur �tait loggu� alors on fait un lien vers sa fiche utilisateur phpBB
			$lien=$config['fiche_utilisateur'].$rqpoint->id_auteur_derniere_modification;
			$lien_debut="<a href=\"".$lien."\">";
			$lien_fin="</a>";
		} else 
			{$lien_fin="";$lien_debut=""; }

		$html_construct .= "
			<dt class='condense'>Derni�re modification par </dt>
				<dd class='condense'>$lien_debut".bbcode2html($rqpoint->auteur_derniere_modification)."$lien_fin</dd>
		";
		// Dans le cas ou date de derni�re modification n'est pas z�ro, on l'indique.
		if ($rqpoint->date_derniere_modification!="0000-00-00")
		$html_construct .= "
			<dt class='condense'>du </dt>
				<dd class='condense'>".date("d/m/Y",$rqpoint->date_modif_timestamp)."</dd>
		";
	} // fin derni�re modification

	// rajout d'un bloc coord GPS
	$html_construct .= "\n<dt>Coordonn�es:</dt>";
		// la qualit� des coordonn�es GPS se trouve maintenant comme informations de plus dans la table
		// si elles sont cach�es on ne les donne pas, sinon on indique leur qualit�e
	$html_construct .="<dd>Altitude: <em>$rqpoint->altitude"."m</em>";
	
		if ($rqpoint->precision_gps==$config['id_coordonees_gps_fausses'])
			$html_construct .= "<dd class='condense'>$rqpoint->nom_precision_gps</dd>";
		else {
			$html_construct .= "
					Lat: <em>$rqpoint->latitude</em>, Lon: <em>$rqpoint->longitude</em>
					<a class='infobulle' href='#vide'>
					";
			if ($rqpoint->id_type_precision_gps==$config['id_coordonees_gps_approximative'])
				$html_construct .="<strong>$rqpoint->nom_precision_gps</strong>";
			else
				$html_construct .=$rqpoint->nom_precision_gps;
			$html_construct.="
					<span>
						Pr�cision: $rqpoint->nom_precision_gps<br />
						<br />
						Lattitude et longitude en Degr�s D�cimaux.<br />
						Syst�me WGS84<br />
					</span>
				</a>
				( <a href=\"/exportations/exportations.php?format=gpx&amp;liste_id_point=$rqpoint->id_point\">gpx</a>,
				  <a href=\"/exportations/exportations.php?format=kml&amp;liste_id_point=$rqpoint->id_point\">kml</a> )

			</dd>
			";
		}
	// fin du bloc GPS

		if ($rqpoint->equivalent_proprio!="") {
			$html_construct .= "
			<dt>$rqpoint->equivalent_proprio</dt>
				<dd>".bbcode2html($rqpoint->proprio);
				// attirer l'oeil des proprio de cabanes
				// coup�, �a perturbe l'oeil, et c'est d�j� pr�sent dans le mode d'emploi
				// je ne pense pas que �a ait servi tant que �a : trop d'info tue l'info sly 18/09/2008
				//if ($rqpoint->id_point_type == 7)
				//	$html_construct .= "  (gestionnaires? <a href='/statique/gestionnaires.php'>cliquez ici!</a>)";
				
			$html_construct .=  "</dd>\n";
		}
		// Acces.
		$html_construct .= "
        	<dt style='clear: left;'>Acc�s:</dt>
				<dd>".bbcode2html($rqpoint->acces)."</dd>
    
        	<dt>Remarques:</dt>
        	<dd>".bbcode2html($rqpoint->remark)."</dd>
		";

		// rajout d'un lien vers bougetoiattitude en cas de cabane (mouais, on bouge pas bocoup)
		if ($rqpoint->id_point_type >= 7 && $rqpoint->id_point_type <= 10) // c'est une cabane ou un refu
		{
			// ces infos "associatives" dans un bloc DIV
			$html_construct .= "\n  <dt>A lire :</dt>\n <dd>";
			if ($rqpoint->id_point_type == 7) // cest une cabane! 
				$html_construct .= "<a href='http://erchapuis.free.fr/bouge/bonne%20conduite%20refuge5.htm'>B-A BA de l'utilisation des cabanes</a>(charte) (voir le site <a href='http://www.bougetoiattitude.fr.st'>Bouge-Toi Attitude</a>, )";
			$html_construct .= "&nbsp;&nbsp;<a href='".lien_mode_emploi("index")."'>Mode d'Emploi</a> du site";
			$html_construct .= "</dd>"; //fin du DT de bonne parole
		}

		/*******************************************************
		Vu des photos en mignature avec lien
		Remasteuris� par sly
		d�sormais plus rien dans la base, juste des liens vers
		les jpeg ( plus lite pour la base, et les mises en cache )
		et pour pas que je m'arrache les cheveux :-)
		06/03/08 jmb, passage en DD
		*******************************************************/
		$sql_select_comment = "SELECT * FROM commentaires
								WHERE id_point='$rqpoint->id_point' AND photo_existe=1
								ORDER BY date DESC";
		$r_select_comment = mysql_query($sql_select_comment ) or die("mauvaise requete");
// 		$html_construct.='
// 				<br />
// 				<a rel="license" href="http://creativecommons.org/licenses/by-sa/2.0/fr/">
// 					<img alt="Creative Commons License" src="http://i.creativecommons.org/l/by-sa/2.0/fr/88x31.png"/>
// 				</a>';

		// ouverture d'un DT/DD pour les photos
		$html_construct .= "
				<dt>Photos:</dt> 
				<dd><!-- MINIATURES -->\n";

		while ($commentaire_avec_photo=mysql_fetch_object($r_select_comment))
			$html_construct .= "
				<a href='#C$commentaire_avec_photo->id_commentaire'>
						<img height='50'
							style='vertical-align: middle ;'
							src='".$config['rep_web_photos_points'].$commentaire_avec_photo->id_commentaire.".jpeg'
							alt='photo miniature' />
				</a>\n";

		// rff 21/03/06 : Maintenant, nous lib�rons le r�sultat et continuons notre script
		mysql_free_result($r_select_comment);

		$html_construct .= "
			</dd>\n
			<dt>Ajouter :</dt>
			<dd><a class='lien_ajout_commentaire' href='/point_ajout_commentaire.php?id_point=$rqpoint->id_point'>
				un commentaire, une photo, une demande de correction
						</a>
			<br />
			</dd>
			
"; // fermeture du DD des photos

		// *********fin des foto en miniatur -----------------------

		// FIN DES INFOS de fiche COMPLETE
		//*****************

	//------------- FIN DES INFOS --------
	$html_construct .= "
		<!-- ======== FIN DE LA LISTE D'INFOS ======= -->
	</dl>
	";


	// FIN DU DIV de l'ENCADRE
	$html_construct .= "\n </div>\n"; 
	// affiche tout. oui, on aurait pu faire des echo tout du long ... cest historik
	// je change, maintenant on essaye de faire des "vrais" fonctions qui ne font pas des echo � tout bout de champ
	// l'id�e du $html_construct est donc TRES bonne seulon moi, � propager sly 21/03/2008
	return $html_construct; 

}//end presentation_infos_general_point

//**********************************************************************************************
//* Nom de la fonction:    | bbcode2html                                                       *
//* Date :                 |                                                                   *
//* Cr�ateur :             | sly                                                               *
//* R�le de la fonction:   | Afin d'�viter le cross site scripting et permettre de mettre un   *
//*                        | peu de mise en page dans les fiches de points mais aussi          *
//*                        | d'afficher convenablement le message en provenance du forum       *
//*------------------------|-------------------------------------------------------------------*
//* Param�tres(Nom E/S)    | R�le                                                              *
//*------------------------|-------------------------------------------------------------------*
//* $texte             E   | le texte en bbcode                                                *
//* retourne               | le code en HTML
//*------------------------|-------------------------------------------------------------------*
//* Modifications(date Nom)| Elements modifi�s, ajout�s ou supprim�s                           *
//*------------------------|-------------------------------------------------------------------*
//* ???? yip               |r�cup�ration du code de yip                                        *
//* 21/03/08 sly           |cr�ation initiale de la fonction                                   *
//* 26/05/08 jmb		| correction bug des multiples [b] (rajout d'un ? pour une regex ungreedy)*
//**********************************************************************************************
function bbcode2html($texte,$autoriser_html=FALSE)
{

// �tape 1
// nouvelle fonction qui permet de faire des liens internes entre les fiches :
// [->457] cr�er un lien qui pointe vers la fiche du point d'id 457

$occurences_trouvees=preg_match_all("/\[\-\>([0-9]*)\]/",$texte,$occurence);

if ($occurences_trouvees!=0)
{
	for ($x=0;$x<$occurences_trouvees;$x++)
	{	
		$infos_point=infos_point($occurence[1][$x]);
		$texte=str_replace($occurence[0][$x],"[url=".lien_point($infos_point->nom,$infos_point->nom_massif,$infos_point->id_point,$infos_point->nom_type)."]$infos_point->nom[/url]",$texte);
	}
}


// �tape 2 : on �vite qu'un petit malin injecte du HTML ( style javascript pas sympa )
// sauf si on veut expr�ss�ment autoriser une entr�e en HTML
if (!$autoriser_html)
	$html=htmlentities($texte);
else
	$html=$texte;

// gestion de la majorit� des tag bbcode
$searcharray = array(
		"/\[img:(.*)\](.+?)\[\/img:(.*)\]/s",
		"/\[img\](.+?)\[\/img\]/s",
		"/\[url:(.*)\](.+?)\[\/url:(.*)\]/s",
		"/\[url\](.+?)\[\/url\]/s",
		"/\[url=(.+?):(.*)\](.+?)\[\/url:(.*)\]/s",
		"/\[url=(.+?)\](.+?)\[\/url\]/s",
		"/\[b:(.*)\](.+?)\[\/b:(.*)\]/s",
		"/\[b\](.*?)\[\/b\]/s",
		"/\[i:(.*)\](.+?)\[\/i:(.*)\]/s",
		"/\[i\](.+?)\[\/i\]/s",
		"/\[u:(.*)\](.+?)\[\/u:(.*)\]/s",
		"/\[u\](.+?)\[\/u\]/s",
		"/\[code:(.*)\](.+?)\[\/code:(.*)\]/s",
		"/\[code\](.+?)\[\/code\]/s",
		"/\[quote:(.*)\](.+?)\[\/quote:(.*)\]/s",
		"/\[quote\](.+?)\[\/quote\]/s",
		"/\[quote=(.+?):(.*)\](.+?)\[\/quote:(.*)\]/s",
		"/\[quote=(.+?)\](.+?)\[\/quote\]/s",
		"/\[color=(.+?):(.*)\](.+?)\[\/color:(.*)\]/s",
		"/\[color=(.+?)\](.+?)\[\/color\]/s",
		"/:([a-z]+):/",
		"/\[t\]/"
	);
	$replacearray = array(
		"<img src='$2' alt='photo du forum' /><br />",
		"<img src='$1' alt='photo du forum' /><br />",
		"<a href='$2'>$2</a>",
		"<a href='$1'>$1</a>",
		"<a href='$2'>$3</a>",
		"<a href='$1'>$2</a>",
		"<em>$2</em>",
		"<em>$1</em>",
		"<i>$2</i>",
		"<i>$1</i>",
		"<u>$2</u>",
		"<u>$1</u>",
		"<code>$2</code>",
		"<code>$1</code>",
		"<blockquote><p>$2</p></blockquote>",
		"<blockquote><p>$1</p></blockquote>",
		"<blockquote><p>$2</p></blockquote>",
		"<blockquote><p>$1</p></blockquote>",
		"<span style='color: $1'>$3</span>",
		"<span style='color: $1'>$2</span>",
		" - ",
		"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"
	);
	$html = preg_replace($searcharray, $replacearray, $html); 

// transformation automatique des url
// le truc bizarre devant : ([ :\.;,\n]) c'est pour ne transformer que les urls isol�es
// et �viter de retransformer celles contenant du bbcode
// exemple : coucouwww.coucou ne sera pas transform�
// [url=http://www ne le sera pas non plus
// il doit bien rester quelques cas � am�liorer, mais pour l'instant �a � l'air d�j� bien sly 25/03/2008
// peut-�tre faudrait il en fait faire une n�gation comme : tout SAUF quand le caract�re pr�c�dent est une lettre ou un "=" ? sly 26/03/2008

// FIXME Je pense qu'il ne faudrait pas passer �a en HTML directement, mais en bbcode et laisser faire la routine
// si dessus sly 27/06/2008

// au format http://truc 
$urlauto_pattern = "/([ :\.;,\n])(http:\/\/\w\S*)/i";
$urlauto_replace = "$1<a href=\"$2\">$2</a>";
$html = preg_replace($urlauto_pattern,$urlauto_replace,$html);

// au format www.
$urlauto_pattern = "/([ :\.;,\n])(www.\w\S*)/i";
$urlauto_replace = "$1<a href=\"http://$2\">$2</a>";
$html = preg_replace($urlauto_pattern,$urlauto_replace,$html);

// gestion des retours � la ligne et des espace ajout� volontairement pour la mise en forme
if (!$autoriser_html)
{
	$html = str_replace("\r\n", "<br />", $html);
	$html = str_replace("\n", "<br />", $html);
	$html = str_replace("\r", "<br />", $html);
	$html = str_replace("  ", " &nbsp;", $html);
}
return $html;
}

?>
