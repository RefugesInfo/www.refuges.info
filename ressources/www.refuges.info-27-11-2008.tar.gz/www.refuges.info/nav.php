<?php
//**********************************************************************************************
//* Nom du module:         | nav.php                                                       *
//* Date :                 |                                                                   *
//* Cr�ateur :             |                                                                   *
//* R�le du module :       | Pr�paration d'une page HTML de type 'navigation satellite'(NASA)  *
//*                        | avec une zone de d�termination de crit�res de choix (couches) et  *
//*                        | une fonction de zoomage. Des crit�res tels que 'refuges', villes, *
//*                        | apparaissent au dessus d'un fond de carte.                        *
//*                        | La page ainsi pr�par�e comporte un script Java permettant la s�-  *
//*                        | lection des points chauds ("ex: refuges") de la carte et renvoi   *
//*                        | vers un lien sur clic souris. Le d�placement de la souris sur le  *
//*                        | fond de carte provoque l'affichage des coordonn�es du point.      *
//*                        |                                                                   *
//*------------------------|-------------------------------------------------------------------*
//* Modifications(date Nom)| Elements modifi�s, ajout�s ou supprim�s                           *
//*------------------------|-------------------------------------------------------------------*
//* ??/11/07 jmb           |*nouvelle version, avec googlemaps *
//*                        | toujours des bugs avec IE *
//* 01/12/07 jmb           | nlle version et chgt de nom (etait wms_nav2.php avant)
//* 24/07/08 jmb	   | mise en place $if_pub, cens� transferer de la pub au header. + warning nouvelle caledonie
//**********************************************************************************************


// fonctions divers et avariees
require("./include/fonctions.php");
require("./include/fonctions_autoconnexion.php");
require_once("./include/fonctions_massifs.php");
require("./include/fonctions_gmaps.php");
require("./include/fonctions_pubs.php");

// l'URL d'appel de la page 
// typiquement:  /nav/Massif/34/Vercors/  pour le referenceement google
$tableau_url=explode('/',$_SERVER['PATH_INFO']);
if ( isset( $tableau_url[2] ) )
	$id_polygone = $tableau_url[2] ;
	
//-----------------------------------
// l'entete transmis a header.php
if (isset($id_polygone) )
{
	//echo $id_polygone;
    $infos_polygone=infos_polygone($id_polygone); // recup des infos
    $titre_page="Refuges et sommets dans $infos_polygone->art_def_poly $infos_polygone->type_polygone $infos_polygone->article_partitif $infos_polygone->nom_polygone";
    $description=$titre_page.". Possibilit� de navigation avec choix de la l�gende sur les divers points du massif" ;
}
else
    $description=$titre_page="Navigation sur les photos satellite";

$if_javascript= "
<!--  CHARGEMENT DES LIBS GOOG MAPS -->
<!-- gros script google maps contenant toute l'API , avec notre clef d'enregistrement-->
<script src='http://maps.google.com/maps?file=api&amp;v=2.x&amp;key=". $config["gmaps_key"] ."' type='text/javascript' charset='iso-8859-1'></script>

<script type='text/javascript' charset='iso-8859-1'>
	// pr�-charge les IMAGES de points

	". GM_cree_icones_points() ."
</script>

<!-- les fonctions maison gmaps -->
<script type='text/javascript' src='/include/gmaps.js' charset='iso-8859-1'></script>
";

// INDISPENSABLE a Gmaps
$if_onloadscript = " onload=\"init_icones(); navigateur(document.getElementById('mapnav')); $if_p \" onunload=\"GUnload();\"";

// affichage de la pub en haut. surtout depuis que j'ai l'impression que certains ne font que naviguer sur google.
$if_pubmarchpas = "<div style='float: right; height: 50px;'>".bandeau_publicitaireXML(2,"",50)."</div>";
//$if_pub = "<div style='float: right; height: 50px; overflow: hidden'>".bandeau_publicitaire()."</div>";

include("./include/header.php"); //inclut l'en-t�te, le corps de message (body)
?>

<!-- afficher le titre du massif (en mode massif) -->
<h3 id='titrepage'><?php echo $titre_page ." :" ; ?></h3>
<!-- Si on est appel� par un massif, le massif en variable globale JS -->

<?php
	// Protection IP de l'IRD de nouvelle caledonie qui represente 40% des hits (1% des download)
	// avertissement TEMPORAIRE,, quand l'IP sera dans des niveau correct, a enlever.
	// 193.51.249.162 (firewall-NAT1.ird.nc)
	// voir peut etre tivincent si ca deconne toujours au bout d'un moment (il a pass� 1 an � l'IRD)
	
	// tivincent m'a contacte, il pense que c'est le RSS. je met en place un mouchard au RSS.

/*	if ($_SERVER['REMOTE_ADDR'] == '193.51.249.162')
	{
		echo "<h1>A l'attention du personnel de l'IRD</h1>";
		echo "<h2>Ce site parle de refuges, en nouvelle-cal�donie comme ailleurs</h2>";
		echo "<p>
				Pour surfer sur les cartes de google, sans les refuges,
				allez directement chez google ici: <a href='http://maps.google.fr/maps?ll=-21,165&t=p&z=8'>maps.google.fr/maps?ll=-21,165&t=p&z=8</a>
			</p>
			<p>
				<em>plus de 6000 requ�tes par jour proviennent de l'IRD</em>,
				merci de penser a notre serveur qui n'est pas aussi puissant que celui de google ...
				<br />�crivez � jm@refuges.info pour faire enlever ce message. Nous l'enl�verons quand l'IRD ne repr�sentera plus la moiti� du trafic.
			</p>
			";
	}
*/
?>
	

<script type='text/javascript' charset='iso-8859-1'>
	var idmassif<?php if (isset($id_polygone)) echo "=".$id_polygone; ?> ; 
</script>

 <form
	id='choix_legende'
	style='float: left; width: 200px ;'
	action='/exportations/formulaire_exportations.php'
	>

<?php
	if (isset( $id_polygone ) )
	{
	?>
		<fieldset><legend>Filtrer</legend>
			<label>
				<input name='id_massif'
						type='checkbox'
						checked='checked'
						value='<?php echo $id_polygone; ?>'
						onclick="if (this.checked) {
									idmassif=<?php echo $id_polygone; ?> ; 
									document.getElementById('titrepage').firstChild.nodeValue='<?php echo addslashes($titre_page); ?>' ; 
								} else {
									idmassif=undefined ;
									document.getElementById('titrepage').firstChild.nodeValue='Navigation sur les cartes' ; 
								}
								MAJ_carte( document.getElementsByName('id_point_type[]') );
								" />
				<?php echo $infos_polygone->nom_polygone ." uniquement"; ?>
			</label>
		</fieldset>
	<?php
	}
	
echo GM_cree_legende_POI() ;
?>
	
				<!-- voir les coordonnee GPS en temps reel  -->
				<fieldset><legend>Coordonn�es WGS84</legend>
					<label>
						<input name='gps_lat' id='gps_lat' type='text' size='5' readonly='readonly' />,
						<input name='gps_lng' id='gps_lng' type='text' size='5' readonly='readonly' />

						<!-- garde les coordonnee de la BBOX sous le coude pour l'export -->
						<input name='bbox_latmin' id='bbox_latmin' type='hidden' value='' />
						<input name='bbox_latmax' id='bbox_latmax' type='hidden' value='' />
						<input name='bbox_lngmin' id='bbox_lngmin' type='hidden' value='' />
						<input name='bbox_lngmax' id='bbox_lngmax' type='hidden' value='' />
						
					</label>
				</fieldset>

				<!-- Cadre pour rajouter un point, si c'est valid�, un click rajoutera un point au lieu de se deplacer -->
				<fieldset><legend>Ajouter un point</legend>
					<label>
						<input name='mode_ajout' id='mode_ajout' type='checkbox'
							onclick='if (this.checked) { alert("Cliquer sur la carte pour ajouter un point � cet emplacement");}'
						/>
						autoriser l'ajout
					</label>
				</fieldset>

				<!-- Cadre pour exporter la vue, appelle la page "exportations.php" avec les param en GET -->
				<fieldset><legend>Exportation</legend>
					<label>
						<input type='submit' value='Exporter la vue actuelle' />
					</label>
				</fieldset>

 </form>

<!-- LA MAP GOOGLE EST ICI !!!! elle se resize toute seule a la taille de fenetre -->
<div class='gmaps' id='mapnav' style='height: 80%; margin-left: 210px;'>
</div>

<script type='text/javascript' charset='iso-8859-1'>
	// rends disponible un massif, pour limiter la recherche. sera utilis� par MAJ_Carte
	// normalement,il y a tjs un idmassif. navigateur independant abandonn�
	// sauf si, INTENTIONNELLEMENT, on modifie l'url pour changer idmassif en 0
<?php

// tentons de comprendre, comment on choisir le centre ?
if ($_GET['lat']!="" AND $_GET['long']!="" AND $_GET['zoom']!="")
{
echo "
var lat=$_GET[lat];
var long=$_GET[long];
var taille_zoom=$_GET[zoom]
";
}
elseif (isset($id_polygone) )
	echo GM_cree_massifs(FALSE,$id_polygone) ; // si =0, on les mets tous
if ($_GET['choix_layer']!="")
	echo "var choix_layer='$choix_layer';";
else
	echo "var choix_layer='';";


echo "\n</script>";

include("./include/footer.php");
?>
