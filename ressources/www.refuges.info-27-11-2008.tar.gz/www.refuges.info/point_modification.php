<?php
//**********************************************************************************************
//* Nom du module:         | point_modification.php                                            *
//* Date :                 |                                                                   *
//* Cr�ateur :             |                                                                   *
//* R�le du module :       | Fin modification de la fiche de point.                            *
//*                        |                                                                   *
//*------------------------|-------------------------------------------------------------------*
//* Modifications(date Nom)| Elements modifi�s, ajout�s ou supprim�s                           *
//*------------------------|-------------------------------------------------------------------*
//* 21/03/06 rff           |*Insertion infos de session : utile pour gestion du cache & menu   *
//*                        | gestion.                                                          *
//*                        |                                                                   *
//* 06/03/08 jmb           | new version avec d�co, deplacage de blocs avant le header         *
//* 28/07/08 jmb	| rajout ucfirst pour majuscule
//**********************************************************************************************

/*************************************
3 cas pour arriver ici, toujours depuis point_formulaire_modification:
-Creation d'un point
-Modification d'un point
-suppression d'un point
*************************/

require("./include/fonctions.php");
require("./include/fonctions_points.php");
require("./include/fonctions_autoconnexion.php");
require("./include/fonctions_massifs.php");
include("./include/header.php");

connexion_base();
$html="<div class=\"contenu\">
";

if ( $_POST["action"] == 'Ajouter' || $_POST["action"] == 'Modifier' )
{
// on rempli l'object $point � mettre � jour/ajouter en fonction des param�tres POST
// si l'id_point peut �tre vide, cela indiquera une cr�ation 
// ATTENTION BIDOULLE si on fait attention � ce que le nom des champs correspondent, on gagne du temps avec :
foreach ($_POST as $nom => $value)
	$point->$nom=$value;

// pour s'assurer dans le cas d'une cr�ation et dire qu'il ne s'agit pas d'un mod�le
// normalement le par d�faut de la table SQL devrait suffir, mais bon
if ($_POST["action"] == 'Ajouter')
	$point->modele=0;

// doit on ou non changer le dernier a avoir modifi� cette fiche ?
if (isset($_SESSION['id_utilisateur']) AND $_POST['modification_mineure']!=1 )
{
	$point->auteur_derniere_modification=$_POST["auteur_modification"];
	$point->id_auteur_derniere_modification=$_SESSION['id_utilisateur'];
}

// FIXME a partir d'ici le code n'est vraiment pas beau, il doit y avoir moyen de se passer
// du switch est de fusionner Ajouter et Modifier

function faire_boulot($point)
{
$retour=modification_ajout_point($point);
if ($retour=="erreur_nom")
	$html.="<p><strong>Le nom du point est le seul champ non facultatif</strong></p>";
if ($retour=="erreur_point_inexistant")
	$html.="<p><strong>Le point que vous tentez de modifier n'existe pas</strong></p>";
$ret->html=$html;
$ret->id_point=$retour;
return $ret;
}
}
$texte_duplication="<p>
<h5>Pour continuer :</h5>
<a href='/point_formulaire_modification.php?dupliquer=$point->id_point'> Dupliquer un autre point d'information au MEME endroit</a></p>";
switch ($_POST["action"]) // le bouton ajouter ou modifier ou supprimer
{
    case 'Ajouter':
		$html .= "<h3>Ajout d'un point</h3>";
	// Etant donn� que des robots, ou des peu scrupuleux remplissent avec des faux points, on les vire ici
	if ( !isset($_SESSION['id_utilisateur']) AND ($_POST['lettre_securite']!="d") )
		$html.="<h4>! ERREUR ! vous n'avez pas rentr� la lettre demand�e</h4>";
	else
	{
	$ret=faire_boulot($point);
	if ($ret->html!="")
		$html.=$ret->html;
	else
	{
	$html.="<h4>Merci de votre contribution</h4>
		<h5>le point vient d'�tre ajout� dans la base</h5>
		<h5>le forum du point a �t� cr��...</h5>\n";
	$html.="<p><a href=\"".lien_point_lent($ret->id_point)."\">Cliquez ici pour voir la fiche qui vient d'etre ajout�</a></p>
	$texte_duplication";
	}
	}
      break;
    case 'Modifier':
	$ret=faire_boulot($point);
	if ($ret->html!="")
		$html.=$ret->html;
	else
	{
		$html .= "<h3>Modification d'un point</h3>";
      $html.="<h4>Merci de votre contribution</h4>
		<h5>le point vient d'�tre modifi�</h5>
		<p><a href=\"".lien_point_lent($ret->id_point)."\">Cliquez ici pour revenir � la fiche modifi�e</a></p>
		$texte_duplication";
	}
      break;
    case 'Supprimer':
		$html .= "<h3>Suppression d'un point</h3>";
      suppression_point($_POST['id_point']);
      $html.="<h4>Le point choisi a �t� supprim� !</h4>";
      break;
  } // fin du switch action

  
$html.="\n<p>Seuls les administrateurs sont autoris�s � modifier ou supprimer. Envoyer un mail ou contactez-les sur le forum pour toute question.</p>";
$html .="</div>";

print($html);
  // C'est enregistre, cassos. fini basta.

include("./include/footer.php");
?>  
