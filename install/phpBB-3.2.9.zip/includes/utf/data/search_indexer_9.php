<?php return array('䶵'=>'䶵','一'=>'一');
