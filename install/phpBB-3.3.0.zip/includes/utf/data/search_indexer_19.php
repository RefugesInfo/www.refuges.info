<?php return array('龻'=>'龻');
