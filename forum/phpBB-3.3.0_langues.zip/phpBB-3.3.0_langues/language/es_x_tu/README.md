phpBB 3.3 Casual Honorifics (Tú)
================================

Official Spanish Translation for phpBB 3.3 Casual Honorifics (TÚ)

Traducción oficial a Español de phpBB 3.3 Casual Honorifics (TÚ)

## Corrección de errores
Para cualquier cambio a realizar, simplemente editar para realizar el cambio y "Pull Request".

## License
[GNU General Public License v2](http://opensource.org/licenses/GPL-2.0)

## Autores
ThE KuKa (Raúl Arroyo Monzo)

Huan Manwë (Juan Manuel)


## © [phpBB España](http://www.phpbb-es.com) 2003 / 2019

![phpBB Spain](http://www.phpbb-es.com/images/logo_es.png) 
