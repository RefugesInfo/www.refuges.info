phpBB 3.3 Casual Honorifics (Tú)
================================

Official Spanish Translation for phpBB 3.2 Casual Honorifics (TÚ)

Traducción oficial a Español de phpBB 3.2 Casual Honorifics (TÚ)

## Autores
ThE KuKa (Raúl Arroyo Monzo) - 3.0.10 to 3.1

ThE KuKa (Raúl Arroyo Monzo) - 3.1 to 3.2

ThE KuKa (Raúl Arroyo Monzo) - 3.2 to 3.3

Huan Manwë (Juan Manuel) - phpBB 3.0.x to 3.0.9

## © [phpBB España](http://www.phpbb-es.com) 2003 / 2019
