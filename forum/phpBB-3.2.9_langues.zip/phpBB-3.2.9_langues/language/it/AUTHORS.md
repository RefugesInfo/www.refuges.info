# phpBB - Italian Translation

## Author

* phpBB-Store - https://www.phpbb-store.it

## Contributors

* Alex75 (Alex75) - Administrator
* Angolo (Angolo) - Translator
* Darkman (Darkman) - Translator

## Past Contributors

* effeppi (effeppi)
* phpBB.it
* phpbbitalia.net
