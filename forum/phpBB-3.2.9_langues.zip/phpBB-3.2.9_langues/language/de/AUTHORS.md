Deutsche Übersetzung durch die Übersetzer-Gruppe von phpBB.de
Das aktuelle Team online: https://www.phpbb.de/go/ubersetzerteam

## Übersetzer

### Teamleiter

* PhilippK (Philipp Kordowich) [2003 - ]

### Übersetzer
(derzeit keine)

### Korrektoren
(derzeit keine)

### Contributoren

* bantu (Andreas Fischer) [2014 - ]
* BlackHawk87/Crizz0 (Christian Schnegelberger) [2014 - ]
* mungo (Ingo Migliarina) [2003 - ]
* nickvergessen (Joas Schilling) [2014 - ]
* gn#36 (Martin Beckmann) [2015 - ]


## Ehemalige Mitglieder

### Übersetzer

* aurora876 (Rike Schroeder) [2010 - 2011]
* cgerharz (Christopher Gerharz) [2006 - 2007]
* farbijan (Fabian Koglin) [2009 - 2011]
* Light Lan (Paul Rauch) [2007 - 2008]
* MartectX (Martin Rauscher) [2008 - 2011]
* rabbit (Dirk Gaffke) [2004 - 2007]
* 7emper51 [2010 - 2011]

### Korrektoren

* ingo (Ingo Köhler) [2004 - 2013]
* Loewenherz (Frank Doerr) [2004 - 2011]
* Tuxman (Sven Knurr) [2010 - 2013]
