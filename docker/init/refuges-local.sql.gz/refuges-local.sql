--
-- PostgreSQL database dump
--

-- Dumped from database version 15.8 (Debian 15.8-1.pgdg110+1)
-- Dumped by pg_dump version 15.8 (Debian 15.8-1.pgdg110+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


--
-- Name: varchar_ci; Type: DOMAIN; Schema: public; Owner: -
--

CREATE DOMAIN public.varchar_ci AS character varying(255) NOT NULL DEFAULT ''::character varying;


--
-- Name: _varchar_ci_equal(public.varchar_ci, public.varchar_ci); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._varchar_ci_equal(public.varchar_ci, public.varchar_ci) RETURNS boolean
    LANGUAGE sql STRICT
    AS $_$SELECT LOWER($1) = LOWER($2)$_$;


--
-- Name: _varchar_ci_greater_equals(public.varchar_ci, public.varchar_ci); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._varchar_ci_greater_equals(public.varchar_ci, public.varchar_ci) RETURNS boolean
    LANGUAGE sql STRICT
    AS $_$SELECT LOWER($1) >= LOWER($2)$_$;


--
-- Name: _varchar_ci_greater_than(public.varchar_ci, public.varchar_ci); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._varchar_ci_greater_than(public.varchar_ci, public.varchar_ci) RETURNS boolean
    LANGUAGE sql STRICT
    AS $_$SELECT LOWER($1) > LOWER($2)$_$;


--
-- Name: _varchar_ci_less_equal(public.varchar_ci, public.varchar_ci); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._varchar_ci_less_equal(public.varchar_ci, public.varchar_ci) RETURNS boolean
    LANGUAGE sql STRICT
    AS $_$SELECT LOWER($1) <= LOWER($2)$_$;


--
-- Name: _varchar_ci_less_than(public.varchar_ci, public.varchar_ci); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._varchar_ci_less_than(public.varchar_ci, public.varchar_ci) RETURNS boolean
    LANGUAGE sql STRICT
    AS $_$SELECT LOWER($1) < LOWER($2)$_$;


--
-- Name: _varchar_ci_not_equal(public.varchar_ci, public.varchar_ci); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public._varchar_ci_not_equal(public.varchar_ci, public.varchar_ci) RETURNS boolean
    LANGUAGE sql STRICT
    AS $_$SELECT LOWER($1) != LOWER($2)$_$;


--
-- Name: <; Type: OPERATOR; Schema: public; Owner: -
--

CREATE OPERATOR public.< (
    FUNCTION = public._varchar_ci_less_than,
    LEFTARG = public.varchar_ci,
    RIGHTARG = public.varchar_ci,
    COMMUTATOR = OPERATOR(public.>),
    NEGATOR = OPERATOR(public.>=),
    RESTRICT = scalarltsel,
    JOIN = scalarltjoinsel
);


--
-- Name: <=; Type: OPERATOR; Schema: public; Owner: -
--

CREATE OPERATOR public.<= (
    FUNCTION = public._varchar_ci_less_equal,
    LEFTARG = public.varchar_ci,
    RIGHTARG = public.varchar_ci,
    COMMUTATOR = OPERATOR(public.>=),
    NEGATOR = OPERATOR(public.>),
    RESTRICT = scalarltsel,
    JOIN = scalarltjoinsel
);


--
-- Name: <>; Type: OPERATOR; Schema: public; Owner: -
--

CREATE OPERATOR public.<> (
    FUNCTION = public._varchar_ci_not_equal,
    LEFTARG = public.varchar_ci,
    RIGHTARG = public.varchar_ci,
    COMMUTATOR = OPERATOR(public.<>),
    NEGATOR = OPERATOR(public.=),
    RESTRICT = neqsel,
    JOIN = neqjoinsel
);


--
-- Name: =; Type: OPERATOR; Schema: public; Owner: -
--

CREATE OPERATOR public.= (
    FUNCTION = public._varchar_ci_equal,
    LEFTARG = public.varchar_ci,
    RIGHTARG = public.varchar_ci,
    COMMUTATOR = OPERATOR(public.=),
    NEGATOR = OPERATOR(public.<>),
    MERGES,
    HASHES,
    RESTRICT = eqsel,
    JOIN = eqjoinsel
);


--
-- Name: >; Type: OPERATOR; Schema: public; Owner: -
--

CREATE OPERATOR public.> (
    FUNCTION = public._varchar_ci_greater_than,
    LEFTARG = public.varchar_ci,
    RIGHTARG = public.varchar_ci,
    COMMUTATOR = OPERATOR(public.<),
    NEGATOR = OPERATOR(public.<=),
    RESTRICT = scalargtsel,
    JOIN = scalargtjoinsel
);


--
-- Name: >=; Type: OPERATOR; Schema: public; Owner: -
--

CREATE OPERATOR public.>= (
    FUNCTION = public._varchar_ci_greater_equals,
    LEFTARG = public.varchar_ci,
    RIGHTARG = public.varchar_ci,
    COMMUTATOR = OPERATOR(public.<=),
    NEGATOR = OPERATOR(public.<),
    RESTRICT = scalargtsel,
    JOIN = scalargtjoinsel
);


--
-- Name: commentaires_id_commentaire_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.commentaires_id_commentaire_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: commentaires; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.commentaires (
    id_commentaire integer DEFAULT nextval('public.commentaires_id_commentaire_seq'::regclass) NOT NULL,
    date timestamp without time zone DEFAULT now() NOT NULL,
    id_point integer DEFAULT 0 NOT NULL,
    texte text NOT NULL,
    auteur_commentaire character varying(80),
    photo_existe integer DEFAULT 0 NOT NULL,
    date_photo date,
    demande_correction integer DEFAULT 0 NOT NULL,
    id_createur_commentaire integer DEFAULT 0 NOT NULL,
    raison_demande_correction text
);


--
-- Name: COLUMN commentaires.date; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.commentaires.date IS 'ajout de default now, qu''on ait pas besoin de le gerer';


--
-- Name: emails_bounce_id_email_bounce_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.emails_bounce_id_email_bounce_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 2147483647
    CACHE 1;


--
-- Name: emails_bounce; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.emails_bounce (
    id_email_bounce integer DEFAULT nextval('public.emails_bounce_id_email_bounce_seq'::regclass) NOT NULL,
    date timestamp without time zone NOT NULL,
    contenu text NOT NULL,
    a_traiter boolean DEFAULT true
);


--
-- Name: historique_modifications_poin_id_historique_modifications_p_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.historique_modifications_poin_id_historique_modifications_p_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: historique_modifications_points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.historique_modifications_points (
    id_historique_modifications_points integer DEFAULT nextval('public.historique_modifications_poin_id_historique_modifications_p_seq'::regclass) NOT NULL,
    id_point integer DEFAULT 0 NOT NULL,
    id_user integer DEFAULT 0 NOT NULL,
    date_modification timestamp with time zone NOT NULL,
    raison_modification text,
    avant text NOT NULL,
    apres text NOT NULL,
    type_modification character(50) DEFAULT 'modification'::bpchar NOT NULL
);


--
-- Name: pages_wiki; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pages_wiki (
    nom_page character varying(200) NOT NULL,
    date timestamp without time zone DEFAULT now() NOT NULL,
    contenu text
);


--
-- Name: phpbb3_acl_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_acl_groups (
    group_id integer DEFAULT 0 NOT NULL,
    forum_id integer DEFAULT 0 NOT NULL,
    auth_option_id integer DEFAULT 0 NOT NULL,
    auth_role_id integer DEFAULT 0 NOT NULL,
    auth_setting smallint DEFAULT 0 NOT NULL
);


--
-- Name: phpbb3_acl_options_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.phpbb3_acl_options_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: phpbb3_acl_options; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_acl_options (
    auth_option_id integer DEFAULT nextval('public.phpbb3_acl_options_seq'::regclass) NOT NULL,
    auth_option character varying(50) DEFAULT ''::character varying NOT NULL,
    is_global smallint DEFAULT 0 NOT NULL,
    is_local smallint DEFAULT 0 NOT NULL,
    founder_only smallint DEFAULT 0 NOT NULL
);


--
-- Name: phpbb3_acl_roles_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.phpbb3_acl_roles_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: phpbb3_acl_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_acl_roles (
    role_id integer DEFAULT nextval('public.phpbb3_acl_roles_seq'::regclass) NOT NULL,
    role_name character varying(255) DEFAULT ''::character varying NOT NULL,
    role_description character varying(4000) DEFAULT ''::character varying NOT NULL,
    role_type character varying(10) DEFAULT ''::character varying NOT NULL,
    role_order smallint DEFAULT 0 NOT NULL
);


--
-- Name: phpbb3_acl_roles_data; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_acl_roles_data (
    role_id integer DEFAULT 0 NOT NULL,
    auth_option_id integer DEFAULT 0 NOT NULL,
    auth_setting smallint DEFAULT 0 NOT NULL
);


--
-- Name: phpbb3_acl_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_acl_users (
    user_id integer DEFAULT 0 NOT NULL,
    forum_id integer DEFAULT 0 NOT NULL,
    auth_option_id integer DEFAULT 0 NOT NULL,
    auth_role_id integer DEFAULT 0 NOT NULL,
    auth_setting smallint DEFAULT 0 NOT NULL
);


--
-- Name: phpbb3_attachments_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.phpbb3_attachments_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: phpbb3_attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_attachments (
    attach_id integer DEFAULT nextval('public.phpbb3_attachments_seq'::regclass) NOT NULL,
    post_msg_id integer DEFAULT 0 NOT NULL,
    topic_id integer DEFAULT 0 NOT NULL,
    in_message smallint DEFAULT 0 NOT NULL,
    poster_id integer DEFAULT 0 NOT NULL,
    is_orphan smallint DEFAULT 1 NOT NULL,
    physical_filename character varying(255) DEFAULT ''::character varying NOT NULL,
    real_filename character varying(255) DEFAULT ''::character varying NOT NULL,
    download_count integer DEFAULT 0 NOT NULL,
    attach_comment character varying(4000) DEFAULT ''::character varying NOT NULL,
    extension character varying(100) DEFAULT ''::character varying NOT NULL,
    mimetype character varying(100) DEFAULT ''::character varying NOT NULL,
    filesize integer DEFAULT 0 NOT NULL,
    filetime integer DEFAULT 0 NOT NULL,
    thumbnail smallint DEFAULT 0 NOT NULL
);


--
-- Name: phpbb3_banlist_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.phpbb3_banlist_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: phpbb3_banlist; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_banlist (
    ban_id integer DEFAULT nextval('public.phpbb3_banlist_seq'::regclass) NOT NULL,
    ban_userid integer DEFAULT 0 NOT NULL,
    ban_ip character varying(40) DEFAULT ''::character varying NOT NULL,
    ban_email character varying(100) DEFAULT ''::character varying NOT NULL,
    ban_start integer DEFAULT 0 NOT NULL,
    ban_end integer DEFAULT 0 NOT NULL,
    ban_exclude smallint DEFAULT 0 NOT NULL,
    ban_reason character varying(255) DEFAULT ''::character varying NOT NULL,
    ban_give_reason character varying(255) DEFAULT ''::character varying NOT NULL
);


--
-- Name: phpbb3_bbcodes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_bbcodes (
    bbcode_id smallint DEFAULT 0 NOT NULL,
    bbcode_tag character varying(16) DEFAULT ''::character varying NOT NULL,
    bbcode_helpline character varying(255) DEFAULT ''::character varying NOT NULL,
    display_on_posting smallint DEFAULT 0 NOT NULL,
    bbcode_match character varying(4000) DEFAULT ''::character varying NOT NULL,
    bbcode_tpl text DEFAULT ''::text NOT NULL,
    first_pass_match text DEFAULT ''::text NOT NULL,
    first_pass_replace text DEFAULT ''::text NOT NULL,
    second_pass_match text DEFAULT ''::text NOT NULL,
    second_pass_replace text DEFAULT ''::text NOT NULL
);


--
-- Name: phpbb3_bookmarks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_bookmarks (
    topic_id integer DEFAULT 0 NOT NULL,
    user_id integer DEFAULT 0 NOT NULL
);


--
-- Name: phpbb3_bots_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.phpbb3_bots_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: phpbb3_bots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_bots (
    bot_id integer DEFAULT nextval('public.phpbb3_bots_seq'::regclass) NOT NULL,
    bot_active smallint DEFAULT 1 NOT NULL,
    bot_name character varying(255) DEFAULT ''::character varying NOT NULL,
    user_id integer DEFAULT 0 NOT NULL,
    bot_agent character varying(255) DEFAULT ''::character varying NOT NULL,
    bot_ip character varying(255) DEFAULT ''::character varying NOT NULL
);


--
-- Name: phpbb3_captcha_answers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_captcha_answers (
    question_id integer DEFAULT 0 NOT NULL,
    answer_text character varying(255) DEFAULT ''::character varying NOT NULL
);


--
-- Name: phpbb3_captcha_questions_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.phpbb3_captcha_questions_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: phpbb3_captcha_questions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_captcha_questions (
    question_id integer DEFAULT nextval('public.phpbb3_captcha_questions_seq'::regclass) NOT NULL,
    strict smallint DEFAULT 0 NOT NULL,
    lang_id integer DEFAULT 0 NOT NULL,
    lang_iso character varying(30) DEFAULT ''::character varying NOT NULL,
    question_text character varying(4000) DEFAULT ''::character varying NOT NULL
);


--
-- Name: phpbb3_cleantalk_sfw; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_cleantalk_sfw (
    network integer DEFAULT 0 NOT NULL,
    mask integer DEFAULT 0 NOT NULL,
    status smallint DEFAULT '0'::smallint NOT NULL
);


--
-- Name: phpbb3_cleantalk_sfw_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_cleantalk_sfw_logs (
    ip character varying(15) DEFAULT ''::character varying NOT NULL,
    all_entries integer DEFAULT 0,
    blocked_entries integer DEFAULT 0,
    entries_timestamp integer DEFAULT 0
);


--
-- Name: phpbb3_config; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_config (
    config_name character varying(255) DEFAULT ''::character varying NOT NULL,
    config_value character varying(255) DEFAULT ''::character varying NOT NULL,
    is_dynamic smallint DEFAULT 0 NOT NULL
);


--
-- Name: phpbb3_config_text; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_config_text (
    config_name character varying(255) DEFAULT ''::character varying NOT NULL,
    config_value text DEFAULT ''::text NOT NULL
);


--
-- Name: phpbb3_confirm; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_confirm (
    confirm_id character(32) DEFAULT ''::bpchar NOT NULL,
    session_id character(32) DEFAULT ''::bpchar NOT NULL,
    confirm_type smallint DEFAULT 0 NOT NULL,
    code character varying(8) DEFAULT ''::character varying NOT NULL,
    seed integer DEFAULT 0 NOT NULL,
    attempts integer DEFAULT 0 NOT NULL
);


--
-- Name: phpbb3_disallow_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.phpbb3_disallow_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: phpbb3_disallow; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_disallow (
    disallow_id integer DEFAULT nextval('public.phpbb3_disallow_seq'::regclass) NOT NULL,
    disallow_username character varying(255) DEFAULT ''::character varying NOT NULL
);


--
-- Name: phpbb3_drafts_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.phpbb3_drafts_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: phpbb3_drafts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_drafts (
    draft_id integer DEFAULT nextval('public.phpbb3_drafts_seq'::regclass) NOT NULL,
    user_id integer DEFAULT 0 NOT NULL,
    topic_id integer DEFAULT 0 NOT NULL,
    forum_id integer DEFAULT 0 NOT NULL,
    save_time integer DEFAULT 0 NOT NULL,
    draft_subject character varying(255) DEFAULT ''::character varying NOT NULL,
    draft_message text DEFAULT ''::text NOT NULL
);


--
-- Name: phpbb3_ext; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_ext (
    ext_name character varying(255) DEFAULT ''::character varying NOT NULL,
    ext_active smallint DEFAULT 0 NOT NULL,
    ext_state character varying(8000) DEFAULT ''::character varying NOT NULL
);


--
-- Name: phpbb3_extension_groups_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.phpbb3_extension_groups_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: phpbb3_extension_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_extension_groups (
    group_id integer DEFAULT nextval('public.phpbb3_extension_groups_seq'::regclass) NOT NULL,
    group_name character varying(255) DEFAULT ''::character varying NOT NULL,
    cat_id smallint DEFAULT 0 NOT NULL,
    allow_group smallint DEFAULT 0 NOT NULL,
    download_mode smallint DEFAULT 1 NOT NULL,
    upload_icon character varying(255) DEFAULT ''::character varying NOT NULL,
    max_filesize integer DEFAULT 0 NOT NULL,
    allowed_forums character varying(8000) DEFAULT ''::character varying NOT NULL,
    allow_in_pm smallint DEFAULT 0 NOT NULL
);


--
-- Name: phpbb3_extensions_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.phpbb3_extensions_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: phpbb3_extensions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_extensions (
    extension_id integer DEFAULT nextval('public.phpbb3_extensions_seq'::regclass) NOT NULL,
    group_id integer DEFAULT 0 NOT NULL,
    extension character varying(100) DEFAULT ''::character varying NOT NULL
);


--
-- Name: phpbb3_forums_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.phpbb3_forums_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: phpbb3_forums; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_forums (
    forum_id integer DEFAULT nextval('public.phpbb3_forums_seq'::regclass) NOT NULL,
    parent_id integer DEFAULT 0 NOT NULL,
    left_id integer DEFAULT 0 NOT NULL,
    right_id integer DEFAULT 0 NOT NULL,
    forum_parents text DEFAULT ''::text NOT NULL,
    forum_name character varying(255) DEFAULT ''::character varying NOT NULL,
    forum_desc character varying(4000) DEFAULT ''::character varying NOT NULL,
    forum_desc_bitfield character varying(255) DEFAULT ''::character varying NOT NULL,
    forum_desc_options integer DEFAULT 7 NOT NULL,
    forum_desc_uid character varying(8) DEFAULT ''::character varying NOT NULL,
    forum_link character varying(255) DEFAULT ''::character varying NOT NULL,
    forum_password character varying(255) DEFAULT ''::character varying NOT NULL,
    forum_style integer DEFAULT 0 NOT NULL,
    forum_image character varying(255) DEFAULT ''::character varying NOT NULL,
    forum_rules character varying(4000) DEFAULT ''::character varying NOT NULL,
    forum_rules_link character varying(255) DEFAULT ''::character varying NOT NULL,
    forum_rules_bitfield character varying(255) DEFAULT ''::character varying NOT NULL,
    forum_rules_options integer DEFAULT 7 NOT NULL,
    forum_rules_uid character varying(8) DEFAULT ''::character varying NOT NULL,
    forum_topics_per_page smallint DEFAULT 0 NOT NULL,
    forum_type smallint DEFAULT 0 NOT NULL,
    forum_status smallint DEFAULT 0 NOT NULL,
    forum_last_post_id integer DEFAULT 0 NOT NULL,
    forum_last_poster_id integer DEFAULT 0 NOT NULL,
    forum_last_post_subject character varying(255) DEFAULT ''::character varying NOT NULL,
    forum_last_post_time integer DEFAULT 0 NOT NULL,
    forum_last_poster_name character varying(255) DEFAULT ''::character varying NOT NULL,
    forum_last_poster_colour character varying(6) DEFAULT ''::character varying NOT NULL,
    forum_flags smallint DEFAULT 32 NOT NULL,
    display_on_index smallint DEFAULT 1 NOT NULL,
    enable_indexing smallint DEFAULT 1 NOT NULL,
    enable_icons smallint DEFAULT 1 NOT NULL,
    enable_prune smallint DEFAULT 0 NOT NULL,
    prune_next integer DEFAULT 0 NOT NULL,
    prune_days integer DEFAULT 0 NOT NULL,
    prune_viewed integer DEFAULT 0 NOT NULL,
    prune_freq integer DEFAULT 0 NOT NULL,
    display_subforum_list smallint DEFAULT 1 NOT NULL,
    forum_options integer DEFAULT 0 NOT NULL,
    forum_posts_approved integer DEFAULT 0 NOT NULL,
    forum_posts_unapproved integer DEFAULT 0 NOT NULL,
    forum_posts_softdeleted integer DEFAULT 0 NOT NULL,
    forum_topics_approved integer DEFAULT 0 NOT NULL,
    forum_topics_unapproved integer DEFAULT 0 NOT NULL,
    forum_topics_softdeleted integer DEFAULT 0 NOT NULL,
    enable_shadow_prune smallint DEFAULT 0 NOT NULL,
    prune_shadow_days integer DEFAULT 7 NOT NULL,
    prune_shadow_freq integer DEFAULT 1 NOT NULL,
    prune_shadow_next integer DEFAULT 0 NOT NULL,
    display_subforum_limit smallint DEFAULT '0'::smallint NOT NULL,
    CONSTRAINT phpbb3_forums_forum_style_check CHECK ((forum_style >= 0)),
    CONSTRAINT phpbb3_forums_forum_style_check1 CHECK ((forum_style >= 0))
);


--
-- Name: phpbb3_forums_access; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_forums_access (
    forum_id integer DEFAULT 0 NOT NULL,
    user_id integer DEFAULT 0 NOT NULL,
    session_id character(32) DEFAULT ''::bpchar NOT NULL
);


--
-- Name: phpbb3_forums_track; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_forums_track (
    user_id integer DEFAULT 0 NOT NULL,
    forum_id integer DEFAULT 0 NOT NULL,
    mark_time integer DEFAULT 0 NOT NULL
);


--
-- Name: phpbb3_forums_watch; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_forums_watch (
    forum_id integer DEFAULT 0 NOT NULL,
    user_id integer DEFAULT 0 NOT NULL,
    notify_status smallint DEFAULT 0 NOT NULL
);


--
-- Name: phpbb3_groups_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.phpbb3_groups_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: phpbb3_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_groups (
    group_id integer DEFAULT nextval('public.phpbb3_groups_seq'::regclass) NOT NULL,
    group_type smallint DEFAULT 1 NOT NULL,
    group_founder_manage smallint DEFAULT 0 NOT NULL,
    group_skip_auth smallint DEFAULT 0 NOT NULL,
    group_name public.varchar_ci DEFAULT ''::character varying NOT NULL,
    group_desc character varying(4000) DEFAULT ''::character varying NOT NULL,
    group_desc_bitfield character varying(255) DEFAULT ''::character varying NOT NULL,
    group_desc_options integer DEFAULT 7 NOT NULL,
    group_desc_uid character varying(8) DEFAULT ''::character varying NOT NULL,
    group_display smallint DEFAULT 0 NOT NULL,
    group_avatar character varying(255) DEFAULT ''::character varying NOT NULL,
    group_avatar_type character varying(255) DEFAULT ''::character varying NOT NULL,
    group_avatar_width smallint DEFAULT 0 NOT NULL,
    group_avatar_height smallint DEFAULT 0 NOT NULL,
    group_rank integer DEFAULT 0 NOT NULL,
    group_colour character varying(6) DEFAULT ''::character varying NOT NULL,
    group_sig_chars integer DEFAULT 0 NOT NULL,
    group_receive_pm smallint DEFAULT 0 NOT NULL,
    group_message_limit integer DEFAULT 0 NOT NULL,
    group_legend integer DEFAULT 0 NOT NULL,
    group_max_recipients integer DEFAULT 0 NOT NULL
);


--
-- Name: phpbb3_icons_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.phpbb3_icons_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: phpbb3_icons; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_icons (
    icons_id integer DEFAULT nextval('public.phpbb3_icons_seq'::regclass) NOT NULL,
    icons_url character varying(255) DEFAULT ''::character varying NOT NULL,
    icons_width smallint DEFAULT 0 NOT NULL,
    icons_height smallint DEFAULT 0 NOT NULL,
    icons_alt character varying(255) DEFAULT ''::character varying NOT NULL,
    icons_order integer DEFAULT 0 NOT NULL,
    display_on_posting smallint DEFAULT 1 NOT NULL
);


--
-- Name: phpbb3_lang_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.phpbb3_lang_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: phpbb3_lang; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_lang (
    lang_id smallint DEFAULT nextval('public.phpbb3_lang_seq'::regclass) NOT NULL,
    lang_iso character varying(30) DEFAULT ''::character varying NOT NULL,
    lang_dir character varying(30) DEFAULT ''::character varying NOT NULL,
    lang_english_name character varying(100) DEFAULT ''::character varying NOT NULL,
    lang_local_name character varying(255) DEFAULT ''::character varying NOT NULL,
    lang_author character varying(255) DEFAULT ''::character varying NOT NULL
);


--
-- Name: phpbb3_log_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.phpbb3_log_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: phpbb3_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_log (
    log_id integer DEFAULT nextval('public.phpbb3_log_seq'::regclass) NOT NULL,
    log_type smallint DEFAULT 0 NOT NULL,
    user_id integer DEFAULT 0 NOT NULL,
    forum_id integer DEFAULT 0 NOT NULL,
    topic_id integer DEFAULT 0 NOT NULL,
    post_id integer DEFAULT 0 NOT NULL,
    reportee_id integer DEFAULT 0 NOT NULL,
    log_ip character varying(40) DEFAULT ''::character varying NOT NULL,
    log_time integer DEFAULT 0 NOT NULL,
    log_operation character varying(4000) DEFAULT ''::character varying NOT NULL,
    log_data text DEFAULT ''::text NOT NULL
);


--
-- Name: phpbb3_login_attempts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_login_attempts (
    attempt_ip character varying(40) DEFAULT ''::character varying NOT NULL,
    attempt_browser character varying(150) DEFAULT ''::character varying NOT NULL,
    attempt_forwarded_for character varying(255) DEFAULT ''::character varying NOT NULL,
    attempt_time integer DEFAULT 0 NOT NULL,
    user_id integer DEFAULT 0 NOT NULL,
    username character varying(255) DEFAULT '0'::character varying NOT NULL,
    username_clean public.varchar_ci DEFAULT '0'::character varying NOT NULL
);


--
-- Name: phpbb3_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_migrations (
    migration_name character varying(255) DEFAULT ''::character varying NOT NULL,
    migration_depends_on character varying(8000) DEFAULT ''::character varying NOT NULL,
    migration_schema_done smallint DEFAULT 0 NOT NULL,
    migration_data_done smallint DEFAULT 0 NOT NULL,
    migration_data_state character varying(8000) DEFAULT ''::character varying NOT NULL,
    migration_start_time integer DEFAULT 0 NOT NULL,
    migration_end_time integer DEFAULT 0 NOT NULL
);


--
-- Name: phpbb3_moderator_cache; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_moderator_cache (
    forum_id integer DEFAULT 0 NOT NULL,
    user_id integer DEFAULT 0 NOT NULL,
    username character varying(255) DEFAULT ''::character varying NOT NULL,
    group_id integer DEFAULT 0 NOT NULL,
    group_name character varying(255) DEFAULT ''::character varying NOT NULL,
    display_on_index smallint DEFAULT 1 NOT NULL
);


--
-- Name: phpbb3_modules_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.phpbb3_modules_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: phpbb3_modules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_modules (
    module_id integer DEFAULT nextval('public.phpbb3_modules_seq'::regclass) NOT NULL,
    module_enabled smallint DEFAULT 1 NOT NULL,
    module_display smallint DEFAULT 1 NOT NULL,
    module_basename character varying(255) DEFAULT ''::character varying NOT NULL,
    module_class character varying(10) DEFAULT ''::character varying NOT NULL,
    parent_id integer DEFAULT 0 NOT NULL,
    left_id integer DEFAULT 0 NOT NULL,
    right_id integer DEFAULT 0 NOT NULL,
    module_langname character varying(255) DEFAULT ''::character varying NOT NULL,
    module_mode character varying(255) DEFAULT ''::character varying NOT NULL,
    module_auth character varying(255) DEFAULT ''::character varying NOT NULL
);


--
-- Name: phpbb3_notification_emails; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_notification_emails (
    notification_type_id smallint DEFAULT '0'::smallint NOT NULL,
    item_id integer DEFAULT 0 NOT NULL,
    item_parent_id integer DEFAULT 0 NOT NULL,
    user_id integer DEFAULT 0 NOT NULL
);


--
-- Name: phpbb3_notification_types_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.phpbb3_notification_types_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: phpbb3_notification_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_notification_types (
    notification_type_id smallint DEFAULT nextval('public.phpbb3_notification_types_seq'::regclass) NOT NULL,
    notification_type_name character varying(255) DEFAULT ''::character varying NOT NULL,
    notification_type_enabled smallint DEFAULT 1 NOT NULL
);


--
-- Name: phpbb3_notifications_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.phpbb3_notifications_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: phpbb3_notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_notifications (
    notification_id integer DEFAULT nextval('public.phpbb3_notifications_seq'::regclass) NOT NULL,
    notification_type_id smallint DEFAULT 0 NOT NULL,
    item_id integer DEFAULT 0 NOT NULL,
    item_parent_id integer DEFAULT 0 NOT NULL,
    user_id integer DEFAULT 0 NOT NULL,
    notification_read smallint DEFAULT 0 NOT NULL,
    notification_time integer DEFAULT 1 NOT NULL,
    notification_data character varying(4000) DEFAULT ''::character varying NOT NULL
);


--
-- Name: phpbb3_oauth_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_oauth_accounts (
    user_id integer DEFAULT 0 NOT NULL,
    provider character varying(255) DEFAULT ''::character varying NOT NULL,
    oauth_provider_id character varying(4000) DEFAULT ''::character varying NOT NULL
);


--
-- Name: phpbb3_oauth_states; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_oauth_states (
    user_id integer DEFAULT 0 NOT NULL,
    session_id character(32) DEFAULT ''::bpchar NOT NULL,
    provider character varying(255) DEFAULT ''::character varying NOT NULL,
    oauth_state character varying(255) DEFAULT ''::character varying NOT NULL
);


--
-- Name: phpbb3_oauth_tokens; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_oauth_tokens (
    user_id integer DEFAULT 0 NOT NULL,
    session_id character(32) DEFAULT ''::bpchar NOT NULL,
    provider character varying(255) DEFAULT ''::character varying NOT NULL,
    oauth_token text DEFAULT ''::text NOT NULL
);


--
-- Name: phpbb3_poll_options; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_poll_options (
    poll_option_id smallint DEFAULT 0 NOT NULL,
    topic_id integer DEFAULT 0 NOT NULL,
    poll_option_text character varying(4000) DEFAULT ''::character varying NOT NULL,
    poll_option_total integer DEFAULT 0 NOT NULL
);


--
-- Name: phpbb3_poll_votes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_poll_votes (
    topic_id integer DEFAULT 0 NOT NULL,
    poll_option_id smallint DEFAULT 0 NOT NULL,
    vote_user_id integer DEFAULT 0 NOT NULL,
    vote_user_ip character varying(40) DEFAULT ''::character varying NOT NULL
);


--
-- Name: phpbb3_posts_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.phpbb3_posts_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: phpbb3_posts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_posts (
    post_id integer DEFAULT nextval('public.phpbb3_posts_seq'::regclass) NOT NULL,
    topic_id integer DEFAULT 0 NOT NULL,
    forum_id integer DEFAULT 0 NOT NULL,
    poster_id integer DEFAULT 0 NOT NULL,
    icon_id integer DEFAULT 0 NOT NULL,
    poster_ip character varying(40) DEFAULT ''::character varying NOT NULL,
    post_time integer DEFAULT 0 NOT NULL,
    post_reported smallint DEFAULT 0 NOT NULL,
    enable_bbcode smallint DEFAULT 1 NOT NULL,
    enable_smilies smallint DEFAULT 1 NOT NULL,
    enable_magic_url smallint DEFAULT 1 NOT NULL,
    enable_sig smallint DEFAULT 1 NOT NULL,
    post_username character varying(255) DEFAULT ''::character varying NOT NULL,
    post_subject character varying(255) DEFAULT ''::character varying NOT NULL,
    post_text text DEFAULT ''::text NOT NULL,
    post_checksum character varying(32) DEFAULT ''::character varying NOT NULL,
    post_attachment smallint DEFAULT 0 NOT NULL,
    bbcode_bitfield character varying(255) DEFAULT ''::character varying NOT NULL,
    bbcode_uid character varying(8) DEFAULT ''::character varying NOT NULL,
    post_postcount smallint DEFAULT 1 NOT NULL,
    post_edit_time integer DEFAULT 0 NOT NULL,
    post_edit_reason character varying(255) DEFAULT ''::character varying NOT NULL,
    post_edit_user integer DEFAULT 0 NOT NULL,
    post_edit_count smallint DEFAULT 0 NOT NULL,
    post_edit_locked smallint DEFAULT 0 NOT NULL,
    post_visibility smallint DEFAULT 0 NOT NULL,
    post_delete_time integer DEFAULT 0 NOT NULL,
    post_delete_reason character varying(255) DEFAULT ''::character varying NOT NULL,
    post_delete_user integer DEFAULT 0 NOT NULL
);


--
-- Name: phpbb3_privmsgs_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.phpbb3_privmsgs_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: phpbb3_privmsgs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_privmsgs (
    msg_id integer DEFAULT nextval('public.phpbb3_privmsgs_seq'::regclass) NOT NULL,
    root_level integer DEFAULT 0 NOT NULL,
    author_id integer DEFAULT 0 NOT NULL,
    icon_id integer DEFAULT 0 NOT NULL,
    author_ip character varying(40) DEFAULT ''::character varying NOT NULL,
    message_time integer DEFAULT 0 NOT NULL,
    enable_bbcode smallint DEFAULT 1 NOT NULL,
    enable_smilies smallint DEFAULT 1 NOT NULL,
    enable_magic_url smallint DEFAULT 1 NOT NULL,
    enable_sig smallint DEFAULT 1 NOT NULL,
    message_subject character varying(255) DEFAULT ''::character varying NOT NULL,
    message_text text DEFAULT ''::text NOT NULL,
    message_edit_reason character varying(255) DEFAULT ''::character varying NOT NULL,
    message_edit_user integer DEFAULT 0 NOT NULL,
    message_attachment smallint DEFAULT 0 NOT NULL,
    bbcode_bitfield character varying(255) DEFAULT ''::character varying NOT NULL,
    bbcode_uid character varying(8) DEFAULT ''::character varying NOT NULL,
    message_edit_time integer DEFAULT 0 NOT NULL,
    message_edit_count smallint DEFAULT 0 NOT NULL,
    to_address character varying(4000) DEFAULT ''::character varying NOT NULL,
    bcc_address character varying(4000) DEFAULT ''::character varying NOT NULL,
    message_reported smallint DEFAULT 0 NOT NULL
);


--
-- Name: phpbb3_privmsgs_folder_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.phpbb3_privmsgs_folder_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: phpbb3_privmsgs_folder; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_privmsgs_folder (
    folder_id integer DEFAULT nextval('public.phpbb3_privmsgs_folder_seq'::regclass) NOT NULL,
    user_id integer DEFAULT 0 NOT NULL,
    folder_name character varying(255) DEFAULT ''::character varying NOT NULL,
    pm_count integer DEFAULT 0 NOT NULL
);


--
-- Name: phpbb3_privmsgs_rules_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.phpbb3_privmsgs_rules_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: phpbb3_privmsgs_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_privmsgs_rules (
    rule_id integer DEFAULT nextval('public.phpbb3_privmsgs_rules_seq'::regclass) NOT NULL,
    user_id integer DEFAULT 0 NOT NULL,
    rule_check integer DEFAULT 0 NOT NULL,
    rule_connection integer DEFAULT 0 NOT NULL,
    rule_string character varying(255) DEFAULT ''::character varying NOT NULL,
    rule_user_id integer DEFAULT 0 NOT NULL,
    rule_group_id integer DEFAULT 0 NOT NULL,
    rule_action integer DEFAULT 0 NOT NULL,
    rule_folder_id integer DEFAULT 0 NOT NULL
);


--
-- Name: phpbb3_privmsgs_to; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_privmsgs_to (
    msg_id integer DEFAULT 0 NOT NULL,
    user_id integer DEFAULT 0 NOT NULL,
    author_id integer DEFAULT 0 NOT NULL,
    pm_deleted smallint DEFAULT 0 NOT NULL,
    pm_new smallint DEFAULT 1 NOT NULL,
    pm_unread smallint DEFAULT 1 NOT NULL,
    pm_replied smallint DEFAULT 0 NOT NULL,
    pm_marked smallint DEFAULT 0 NOT NULL,
    pm_forwarded smallint DEFAULT 0 NOT NULL,
    folder_id integer DEFAULT 0 NOT NULL
);


--
-- Name: phpbb3_profile_fields_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.phpbb3_profile_fields_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: phpbb3_profile_fields; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_profile_fields (
    field_id integer DEFAULT nextval('public.phpbb3_profile_fields_seq'::regclass) NOT NULL,
    field_name character varying(255) DEFAULT ''::character varying NOT NULL,
    field_type character varying(100) DEFAULT ''::character varying NOT NULL,
    field_ident character varying(20) DEFAULT ''::character varying NOT NULL,
    field_length character varying(20) DEFAULT ''::character varying NOT NULL,
    field_minlen character varying(255) DEFAULT ''::character varying NOT NULL,
    field_maxlen character varying(255) DEFAULT ''::character varying NOT NULL,
    field_novalue character varying(255) DEFAULT ''::character varying NOT NULL,
    field_default_value character varying(255) DEFAULT ''::character varying NOT NULL,
    field_validation character varying(64) DEFAULT ''::character varying NOT NULL,
    field_required smallint DEFAULT 0 NOT NULL,
    field_show_on_reg smallint DEFAULT 0 NOT NULL,
    field_hide smallint DEFAULT 0 NOT NULL,
    field_no_view smallint DEFAULT 0 NOT NULL,
    field_active smallint DEFAULT 0 NOT NULL,
    field_order integer DEFAULT 0 NOT NULL,
    field_show_profile smallint DEFAULT 0 NOT NULL,
    field_show_on_vt smallint DEFAULT 0 NOT NULL,
    field_show_novalue smallint DEFAULT 0 NOT NULL,
    field_show_on_pm smallint DEFAULT 0 NOT NULL,
    field_show_on_ml smallint DEFAULT 0 NOT NULL,
    field_is_contact smallint DEFAULT 0 NOT NULL,
    field_contact_desc character varying(255) DEFAULT ''::character varying NOT NULL,
    field_contact_url character varying(255) DEFAULT ''::character varying NOT NULL
);


--
-- Name: phpbb3_profile_fields_data; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_profile_fields_data (
    user_id integer DEFAULT 0 NOT NULL,
    pf_phpbb_interests text DEFAULT ''::text NOT NULL,
    pf_phpbb_occupation text DEFAULT ''::text NOT NULL,
    pf_phpbb_location character varying(255) DEFAULT ''::character varying NOT NULL,
    pf_phpbb_youtube character varying(255) DEFAULT ''::character varying NOT NULL,
    pf_phpbb_facebook character varying(255) DEFAULT ''::character varying NOT NULL,
    pf_phpbb_icq character varying(255) DEFAULT ''::character varying NOT NULL,
    pf_phpbb_skype character varying(255) DEFAULT ''::character varying NOT NULL,
    pf_phpbb_twitter character varying(255) DEFAULT ''::character varying NOT NULL,
    pf_phpbb_website character varying(255) DEFAULT ''::character varying NOT NULL,
    pf_phpbb_yahoo character varying(255) DEFAULT ''::character varying NOT NULL
);


--
-- Name: phpbb3_profile_fields_lang; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_profile_fields_lang (
    field_id integer DEFAULT 0 NOT NULL,
    lang_id integer DEFAULT 0 NOT NULL,
    option_id integer DEFAULT 0 NOT NULL,
    field_type character varying(100) DEFAULT ''::character varying NOT NULL,
    lang_value character varying(255) DEFAULT ''::character varying NOT NULL
);


--
-- Name: phpbb3_profile_lang; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_profile_lang (
    field_id integer DEFAULT 0 NOT NULL,
    lang_id integer DEFAULT 0 NOT NULL,
    lang_name character varying(255) DEFAULT ''::character varying NOT NULL,
    lang_explain character varying(4000) DEFAULT ''::character varying NOT NULL,
    lang_default_value character varying(255) DEFAULT ''::character varying NOT NULL
);


--
-- Name: phpbb3_qa_confirm; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_qa_confirm (
    session_id character(32) DEFAULT ''::bpchar NOT NULL,
    confirm_id character(32) DEFAULT ''::bpchar NOT NULL,
    lang_iso character varying(30) DEFAULT ''::character varying NOT NULL,
    question_id integer DEFAULT 0 NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    confirm_type smallint DEFAULT 0 NOT NULL
);


--
-- Name: phpbb3_ranks_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.phpbb3_ranks_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: phpbb3_ranks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_ranks (
    rank_id integer DEFAULT nextval('public.phpbb3_ranks_seq'::regclass) NOT NULL,
    rank_title character varying(255) DEFAULT ''::character varying NOT NULL,
    rank_min integer DEFAULT 0 NOT NULL,
    rank_special smallint DEFAULT 0 NOT NULL,
    rank_image character varying(255) DEFAULT ''::character varying NOT NULL
);


--
-- Name: phpbb3_reports_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.phpbb3_reports_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: phpbb3_reports; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_reports (
    report_id integer DEFAULT nextval('public.phpbb3_reports_seq'::regclass) NOT NULL,
    reason_id smallint DEFAULT 0 NOT NULL,
    post_id integer DEFAULT 0 NOT NULL,
    user_id integer DEFAULT 0 NOT NULL,
    user_notify smallint DEFAULT 0 NOT NULL,
    report_closed smallint DEFAULT 0 NOT NULL,
    report_time integer DEFAULT 0 NOT NULL,
    report_text text DEFAULT ''::text NOT NULL,
    pm_id integer DEFAULT 0 NOT NULL,
    reported_post_enable_bbcode smallint DEFAULT 1 NOT NULL,
    reported_post_enable_smilies smallint DEFAULT 1 NOT NULL,
    reported_post_enable_magic_url smallint DEFAULT 1 NOT NULL,
    reported_post_text text DEFAULT ''::text NOT NULL,
    reported_post_uid character varying(8) DEFAULT ''::character varying NOT NULL,
    reported_post_bitfield character varying(255) DEFAULT ''::character varying NOT NULL
);


--
-- Name: phpbb3_reports_reasons_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.phpbb3_reports_reasons_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: phpbb3_reports_reasons; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_reports_reasons (
    reason_id smallint DEFAULT nextval('public.phpbb3_reports_reasons_seq'::regclass) NOT NULL,
    reason_title character varying(255) DEFAULT ''::character varying NOT NULL,
    reason_description text DEFAULT ''::text NOT NULL,
    reason_order smallint DEFAULT 0 NOT NULL
);


--
-- Name: phpbb3_search_results; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_search_results (
    search_key character varying(32) DEFAULT ''::character varying NOT NULL,
    search_time integer DEFAULT 0 NOT NULL,
    search_keywords text DEFAULT ''::text NOT NULL,
    search_authors text DEFAULT ''::text NOT NULL
);


--
-- Name: phpbb3_search_wordlist_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.phpbb3_search_wordlist_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: phpbb3_search_wordlist; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_search_wordlist (
    word_id integer DEFAULT nextval('public.phpbb3_search_wordlist_seq'::regclass) NOT NULL,
    word_text character varying(255) DEFAULT ''::character varying NOT NULL,
    word_common smallint DEFAULT 0 NOT NULL,
    word_count integer DEFAULT 0 NOT NULL
);


--
-- Name: phpbb3_search_wordmatch; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_search_wordmatch (
    post_id integer DEFAULT 0 NOT NULL,
    word_id integer DEFAULT 0 NOT NULL,
    title_match smallint DEFAULT 0 NOT NULL
);


--
-- Name: phpbb3_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_sessions (
    session_id character(32) DEFAULT ''::bpchar NOT NULL,
    session_user_id integer DEFAULT 0 NOT NULL,
    session_last_visit integer DEFAULT 0 NOT NULL,
    session_start integer DEFAULT 0 NOT NULL,
    session_time integer DEFAULT 0 NOT NULL,
    session_ip character varying(40) DEFAULT ''::character varying NOT NULL,
    session_browser character varying(150) DEFAULT ''::character varying NOT NULL,
    session_forwarded_for character varying(255) DEFAULT ''::character varying NOT NULL,
    session_page character varying(255) DEFAULT ''::character varying NOT NULL,
    session_viewonline smallint DEFAULT 1 NOT NULL,
    session_autologin smallint DEFAULT 0 NOT NULL,
    session_admin smallint DEFAULT 0 NOT NULL,
    session_forum_id integer DEFAULT 0 NOT NULL
);


--
-- Name: phpbb3_sessions_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_sessions_keys (
    key_id character(32) DEFAULT ''::bpchar NOT NULL,
    user_id integer DEFAULT 0 NOT NULL,
    last_ip character varying(40) DEFAULT ''::character varying NOT NULL,
    last_login integer DEFAULT 0 NOT NULL
);


--
-- Name: phpbb3_sitelist_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.phpbb3_sitelist_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: phpbb3_sitelist; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_sitelist (
    site_id integer DEFAULT nextval('public.phpbb3_sitelist_seq'::regclass) NOT NULL,
    site_ip character varying(40) DEFAULT ''::character varying NOT NULL,
    site_hostname character varying(255) DEFAULT ''::character varying NOT NULL,
    ip_exclude smallint DEFAULT 0 NOT NULL
);


--
-- Name: phpbb3_smilies_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.phpbb3_smilies_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: phpbb3_smilies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_smilies (
    smiley_id integer DEFAULT nextval('public.phpbb3_smilies_seq'::regclass) NOT NULL,
    code character varying(50) DEFAULT ''::character varying NOT NULL,
    emotion character varying(255) DEFAULT ''::character varying NOT NULL,
    smiley_url character varying(50) DEFAULT ''::character varying NOT NULL,
    smiley_width smallint DEFAULT 0 NOT NULL,
    smiley_height smallint DEFAULT 0 NOT NULL,
    smiley_order integer DEFAULT 0 NOT NULL,
    display_on_posting smallint DEFAULT 1 NOT NULL
);


--
-- Name: phpbb3_styles_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.phpbb3_styles_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: phpbb3_styles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_styles (
    style_id integer DEFAULT nextval('public.phpbb3_styles_seq'::regclass) NOT NULL,
    style_name character varying(255) DEFAULT ''::character varying NOT NULL,
    style_copyright character varying(255) DEFAULT ''::character varying NOT NULL,
    style_active smallint DEFAULT 1 NOT NULL,
    style_path character varying(100) DEFAULT ''::character varying NOT NULL,
    bbcode_bitfield character varying(255) DEFAULT 'kNg='::character varying NOT NULL,
    style_parent_id integer DEFAULT 0 NOT NULL,
    style_parent_tree character varying(8000) DEFAULT ''::character varying NOT NULL,
    template_id integer DEFAULT 0 NOT NULL,
    theme_id integer DEFAULT 0 NOT NULL,
    imageset_id integer DEFAULT 0 NOT NULL,
    CONSTRAINT phpbb3_styles_imageset_id_check CHECK ((imageset_id >= 0)),
    CONSTRAINT phpbb3_styles_style_id_check CHECK ((style_id >= 0)),
    CONSTRAINT phpbb3_styles_template_id_check CHECK ((template_id >= 0)),
    CONSTRAINT phpbb3_styles_theme_id_check CHECK ((theme_id >= 0))
);


--
-- Name: phpbb3_styles_imageset_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.phpbb3_styles_imageset_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: phpbb3_styles_imageset; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_styles_imageset (
    imageset_id integer DEFAULT nextval('public.phpbb3_styles_imageset_seq'::regclass) NOT NULL,
    imageset_name character varying(255) DEFAULT ''::character varying NOT NULL,
    imageset_copyright character varying(255) DEFAULT ''::character varying NOT NULL,
    imageset_path character varying(100) DEFAULT ''::character varying NOT NULL,
    CONSTRAINT phpbb3_styles_imageset_imageset_id_check CHECK ((imageset_id >= 0)),
    CONSTRAINT phpbb3_styles_imageset_imageset_id_check1 CHECK ((imageset_id >= 0))
);


--
-- Name: phpbb3_styles_imageset_data_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.phpbb3_styles_imageset_data_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: phpbb3_styles_imageset_data; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_styles_imageset_data (
    image_id integer DEFAULT nextval('public.phpbb3_styles_imageset_data_seq'::regclass) NOT NULL,
    image_name character varying(200) DEFAULT ''::character varying NOT NULL,
    image_filename character varying(200) DEFAULT ''::character varying NOT NULL,
    image_lang character varying(30) DEFAULT ''::character varying NOT NULL,
    image_height smallint DEFAULT '0'::smallint NOT NULL,
    image_width smallint DEFAULT '0'::smallint NOT NULL,
    imageset_id integer DEFAULT 0 NOT NULL,
    CONSTRAINT phpbb3_styles_imageset_data_image_height_check CHECK ((image_height >= 0)),
    CONSTRAINT phpbb3_styles_imageset_data_image_id_check CHECK ((image_id >= 0)),
    CONSTRAINT phpbb3_styles_imageset_data_image_id_check1 CHECK ((image_id >= 0)),
    CONSTRAINT phpbb3_styles_imageset_data_image_width_check CHECK ((image_width >= 0)),
    CONSTRAINT phpbb3_styles_imageset_data_imageset_id_check CHECK ((imageset_id >= 0)),
    CONSTRAINT phpbb3_styles_imageset_data_imageset_id_check1 CHECK ((imageset_id >= 0))
);


--
-- Name: phpbb3_styles_template_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.phpbb3_styles_template_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: phpbb3_styles_template; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_styles_template (
    template_id integer DEFAULT nextval('public.phpbb3_styles_template_seq'::regclass) NOT NULL,
    template_name character varying(255) DEFAULT ''::character varying NOT NULL,
    template_copyright character varying(255) DEFAULT ''::character varying NOT NULL,
    template_path character varying(100) DEFAULT ''::character varying NOT NULL,
    bbcode_bitfield character varying(255) DEFAULT 'kNg='::character varying NOT NULL,
    template_storedb smallint DEFAULT '0'::smallint NOT NULL,
    template_inherits_id integer DEFAULT 0 NOT NULL,
    template_inherit_path character varying(255) DEFAULT ''::character varying NOT NULL,
    CONSTRAINT phpbb3_styles_template_template_id_check CHECK ((template_id >= 0)),
    CONSTRAINT phpbb3_styles_template_template_id_check1 CHECK ((template_id >= 0)),
    CONSTRAINT phpbb3_styles_template_template_inherits_id_check CHECK ((template_inherits_id >= 0)),
    CONSTRAINT phpbb3_styles_template_template_storedb_check CHECK ((template_storedb >= 0))
);


--
-- Name: phpbb3_styles_template_data; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_styles_template_data (
    template_id integer DEFAULT 0 NOT NULL,
    template_filename character varying(100) DEFAULT ''::character varying NOT NULL,
    template_included character varying(8000) DEFAULT ''::character varying NOT NULL,
    template_mtime integer DEFAULT 0 NOT NULL,
    template_data text DEFAULT ''::text NOT NULL,
    CONSTRAINT phpbb3_styles_template_data_template_id_check CHECK ((template_id >= 0)),
    CONSTRAINT phpbb3_styles_template_data_template_id_check1 CHECK ((template_id >= 0)),
    CONSTRAINT phpbb3_styles_template_data_template_mtime_check CHECK ((template_mtime >= 0))
);


--
-- Name: phpbb3_styles_theme_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.phpbb3_styles_theme_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: phpbb3_styles_theme; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_styles_theme (
    theme_id integer DEFAULT nextval('public.phpbb3_styles_theme_seq'::regclass) NOT NULL,
    theme_name character varying(255) DEFAULT ''::character varying NOT NULL,
    theme_copyright character varying(255) DEFAULT ''::character varying NOT NULL,
    theme_path character varying(100) DEFAULT ''::character varying NOT NULL,
    theme_storedb smallint DEFAULT '0'::smallint NOT NULL,
    theme_mtime integer DEFAULT 0 NOT NULL,
    theme_data text DEFAULT ''::text NOT NULL,
    CONSTRAINT phpbb3_styles_theme_theme_id_check CHECK ((theme_id >= 0)),
    CONSTRAINT phpbb3_styles_theme_theme_id_check1 CHECK ((theme_id >= 0)),
    CONSTRAINT phpbb3_styles_theme_theme_mtime_check CHECK ((theme_mtime >= 0)),
    CONSTRAINT phpbb3_styles_theme_theme_storedb_check CHECK ((theme_storedb >= 0))
);


--
-- Name: phpbb3_teampage_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.phpbb3_teampage_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: phpbb3_teampage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_teampage (
    teampage_id integer DEFAULT nextval('public.phpbb3_teampage_seq'::regclass) NOT NULL,
    group_id integer DEFAULT 0 NOT NULL,
    teampage_name character varying(255) DEFAULT ''::character varying NOT NULL,
    teampage_position integer DEFAULT 0 NOT NULL,
    teampage_parent integer DEFAULT 0 NOT NULL
);


--
-- Name: phpbb3_topics_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.phpbb3_topics_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: phpbb3_topics; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_topics (
    topic_id integer DEFAULT nextval('public.phpbb3_topics_seq'::regclass) NOT NULL,
    forum_id integer DEFAULT 0 NOT NULL,
    icon_id integer DEFAULT 0 NOT NULL,
    topic_attachment smallint DEFAULT 0 NOT NULL,
    topic_reported smallint DEFAULT 0 NOT NULL,
    topic_title character varying(255) DEFAULT ''::character varying NOT NULL,
    topic_poster integer DEFAULT 0 NOT NULL,
    topic_time integer DEFAULT 0 NOT NULL,
    topic_time_limit integer DEFAULT 0 NOT NULL,
    topic_views integer DEFAULT 0 NOT NULL,
    topic_status smallint DEFAULT 0 NOT NULL,
    topic_type smallint DEFAULT 0 NOT NULL,
    topic_first_post_id integer DEFAULT 0 NOT NULL,
    topic_first_poster_name character varying(255) DEFAULT ''::character varying NOT NULL,
    topic_first_poster_colour character varying(6) DEFAULT ''::character varying NOT NULL,
    topic_last_post_id integer DEFAULT 0 NOT NULL,
    topic_last_poster_id integer DEFAULT 0 NOT NULL,
    topic_last_poster_name character varying(255) DEFAULT ''::character varying NOT NULL,
    topic_last_poster_colour character varying(6) DEFAULT ''::character varying NOT NULL,
    topic_last_post_subject character varying(255) DEFAULT ''::character varying NOT NULL,
    topic_last_post_time integer DEFAULT 0 NOT NULL,
    topic_last_view_time integer DEFAULT 0 NOT NULL,
    topic_moved_id integer DEFAULT 0 NOT NULL,
    topic_bumped smallint DEFAULT 0 NOT NULL,
    topic_bumper integer DEFAULT 0 NOT NULL,
    poll_title character varying(255) DEFAULT ''::character varying NOT NULL,
    poll_start integer DEFAULT 0 NOT NULL,
    poll_length integer DEFAULT 0 NOT NULL,
    poll_max_options smallint DEFAULT 1 NOT NULL,
    poll_last_vote integer DEFAULT 0 NOT NULL,
    poll_vote_change smallint DEFAULT 0 NOT NULL,
    topic_visibility smallint DEFAULT 0 NOT NULL,
    topic_delete_time integer DEFAULT 0 NOT NULL,
    topic_delete_reason character varying(255) DEFAULT ''::character varying NOT NULL,
    topic_delete_user integer DEFAULT 0 NOT NULL,
    topic_posts_approved integer DEFAULT 0 NOT NULL,
    topic_posts_unapproved integer DEFAULT 0 NOT NULL,
    topic_posts_softdeleted integer DEFAULT 0 NOT NULL
);


--
-- Name: phpbb3_topics_posted; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_topics_posted (
    user_id integer DEFAULT 0 NOT NULL,
    topic_id integer DEFAULT 0 NOT NULL,
    topic_posted smallint DEFAULT 0 NOT NULL
);


--
-- Name: phpbb3_topics_track; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_topics_track (
    user_id integer DEFAULT 0 NOT NULL,
    topic_id integer DEFAULT 0 NOT NULL,
    forum_id integer DEFAULT 0 NOT NULL,
    mark_time integer DEFAULT 0 NOT NULL
);


--
-- Name: phpbb3_topics_watch; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_topics_watch (
    topic_id integer DEFAULT 0 NOT NULL,
    user_id integer DEFAULT 0 NOT NULL,
    notify_status smallint DEFAULT 0 NOT NULL
);


--
-- Name: phpbb3_user_group; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_user_group (
    group_id integer DEFAULT 0 NOT NULL,
    user_id integer DEFAULT 0 NOT NULL,
    group_leader smallint DEFAULT 0 NOT NULL,
    user_pending smallint DEFAULT 1 NOT NULL
);


--
-- Name: phpbb3_user_notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_user_notifications (
    item_type character varying(165) DEFAULT ''::character varying NOT NULL,
    item_id integer DEFAULT 0 NOT NULL,
    user_id integer DEFAULT 0 NOT NULL,
    method character varying(165) DEFAULT ''::character varying NOT NULL,
    notify smallint DEFAULT 1 NOT NULL
);


--
-- Name: phpbb3_users_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.phpbb3_users_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: phpbb3_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_users (
    user_id integer DEFAULT nextval('public.phpbb3_users_seq'::regclass) NOT NULL,
    user_type smallint DEFAULT 0 NOT NULL,
    group_id integer DEFAULT 3 NOT NULL,
    user_permissions text DEFAULT ''::text NOT NULL,
    user_perm_from integer DEFAULT 0 NOT NULL,
    user_ip character varying(40) DEFAULT ''::character varying NOT NULL,
    user_regdate integer DEFAULT 0 NOT NULL,
    username public.varchar_ci DEFAULT ''::character varying NOT NULL,
    username_clean public.varchar_ci DEFAULT ''::character varying NOT NULL,
    user_password character varying(255) DEFAULT ''::character varying NOT NULL,
    user_passchg integer DEFAULT 0 NOT NULL,
    user_email character varying(100) DEFAULT ''::character varying NOT NULL,
    user_birthday character varying(10) DEFAULT ''::character varying NOT NULL,
    user_lastvisit integer DEFAULT 0 NOT NULL,
    user_lastmark integer DEFAULT 0 NOT NULL,
    user_lastpost_time integer DEFAULT 0 NOT NULL,
    user_lastpage character varying(200) DEFAULT ''::character varying NOT NULL,
    user_last_confirm_key character varying(10) DEFAULT ''::character varying NOT NULL,
    user_last_search integer DEFAULT 0 NOT NULL,
    user_warnings smallint DEFAULT 0 NOT NULL,
    user_last_warning integer DEFAULT 0 NOT NULL,
    user_login_attempts smallint DEFAULT 0 NOT NULL,
    user_inactive_reason smallint DEFAULT 0 NOT NULL,
    user_inactive_time integer DEFAULT 0 NOT NULL,
    user_posts integer DEFAULT 0 NOT NULL,
    user_lang character varying(30) DEFAULT ''::character varying NOT NULL,
    user_timezone character varying(100) DEFAULT ''::character varying NOT NULL,
    user_dateformat character varying(64) DEFAULT 'd M Y H:i'::character varying NOT NULL,
    user_style integer DEFAULT 0 NOT NULL,
    user_rank integer DEFAULT 0 NOT NULL,
    user_colour character varying(6) DEFAULT ''::character varying NOT NULL,
    user_new_privmsg integer DEFAULT 0 NOT NULL,
    user_unread_privmsg integer DEFAULT 0 NOT NULL,
    user_last_privmsg integer DEFAULT 0 NOT NULL,
    user_message_rules smallint DEFAULT 0 NOT NULL,
    user_full_folder integer DEFAULT '-3'::integer NOT NULL,
    user_emailtime integer DEFAULT 0 NOT NULL,
    user_topic_show_days smallint DEFAULT 0 NOT NULL,
    user_topic_sortby_type character varying(1) DEFAULT 't'::character varying NOT NULL,
    user_topic_sortby_dir character varying(1) DEFAULT 'd'::character varying NOT NULL,
    user_post_show_days smallint DEFAULT 0 NOT NULL,
    user_post_sortby_type character varying(1) DEFAULT 't'::character varying NOT NULL,
    user_post_sortby_dir character varying(1) DEFAULT 'a'::character varying NOT NULL,
    user_notify smallint DEFAULT 0 NOT NULL,
    user_notify_pm smallint DEFAULT 1 NOT NULL,
    user_notify_type smallint DEFAULT 0 NOT NULL,
    user_allow_pm smallint DEFAULT 1 NOT NULL,
    user_allow_viewonline smallint DEFAULT 1 NOT NULL,
    user_allow_viewemail smallint DEFAULT 1 NOT NULL,
    user_allow_massemail smallint DEFAULT 1 NOT NULL,
    user_options integer DEFAULT 230271 NOT NULL,
    user_avatar character varying(255) DEFAULT ''::character varying NOT NULL,
    user_avatar_type character varying(255) DEFAULT ''::character varying NOT NULL,
    user_avatar_width smallint DEFAULT 0 NOT NULL,
    user_avatar_height smallint DEFAULT 0 NOT NULL,
    user_sig text DEFAULT ''::text NOT NULL,
    user_sig_bbcode_uid character varying(8) DEFAULT ''::character varying NOT NULL,
    user_sig_bbcode_bitfield character varying(255) DEFAULT ''::character varying NOT NULL,
    user_jabber character varying(255) DEFAULT ''::character varying NOT NULL,
    user_actkey character varying(32) DEFAULT ''::character varying NOT NULL,
    user_newpasswd character varying(255) DEFAULT ''::character varying NOT NULL,
    user_form_salt character varying(32) DEFAULT ''::character varying NOT NULL,
    user_new smallint DEFAULT 1 NOT NULL,
    user_reminded smallint DEFAULT 0 NOT NULL,
    user_reminded_time integer DEFAULT 0 NOT NULL,
    reset_token character varying(64) DEFAULT ''::character varying NOT NULL,
    reset_token_expiration integer DEFAULT 0 NOT NULL,
    ct_marked integer DEFAULT 0 NOT NULL,
    user_pass_convert integer DEFAULT 0 NOT NULL,
    CONSTRAINT phpbb3_users_user_style_check CHECK ((user_style >= 0))
);


--
-- Name: phpbb3_warnings_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.phpbb3_warnings_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: phpbb3_warnings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_warnings (
    warning_id integer DEFAULT nextval('public.phpbb3_warnings_seq'::regclass) NOT NULL,
    user_id integer DEFAULT 0 NOT NULL,
    post_id integer DEFAULT 0 NOT NULL,
    log_id integer DEFAULT 0 NOT NULL,
    warning_time integer DEFAULT 0 NOT NULL
);


--
-- Name: phpbb3_words_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.phpbb3_words_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: phpbb3_words; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_words (
    word_id integer DEFAULT nextval('public.phpbb3_words_seq'::regclass) NOT NULL,
    word character varying(255) DEFAULT ''::character varying NOT NULL,
    replacement character varying(255) DEFAULT ''::character varying NOT NULL
);


--
-- Name: phpbb3_zebra; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3_zebra (
    user_id integer DEFAULT 0 NOT NULL,
    zebra_id integer DEFAULT 0 NOT NULL,
    friend smallint DEFAULT 0 NOT NULL,
    foe smallint DEFAULT 0 NOT NULL
);


--
-- Name: phpbb3recovery_profile_fields_data; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3recovery_profile_fields_data (
    user_id integer DEFAULT 0 NOT NULL,
    pf_phpbb_interests text DEFAULT ''::text NOT NULL,
    pf_phpbb_occupation text DEFAULT ''::text NOT NULL,
    pf_phpbb_location character varying(255) DEFAULT ''::character varying NOT NULL,
    pf_phpbb_youtube character varying(255) DEFAULT ''::character varying NOT NULL,
    pf_phpbb_facebook character varying(255) DEFAULT ''::character varying NOT NULL,
    pf_phpbb_icq character varying(255) DEFAULT ''::character varying NOT NULL,
    pf_phpbb_skype character varying(255) DEFAULT ''::character varying NOT NULL,
    pf_phpbb_twitter character varying(255) DEFAULT ''::character varying NOT NULL,
    pf_phpbb_googleplus character varying(255) DEFAULT ''::character varying NOT NULL,
    pf_phpbb_website character varying(255) DEFAULT ''::character varying NOT NULL,
    pf_phpbb_yahoo character varying(255) DEFAULT ''::character varying NOT NULL,
    pf_phpbb_aol character varying(255) DEFAULT ''::character varying NOT NULL
);


--
-- Name: phpbb3recovery_users_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.phpbb3recovery_users_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: phpbb3recovery_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.phpbb3recovery_users (
    user_id integer DEFAULT nextval('public.phpbb3recovery_users_seq'::regclass) NOT NULL,
    user_type smallint DEFAULT 0 NOT NULL,
    group_id integer DEFAULT 3 NOT NULL,
    user_permissions text DEFAULT ''::text NOT NULL,
    user_perm_from integer DEFAULT 0 NOT NULL,
    user_ip character varying(40) DEFAULT ''::character varying NOT NULL,
    user_regdate integer DEFAULT 0 NOT NULL,
    username public.varchar_ci DEFAULT ''::character varying NOT NULL,
    username_clean public.varchar_ci DEFAULT ''::character varying NOT NULL,
    user_password character varying(255) DEFAULT ''::character varying NOT NULL,
    user_passchg integer DEFAULT 0 NOT NULL,
    user_email character varying(100) DEFAULT ''::character varying NOT NULL,
    user_email_hash bigint DEFAULT 0 NOT NULL,
    user_birthday character varying(10) DEFAULT ''::character varying NOT NULL,
    user_lastvisit integer DEFAULT 0 NOT NULL,
    user_lastmark integer DEFAULT 0 NOT NULL,
    user_lastpost_time integer DEFAULT 0 NOT NULL,
    user_lastpage character varying(200) DEFAULT ''::character varying NOT NULL,
    user_last_confirm_key character varying(10) DEFAULT ''::character varying NOT NULL,
    user_last_search integer DEFAULT 0 NOT NULL,
    user_warnings smallint DEFAULT 0 NOT NULL,
    user_last_warning integer DEFAULT 0 NOT NULL,
    user_login_attempts smallint DEFAULT 0 NOT NULL,
    user_inactive_reason smallint DEFAULT 0 NOT NULL,
    user_inactive_time integer DEFAULT 0 NOT NULL,
    user_posts integer DEFAULT 0 NOT NULL,
    user_lang character varying(30) DEFAULT ''::character varying NOT NULL,
    user_timezone character varying(100) DEFAULT ''::character varying NOT NULL,
    user_dateformat character varying(64) DEFAULT 'd M Y H:i'::character varying NOT NULL,
    user_style integer DEFAULT 0 NOT NULL,
    user_rank integer DEFAULT 0 NOT NULL,
    user_colour character varying(6) DEFAULT ''::character varying NOT NULL,
    user_new_privmsg integer DEFAULT 0 NOT NULL,
    user_unread_privmsg integer DEFAULT 0 NOT NULL,
    user_last_privmsg integer DEFAULT 0 NOT NULL,
    user_message_rules smallint DEFAULT 0 NOT NULL,
    user_full_folder integer DEFAULT '-3'::integer NOT NULL,
    user_emailtime integer DEFAULT 0 NOT NULL,
    user_topic_show_days smallint DEFAULT 0 NOT NULL,
    user_topic_sortby_type character varying(1) DEFAULT 't'::character varying NOT NULL,
    user_topic_sortby_dir character varying(1) DEFAULT 'd'::character varying NOT NULL,
    user_post_show_days smallint DEFAULT 0 NOT NULL,
    user_post_sortby_type character varying(1) DEFAULT 't'::character varying NOT NULL,
    user_post_sortby_dir character varying(1) DEFAULT 'a'::character varying NOT NULL,
    user_notify smallint DEFAULT 0 NOT NULL,
    user_notify_pm smallint DEFAULT 1 NOT NULL,
    user_notify_type smallint DEFAULT 0 NOT NULL,
    user_allow_pm smallint DEFAULT 1 NOT NULL,
    user_allow_viewonline smallint DEFAULT 1 NOT NULL,
    user_allow_viewemail smallint DEFAULT 1 NOT NULL,
    user_allow_massemail smallint DEFAULT 1 NOT NULL,
    user_options integer DEFAULT 230271 NOT NULL,
    user_avatar character varying(255) DEFAULT ''::character varying NOT NULL,
    user_avatar_type character varying(255) DEFAULT ''::character varying NOT NULL,
    user_avatar_width smallint DEFAULT 0 NOT NULL,
    user_avatar_height smallint DEFAULT 0 NOT NULL,
    user_sig text DEFAULT ''::text NOT NULL,
    user_sig_bbcode_uid character varying(8) DEFAULT ''::character varying NOT NULL,
    user_sig_bbcode_bitfield character varying(255) DEFAULT ''::character varying NOT NULL,
    user_jabber character varying(255) DEFAULT ''::character varying NOT NULL,
    user_actkey character varying(32) DEFAULT ''::character varying NOT NULL,
    user_newpasswd character varying(255) DEFAULT ''::character varying NOT NULL,
    user_form_salt character varying(32) DEFAULT ''::character varying NOT NULL,
    user_new smallint DEFAULT 1 NOT NULL,
    user_reminded smallint DEFAULT 0 NOT NULL,
    user_reminded_time integer DEFAULT 0 NOT NULL,
    ct_marked integer DEFAULT 0 NOT NULL
);


--
-- Name: point_type_id_point_type_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.point_type_id_point_type_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: point_type; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.point_type (
    id_point_type integer DEFAULT nextval('public.point_type_id_point_type_seq'::regclass) NOT NULL,
    article_demonstratif character varying(20) NOT NULL,
    article_defini character varying(20) NOT NULL,
    article_partitif_point_type character varying(20) NOT NULL,
    nom_type character varying(50) NOT NULL,
    equivalent_site_officiel character varying(255) NOT NULL,
    equivalent_manque_un_mur character varying(255) NOT NULL,
    equivalent_places character varying(50) NOT NULL,
    equivalent_proprio character varying(200) NOT NULL,
    equivalent_conditions_utilisation character varying(255) NOT NULL,
    equivalent_cheminee character varying(255) NOT NULL,
    equivalent_poele character varying(255) NOT NULL,
    equivalent_couvertures character varying(255) NOT NULL,
    equivalent_places_matelas character varying(255) NOT NULL,
    equivalent_latrines character varying(255) NOT NULL,
    equivalent_bois_a_proximite character varying(255) NOT NULL,
    equivalent_eau_a_proximite character varying(255) NOT NULL,
    ech_max integer DEFAULT 50 NOT NULL,
    importance integer DEFAULT 0 NOT NULL,
    pas_afficher integer DEFAULT 0 NOT NULL,
    symbole character varying(50)
);


--
-- Name: COLUMN point_type.symbole; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.point_type.symbole IS 'Pictos pour GPS Garmin';


--
-- Name: points_id_point_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.points_id_point_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: points; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.points (
    id_point integer DEFAULT nextval('public.points_id_point_seq'::regclass) NOT NULL,
    nom character varying(80) NOT NULL,
    id_point_type integer DEFAULT 0 NOT NULL,
    site_officiel character varying(255),
    places bigint DEFAULT 0,
    remark text,
    proprio text,
    conditions_utilisation character varying(255) DEFAULT 'ouverture'::character varying,
    places_matelas integer,
    nom_createur character varying(255),
    date_derniere_modification timestamp without time zone DEFAULT now(),
    id_createur integer DEFAULT 0 NOT NULL,
    modele integer DEFAULT 0 NOT NULL,
    date_creation timestamp without time zone DEFAULT now() NOT NULL,
    manque_un_mur boolean,
    cheminee boolean,
    poele boolean,
    couvertures boolean,
    latrines boolean,
    bois_a_proximite boolean,
    eau_a_proximite boolean,
    cache boolean DEFAULT false,
    topic_id integer DEFAULT 0,
    altitude integer DEFAULT 0 NOT NULL,
    acces text DEFAULT ' '::text NOT NULL,
    id_type_precision_gps integer DEFAULT 0 NOT NULL,
    geom public.geometry
);


--
-- Name: COLUMN points.conditions_utilisation; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.points.conditions_utilisation IS 'ouverture ou fermeture ou detruit ou clef_a_recuperer';


--
-- Name: COLUMN points.places_matelas; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.points.places_matelas IS 'NULL-> on sait pas, 0 yen a , N il y a N matelas -1 ya pas';


--
-- Name: COLUMN points.date_creation; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.points.date_creation IS 'remplace date_insertion (bigint)';


--
-- Name: polygone_type_id_polygone_type_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.polygone_type_id_polygone_type_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: polygone_type; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.polygone_type (
    id_polygone_type integer DEFAULT nextval('public.polygone_type_id_polygone_type_seq'::regclass) NOT NULL,
    art_dem_poly character varying(6) NOT NULL,
    art_def_poly character varying(6) NOT NULL,
    type_polygone character varying(32) NOT NULL,
    ordre_taille integer DEFAULT 0 NOT NULL,
    categorie_polygone_type character varying(255),
    art_indef_poly character varying(6)
);


--
-- Name: COLUMN polygone_type.ordre_taille; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.polygone_type.ordre_taille IS 'importance';


--
-- Name: polygones_id_polygone_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.polygones_id_polygone_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: polygones; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.polygones (
    id_polygone integer DEFAULT nextval('public.polygones_id_polygone_seq'::regclass) NOT NULL,
    id_polygone_type integer DEFAULT 1 NOT NULL,
    article_partitif character varying(20),
    nom_polygone character varying(255) NOT NULL,
    source character varying(255),
    message_information_polygone text,
    url_exterieure character varying(255),
    geom public.geometry,
    site_web character varying(255)
);


--
-- Name: COLUMN polygones.article_partitif; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.polygones.article_partitif IS 'il y avait une merdouille sur le default, ca a fait des 4 partout';


--
-- Name: COLUMN polygones.url_exterieure; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.polygones.url_exterieure IS 'URL plus précise pour tirer des infos utiles pour wri (exemple : pages des restrictions pour les réserves)';


--
-- Name: COLUMN polygones.site_web; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.polygones.site_web IS 'Adresse du site web principal du polygone (si existe)';


--
-- Name: raster_columns; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.raster_columns (
    r_table_catalog name,
    r_table_schema name,
    r_table_name name,
    r_raster_column name,
    srid integer,
    scale_x double precision,
    scale_y double precision,
    blocksize_x integer,
    blocksize_y integer,
    same_alignment boolean,
    regular_blocking boolean,
    num_bands integer,
    pixel_types text[],
    nodata_values double precision[],
    out_db boolean[],
    extent public.geometry,
    spatial_index boolean
);


--
-- Name: raster_overviews; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.raster_overviews (
    o_table_catalog name,
    o_table_schema name,
    o_table_name name,
    o_raster_column name,
    r_table_catalog name,
    r_table_schema name,
    r_table_name name,
    r_raster_column name,
    overview_factor integer
);


--
-- Name: type_precision_gps_id_type_precision_gps_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.type_precision_gps_id_type_precision_gps_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: type_precision_gps; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.type_precision_gps (
    id_type_precision_gps integer DEFAULT nextval('public.type_precision_gps_id_type_precision_gps_seq'::regclass) NOT NULL,
    nom_precision_gps character varying(255) NOT NULL,
    ordre integer DEFAULT 0 NOT NULL
);


--
-- Data for Name: commentaires; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.commentaires (id_commentaire, date, id_point, texte, auteur_commentaire, photo_existe, date_photo, demande_correction, id_createur_commentaire, raison_demande_correction) FROM stdin;
\.


--
-- Data for Name: emails_bounce; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.emails_bounce (id_email_bounce, date, contenu, a_traiter) FROM stdin;
\.


--
-- Data for Name: historique_modifications_points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.historique_modifications_points (id_historique_modifications_points, id_point, id_user, date_modification, raison_modification, avant, apres, type_modification) FROM stdin;
\.


--
-- Data for Name: pages_wiki; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pages_wiki (nom_page, date, contenu) FROM stdin;
\.


--
-- Data for Name: phpbb3_acl_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_acl_groups (group_id, forum_id, auth_option_id, auth_role_id, auth_setting) FROM stdin;
\.


--
-- Data for Name: phpbb3_acl_options; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_acl_options (auth_option_id, auth_option, is_global, is_local, founder_only) FROM stdin;
1	u_masspm_group	1	0	0
2	u_	1	0	0
\.


--
-- Data for Name: phpbb3_acl_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_acl_roles (role_id, role_name, role_description, role_type, role_order) FROM stdin;
\.


--
-- Data for Name: phpbb3_acl_roles_data; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_acl_roles_data (role_id, auth_option_id, auth_setting) FROM stdin;
\.


--
-- Data for Name: phpbb3_acl_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_acl_users (user_id, forum_id, auth_option_id, auth_role_id, auth_setting) FROM stdin;
\.


--
-- Data for Name: phpbb3_attachments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_attachments (attach_id, post_msg_id, topic_id, in_message, poster_id, is_orphan, physical_filename, real_filename, download_count, attach_comment, extension, mimetype, filesize, filetime, thumbnail) FROM stdin;
\.


--
-- Data for Name: phpbb3_banlist; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_banlist (ban_id, ban_userid, ban_ip, ban_email, ban_start, ban_end, ban_exclude, ban_reason, ban_give_reason) FROM stdin;
\.


--
-- Data for Name: phpbb3_bbcodes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_bbcodes (bbcode_id, bbcode_tag, bbcode_helpline, display_on_posting, bbcode_match, bbcode_tpl, first_pass_match, first_pass_replace, second_pass_match, second_pass_replace) FROM stdin;
\.


--
-- Data for Name: phpbb3_bookmarks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_bookmarks (topic_id, user_id) FROM stdin;
\.


--
-- Data for Name: phpbb3_bots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_bots (bot_id, bot_active, bot_name, user_id, bot_agent, bot_ip) FROM stdin;
\.


--
-- Data for Name: phpbb3_captcha_answers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_captcha_answers (question_id, answer_text) FROM stdin;
\.


--
-- Data for Name: phpbb3_captcha_questions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_captcha_questions (question_id, strict, lang_id, lang_iso, question_text) FROM stdin;
\.


--
-- Data for Name: phpbb3_cleantalk_sfw; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_cleantalk_sfw (network, mask, status) FROM stdin;
\.


--
-- Data for Name: phpbb3_cleantalk_sfw_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_cleantalk_sfw_logs (ip, all_entries, blocked_entries, entries_timestamp) FROM stdin;
\.


--
-- Data for Name: phpbb3_config; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_config (config_name, config_value, is_dynamic) FROM stdin;
assets_version	1	0
referer_validation	1	0
check_attachment_content	1	0
mime_triggers	body|head|html|img|plaintext|a href|pre|script|table|title	0
enable_queue_trigger	0	0
queue_trigger_posts	3	0
pm_max_recipients	0	0
dbms_version	15.8 (Debian 15.8-1.pgdg110+1) on x86_64-pc-linux-gnu, compiled by gcc (Debian 10.2.1-6) 10.2.1 20210110, 64-bit	0
version	3.0.4	0
captcha_gd_wave	0	0
captcha_gd_3d_noise	1	0
captcha_gd_fonts	1	0
confirm_refresh	1	0
max_num_search_keywords	10	0
search_indexing_state		1
\.


--
-- Data for Name: phpbb3_config_text; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_config_text (config_name, config_value) FROM stdin;
\.


--
-- Data for Name: phpbb3_confirm; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_confirm (confirm_id, session_id, confirm_type, code, seed, attempts) FROM stdin;
\.


--
-- Data for Name: phpbb3_disallow; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_disallow (disallow_id, disallow_username) FROM stdin;
\.


--
-- Data for Name: phpbb3_drafts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_drafts (draft_id, user_id, topic_id, forum_id, save_time, draft_subject, draft_message) FROM stdin;
\.


--
-- Data for Name: phpbb3_ext; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_ext (ext_name, ext_active, ext_state) FROM stdin;
\.


--
-- Data for Name: phpbb3_extension_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_extension_groups (group_id, group_name, cat_id, allow_group, download_mode, upload_icon, max_filesize, allowed_forums, allow_in_pm) FROM stdin;
\.


--
-- Data for Name: phpbb3_extensions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_extensions (extension_id, group_id, extension) FROM stdin;
\.


--
-- Data for Name: phpbb3_forums; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_forums (forum_id, parent_id, left_id, right_id, forum_parents, forum_name, forum_desc, forum_desc_bitfield, forum_desc_options, forum_desc_uid, forum_link, forum_password, forum_style, forum_image, forum_rules, forum_rules_link, forum_rules_bitfield, forum_rules_options, forum_rules_uid, forum_topics_per_page, forum_type, forum_status, forum_last_post_id, forum_last_poster_id, forum_last_post_subject, forum_last_post_time, forum_last_poster_name, forum_last_poster_colour, forum_flags, display_on_index, enable_indexing, enable_icons, enable_prune, prune_next, prune_days, prune_viewed, prune_freq, display_subforum_list, forum_options, forum_posts_approved, forum_posts_unapproved, forum_posts_softdeleted, forum_topics_approved, forum_topics_unapproved, forum_topics_softdeleted, enable_shadow_prune, prune_shadow_days, prune_shadow_freq, prune_shadow_next, display_subforum_limit) FROM stdin;
\.


--
-- Data for Name: phpbb3_forums_access; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_forums_access (forum_id, user_id, session_id) FROM stdin;
\.


--
-- Data for Name: phpbb3_forums_track; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_forums_track (user_id, forum_id, mark_time) FROM stdin;
\.


--
-- Data for Name: phpbb3_forums_watch; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_forums_watch (forum_id, user_id, notify_status) FROM stdin;
\.


--
-- Data for Name: phpbb3_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_groups (group_id, group_type, group_founder_manage, group_skip_auth, group_name, group_desc, group_desc_bitfield, group_desc_options, group_desc_uid, group_display, group_avatar, group_avatar_type, group_avatar_width, group_avatar_height, group_rank, group_colour, group_sig_chars, group_receive_pm, group_message_limit, group_legend, group_max_recipients) FROM stdin;
\.


--
-- Data for Name: phpbb3_icons; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_icons (icons_id, icons_url, icons_width, icons_height, icons_alt, icons_order, display_on_posting) FROM stdin;
\.


--
-- Data for Name: phpbb3_lang; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_lang (lang_id, lang_iso, lang_dir, lang_english_name, lang_local_name, lang_author) FROM stdin;
\.


--
-- Data for Name: phpbb3_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_log (log_id, log_type, user_id, forum_id, topic_id, post_id, reportee_id, log_ip, log_time, log_operation, log_data) FROM stdin;
\.


--
-- Data for Name: phpbb3_login_attempts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_login_attempts (attempt_ip, attempt_browser, attempt_forwarded_for, attempt_time, user_id, username, username_clean) FROM stdin;
\.


--
-- Data for Name: phpbb3_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_migrations (migration_name, migration_depends_on, migration_schema_done, migration_data_done, migration_data_state, migration_start_time, migration_end_time) FROM stdin;
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_3_rc1	a:1:{i:0;s:43:"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_2";}	1	1		1785077262	1785077262
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_3	a:1:{i:0;s:47:"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_3_rc1";}	1	1		1785077262	1785077262
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_2_rc2	a:1:{i:0;s:47:"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_2_rc1";}	1	1		1785077262	1785077262
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_1_rc1	a:1:{i:0;s:43:"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_0";}	1	1		1785077217	1785077262
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_2	a:1:{i:0;s:47:"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_2_rc2";}	1	1		1785077262	1785077262
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_1	a:1:{i:0;s:47:"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_1_rc1";}	1	1		1785077262	1785077262
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_5_rc1	a:1:{i:0;s:43:"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_4";}	1	1		1785077263	1785077356
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_5_rc1part2	a:1:{i:0;s:47:"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_5_rc1";}	0	0		1785077356	0
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_4_rc1	a:1:{i:0;s:43:"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_3";}	1	1		1785077262	1785077263
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_2_rc1	a:1:{i:0;s:43:"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_1";}	1	1		1785077262	1785077262
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_4	a:1:{i:0;s:47:"\\phpbb\\db\\migration\\data\\v30x\\release_3_0_4_rc1";}	1	1		1785077263	1785077263
\\phpbb\\db\\migration\\data\\v30x\\release_3_0_0	a:0:{}	1	1		1785077217	1785077217
\.


--
-- Data for Name: phpbb3_moderator_cache; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_moderator_cache (forum_id, user_id, username, group_id, group_name, display_on_index) FROM stdin;
\.


--
-- Data for Name: phpbb3_modules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_modules (module_id, module_enabled, module_display, module_basename, module_class, parent_id, left_id, right_id, module_langname, module_mode, module_auth) FROM stdin;
\.


--
-- Data for Name: phpbb3_notification_emails; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_notification_emails (notification_type_id, item_id, item_parent_id, user_id) FROM stdin;
\.


--
-- Data for Name: phpbb3_notification_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_notification_types (notification_type_id, notification_type_name, notification_type_enabled) FROM stdin;
\.


--
-- Data for Name: phpbb3_notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_notifications (notification_id, notification_type_id, item_id, item_parent_id, user_id, notification_read, notification_time, notification_data) FROM stdin;
\.


--
-- Data for Name: phpbb3_oauth_accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_oauth_accounts (user_id, provider, oauth_provider_id) FROM stdin;
\.


--
-- Data for Name: phpbb3_oauth_states; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_oauth_states (user_id, session_id, provider, oauth_state) FROM stdin;
\.


--
-- Data for Name: phpbb3_oauth_tokens; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_oauth_tokens (user_id, session_id, provider, oauth_token) FROM stdin;
\.


--
-- Data for Name: phpbb3_poll_options; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_poll_options (poll_option_id, topic_id, poll_option_text, poll_option_total) FROM stdin;
\.


--
-- Data for Name: phpbb3_poll_votes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_poll_votes (topic_id, poll_option_id, vote_user_id, vote_user_ip) FROM stdin;
\.


--
-- Data for Name: phpbb3_posts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_posts (post_id, topic_id, forum_id, poster_id, icon_id, poster_ip, post_time, post_reported, enable_bbcode, enable_smilies, enable_magic_url, enable_sig, post_username, post_subject, post_text, post_checksum, post_attachment, bbcode_bitfield, bbcode_uid, post_postcount, post_edit_time, post_edit_reason, post_edit_user, post_edit_count, post_edit_locked, post_visibility, post_delete_time, post_delete_reason, post_delete_user) FROM stdin;
\.


--
-- Data for Name: phpbb3_privmsgs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_privmsgs (msg_id, root_level, author_id, icon_id, author_ip, message_time, enable_bbcode, enable_smilies, enable_magic_url, enable_sig, message_subject, message_text, message_edit_reason, message_edit_user, message_attachment, bbcode_bitfield, bbcode_uid, message_edit_time, message_edit_count, to_address, bcc_address, message_reported) FROM stdin;
\.


--
-- Data for Name: phpbb3_privmsgs_folder; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_privmsgs_folder (folder_id, user_id, folder_name, pm_count) FROM stdin;
\.


--
-- Data for Name: phpbb3_privmsgs_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_privmsgs_rules (rule_id, user_id, rule_check, rule_connection, rule_string, rule_user_id, rule_group_id, rule_action, rule_folder_id) FROM stdin;
\.


--
-- Data for Name: phpbb3_privmsgs_to; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_privmsgs_to (msg_id, user_id, author_id, pm_deleted, pm_new, pm_unread, pm_replied, pm_marked, pm_forwarded, folder_id) FROM stdin;
\.


--
-- Data for Name: phpbb3_profile_fields; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_profile_fields (field_id, field_name, field_type, field_ident, field_length, field_minlen, field_maxlen, field_novalue, field_default_value, field_validation, field_required, field_show_on_reg, field_hide, field_no_view, field_active, field_order, field_show_profile, field_show_on_vt, field_show_novalue, field_show_on_pm, field_show_on_ml, field_is_contact, field_contact_desc, field_contact_url) FROM stdin;
\.


--
-- Data for Name: phpbb3_profile_fields_data; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_profile_fields_data (user_id, pf_phpbb_interests, pf_phpbb_occupation, pf_phpbb_location, pf_phpbb_youtube, pf_phpbb_facebook, pf_phpbb_icq, pf_phpbb_skype, pf_phpbb_twitter, pf_phpbb_website, pf_phpbb_yahoo) FROM stdin;
\.


--
-- Data for Name: phpbb3_profile_fields_lang; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_profile_fields_lang (field_id, lang_id, option_id, field_type, lang_value) FROM stdin;
\.


--
-- Data for Name: phpbb3_profile_lang; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_profile_lang (field_id, lang_id, lang_name, lang_explain, lang_default_value) FROM stdin;
\.


--
-- Data for Name: phpbb3_qa_confirm; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_qa_confirm (session_id, confirm_id, lang_iso, question_id, attempts, confirm_type) FROM stdin;
\.


--
-- Data for Name: phpbb3_ranks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_ranks (rank_id, rank_title, rank_min, rank_special, rank_image) FROM stdin;
\.


--
-- Data for Name: phpbb3_reports; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_reports (report_id, reason_id, post_id, user_id, user_notify, report_closed, report_time, report_text, pm_id, reported_post_enable_bbcode, reported_post_enable_smilies, reported_post_enable_magic_url, reported_post_text, reported_post_uid, reported_post_bitfield) FROM stdin;
\.


--
-- Data for Name: phpbb3_reports_reasons; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_reports_reasons (reason_id, reason_title, reason_description, reason_order) FROM stdin;
\.


--
-- Data for Name: phpbb3_search_results; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_search_results (search_key, search_time, search_keywords, search_authors) FROM stdin;
\.


--
-- Data for Name: phpbb3_search_wordlist; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_search_wordlist (word_id, word_text, word_common, word_count) FROM stdin;
\.


--
-- Data for Name: phpbb3_search_wordmatch; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_search_wordmatch (post_id, word_id, title_match) FROM stdin;
\.


--
-- Data for Name: phpbb3_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_sessions (session_id, session_user_id, session_last_visit, session_start, session_time, session_ip, session_browser, session_forwarded_for, session_page, session_viewonline, session_autologin, session_admin, session_forum_id) FROM stdin;
8335c55263d88c72f8de0ce76bf43f05	0	1785058843	1785058843	1785058843	192.168.65.1	curl/8.7.1		../index.php	1	0	0	0
b8f6a5b3ff8ba35b31086fc392c1c913	0	1785058887	1785058887	1785058887	192.168.65.1	curl/8.7.1		../index.php	1	0	0	0
8cb6b50c5f3e0f3354fd506ef36f1fa5	0	1785077188	1785077188	1785077188	192.168.65.1	curl/8.7.1		../index.php	1	0	0	0
\.


--
-- Data for Name: phpbb3_sessions_keys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_sessions_keys (key_id, user_id, last_ip, last_login) FROM stdin;
\.


--
-- Data for Name: phpbb3_sitelist; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_sitelist (site_id, site_ip, site_hostname, ip_exclude) FROM stdin;
\.


--
-- Data for Name: phpbb3_smilies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_smilies (smiley_id, code, emotion, smiley_url, smiley_width, smiley_height, smiley_order, display_on_posting) FROM stdin;
\.


--
-- Data for Name: phpbb3_styles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_styles (style_id, style_name, style_copyright, style_active, style_path, bbcode_bitfield, style_parent_id, style_parent_tree, template_id, theme_id, imageset_id) FROM stdin;
\.


--
-- Data for Name: phpbb3_styles_imageset; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_styles_imageset (imageset_id, imageset_name, imageset_copyright, imageset_path) FROM stdin;
\.


--
-- Data for Name: phpbb3_styles_imageset_data; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_styles_imageset_data (image_id, image_name, image_filename, image_lang, image_height, image_width, imageset_id) FROM stdin;
\.


--
-- Data for Name: phpbb3_styles_template; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_styles_template (template_id, template_name, template_copyright, template_path, bbcode_bitfield, template_storedb, template_inherits_id, template_inherit_path) FROM stdin;
\.


--
-- Data for Name: phpbb3_styles_template_data; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_styles_template_data (template_id, template_filename, template_included, template_mtime, template_data) FROM stdin;
\.


--
-- Data for Name: phpbb3_styles_theme; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_styles_theme (theme_id, theme_name, theme_copyright, theme_path, theme_storedb, theme_mtime, theme_data) FROM stdin;
\.


--
-- Data for Name: phpbb3_teampage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_teampage (teampage_id, group_id, teampage_name, teampage_position, teampage_parent) FROM stdin;
\.


--
-- Data for Name: phpbb3_topics; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_topics (topic_id, forum_id, icon_id, topic_attachment, topic_reported, topic_title, topic_poster, topic_time, topic_time_limit, topic_views, topic_status, topic_type, topic_first_post_id, topic_first_poster_name, topic_first_poster_colour, topic_last_post_id, topic_last_poster_id, topic_last_poster_name, topic_last_poster_colour, topic_last_post_subject, topic_last_post_time, topic_last_view_time, topic_moved_id, topic_bumped, topic_bumper, poll_title, poll_start, poll_length, poll_max_options, poll_last_vote, poll_vote_change, topic_visibility, topic_delete_time, topic_delete_reason, topic_delete_user, topic_posts_approved, topic_posts_unapproved, topic_posts_softdeleted) FROM stdin;
\.


--
-- Data for Name: phpbb3_topics_posted; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_topics_posted (user_id, topic_id, topic_posted) FROM stdin;
\.


--
-- Data for Name: phpbb3_topics_track; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_topics_track (user_id, topic_id, forum_id, mark_time) FROM stdin;
\.


--
-- Data for Name: phpbb3_topics_watch; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_topics_watch (topic_id, user_id, notify_status) FROM stdin;
\.


--
-- Data for Name: phpbb3_user_group; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_user_group (group_id, user_id, group_leader, user_pending) FROM stdin;
\.


--
-- Data for Name: phpbb3_user_notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_user_notifications (item_type, item_id, user_id, method, notify) FROM stdin;
\.


--
-- Data for Name: phpbb3_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_users (user_id, user_type, group_id, user_permissions, user_perm_from, user_ip, user_regdate, username, username_clean, user_password, user_passchg, user_email, user_birthday, user_lastvisit, user_lastmark, user_lastpost_time, user_lastpage, user_last_confirm_key, user_last_search, user_warnings, user_last_warning, user_login_attempts, user_inactive_reason, user_inactive_time, user_posts, user_lang, user_timezone, user_dateformat, user_style, user_rank, user_colour, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_message_rules, user_full_folder, user_emailtime, user_topic_show_days, user_topic_sortby_type, user_topic_sortby_dir, user_post_show_days, user_post_sortby_type, user_post_sortby_dir, user_notify, user_notify_pm, user_notify_type, user_allow_pm, user_allow_viewonline, user_allow_viewemail, user_allow_massemail, user_options, user_avatar, user_avatar_type, user_avatar_width, user_avatar_height, user_sig, user_sig_bbcode_uid, user_sig_bbcode_bitfield, user_jabber, user_actkey, user_newpasswd, user_form_salt, user_new, user_reminded, user_reminded_time, reset_token, reset_token_expiration, ct_marked, user_pass_convert) FROM stdin;
\.


--
-- Data for Name: phpbb3_warnings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_warnings (warning_id, user_id, post_id, log_id, warning_time) FROM stdin;
\.


--
-- Data for Name: phpbb3_words; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_words (word_id, word, replacement) FROM stdin;
\.


--
-- Data for Name: phpbb3_zebra; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3_zebra (user_id, zebra_id, friend, foe) FROM stdin;
\.


--
-- Data for Name: phpbb3recovery_profile_fields_data; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3recovery_profile_fields_data (user_id, pf_phpbb_interests, pf_phpbb_occupation, pf_phpbb_location, pf_phpbb_youtube, pf_phpbb_facebook, pf_phpbb_icq, pf_phpbb_skype, pf_phpbb_twitter, pf_phpbb_googleplus, pf_phpbb_website, pf_phpbb_yahoo, pf_phpbb_aol) FROM stdin;
\.


--
-- Data for Name: phpbb3recovery_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.phpbb3recovery_users (user_id, user_type, group_id, user_permissions, user_perm_from, user_ip, user_regdate, username, username_clean, user_password, user_passchg, user_email, user_email_hash, user_birthday, user_lastvisit, user_lastmark, user_lastpost_time, user_lastpage, user_last_confirm_key, user_last_search, user_warnings, user_last_warning, user_login_attempts, user_inactive_reason, user_inactive_time, user_posts, user_lang, user_timezone, user_dateformat, user_style, user_rank, user_colour, user_new_privmsg, user_unread_privmsg, user_last_privmsg, user_message_rules, user_full_folder, user_emailtime, user_topic_show_days, user_topic_sortby_type, user_topic_sortby_dir, user_post_show_days, user_post_sortby_type, user_post_sortby_dir, user_notify, user_notify_pm, user_notify_type, user_allow_pm, user_allow_viewonline, user_allow_viewemail, user_allow_massemail, user_options, user_avatar, user_avatar_type, user_avatar_width, user_avatar_height, user_sig, user_sig_bbcode_uid, user_sig_bbcode_bitfield, user_jabber, user_actkey, user_newpasswd, user_form_salt, user_new, user_reminded, user_reminded_time, ct_marked) FROM stdin;
\.


--
-- Data for Name: point_type; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.point_type (id_point_type, article_demonstratif, article_defini, article_partitif_point_type, nom_type, equivalent_site_officiel, equivalent_manque_un_mur, equivalent_places, equivalent_proprio, equivalent_conditions_utilisation, equivalent_cheminee, equivalent_poele, equivalent_couvertures, equivalent_places_matelas, equivalent_latrines, equivalent_bois_a_proximite, equivalent_eau_a_proximite, ech_max, importance, pas_afficher, symbole) FROM stdin;
10	ce	le	d'un	refuge gardé	Site officiel		Capacité d'accueil	Propriétaires	Fermé					Latrines		Ravitaillement en eau possible	600	97	0	Residence
9	ce	le	d'un	gîte d'étape	Site officiel		Capacité d'accueil	Propriétaires	Fermé							Ravitaillement en eau possible	600	95	0	Residence
23	ce	le	d'un	point d'eau					Tari définitivement								50	83	0	Drinking Water
16	ce	le	d'un	lac													100	20	1	Water Source
6	ce	le	d'un	sommet													250	82	0	Summit
7	cette	la	d'une	cabane non gardée	Site Internet	Manque un mur	Places prévues pour dormir	Propriétaire / accessibilité	Fermée	Cheminée	Poêle	Couvertures	Places sur Matelas	Latrines	Bois à proximité	Eau à proximité	600	99	0	Fishing Hot Spot Facility
28	ce	le	d'un	bâtiment en montagne				Propriétaire / accessibilité	Inutilisable						Bois à proximité	Eau à proximité	50	10	0	Puzzle Cache
3	ce	le	d'un	passage délicat					Fermé								50	75	0	Flag, Red
\.


--
-- Data for Name: points; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.points (id_point, nom, id_point_type, site_officiel, places, remark, proprio, conditions_utilisation, places_matelas, nom_createur, date_derniere_modification, id_createur, modele, date_creation, manque_un_mur, cheminee, poele, couvertures, latrines, bois_a_proximite, eau_a_proximite, cache, topic_id, altitude, acces, id_type_precision_gps, geom) FROM stdin;
\.


--
-- Data for Name: polygone_type; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.polygone_type (id_polygone_type, art_dem_poly, art_def_poly, type_polygone, ordre_taille, categorie_polygone_type, art_indef_poly) FROM stdin;
13	cette	la	commune	100	administrative	une
17	cette	la	région	600	administrative	une
11	cette	la	zone	800	montagnarde	une
6	ce	le	pays	700	administrative	un
10	ce	le	département	500	administrative	un
3	cette	la	carte	300	montagnarde	une
12	cette	la	zone réglementée	200	montagnarde	une
1	ce	le	massif	400	montagnarde	un
\.


--
-- Data for Name: polygones; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.polygones (id_polygone, id_polygone_type, article_partitif, nom_polygone, source, message_information_polygone, url_exterieure, geom, site_web) FROM stdin;
\.


--
-- Data for Name: raster_columns; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.raster_columns (r_table_catalog, r_table_schema, r_table_name, r_raster_column, srid, scale_x, scale_y, blocksize_x, blocksize_y, same_alignment, regular_blocking, num_bands, pixel_types, nodata_values, out_db, extent, spatial_index) FROM stdin;
\.


--
-- Data for Name: raster_overviews; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.raster_overviews (o_table_catalog, o_table_schema, o_table_name, o_raster_column, r_table_catalog, r_table_schema, r_table_name, r_raster_column, overview_factor) FROM stdin;
\.


--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.


--
-- Data for Name: type_precision_gps; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.type_precision_gps (id_type_precision_gps, nom_precision_gps, ordre) FROM stdin;
5	Coordonnées cachées	99
1	Coordonnées prises sur le terrain	4
8	Coordonnées lues sur une des cartes proposées	8
4	Coordonnées approximatives	2
7	Coordonnées pointées sur photos aériennes	6
10	Autre	90
\.


--
-- Name: commentaires_id_commentaire_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.commentaires_id_commentaire_seq', 1, false);


--
-- Name: emails_bounce_id_email_bounce_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.emails_bounce_id_email_bounce_seq', 1, false);


--
-- Name: historique_modifications_poin_id_historique_modifications_p_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.historique_modifications_poin_id_historique_modifications_p_seq', 1, false);


--
-- Name: phpbb3_acl_options_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.phpbb3_acl_options_seq', 2, true);


--
-- Name: phpbb3_acl_roles_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.phpbb3_acl_roles_seq', 1, false);


--
-- Name: phpbb3_attachments_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.phpbb3_attachments_seq', 1, false);


--
-- Name: phpbb3_banlist_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.phpbb3_banlist_seq', 1, false);


--
-- Name: phpbb3_bots_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.phpbb3_bots_seq', 1, false);


--
-- Name: phpbb3_captcha_questions_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.phpbb3_captcha_questions_seq', 1, false);


--
-- Name: phpbb3_disallow_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.phpbb3_disallow_seq', 1, false);


--
-- Name: phpbb3_drafts_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.phpbb3_drafts_seq', 1, false);


--
-- Name: phpbb3_extension_groups_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.phpbb3_extension_groups_seq', 1, false);


--
-- Name: phpbb3_extensions_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.phpbb3_extensions_seq', 1, false);


--
-- Name: phpbb3_forums_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.phpbb3_forums_seq', 1, false);


--
-- Name: phpbb3_groups_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.phpbb3_groups_seq', 1, false);


--
-- Name: phpbb3_icons_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.phpbb3_icons_seq', 1, false);


--
-- Name: phpbb3_lang_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.phpbb3_lang_seq', 1, false);


--
-- Name: phpbb3_log_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.phpbb3_log_seq', 1, false);


--
-- Name: phpbb3_modules_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.phpbb3_modules_seq', 1, false);


--
-- Name: phpbb3_notification_types_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.phpbb3_notification_types_seq', 1, false);


--
-- Name: phpbb3_notifications_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.phpbb3_notifications_seq', 1, false);


--
-- Name: phpbb3_posts_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.phpbb3_posts_seq', 1, false);


--
-- Name: phpbb3_privmsgs_folder_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.phpbb3_privmsgs_folder_seq', 1, false);


--
-- Name: phpbb3_privmsgs_rules_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.phpbb3_privmsgs_rules_seq', 1, false);


--
-- Name: phpbb3_privmsgs_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.phpbb3_privmsgs_seq', 1, false);


--
-- Name: phpbb3_profile_fields_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.phpbb3_profile_fields_seq', 1, false);


--
-- Name: phpbb3_ranks_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.phpbb3_ranks_seq', 1, false);


--
-- Name: phpbb3_reports_reasons_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.phpbb3_reports_reasons_seq', 1, false);


--
-- Name: phpbb3_reports_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.phpbb3_reports_seq', 1, false);


--
-- Name: phpbb3_search_wordlist_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.phpbb3_search_wordlist_seq', 1, false);


--
-- Name: phpbb3_sitelist_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.phpbb3_sitelist_seq', 1, false);


--
-- Name: phpbb3_smilies_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.phpbb3_smilies_seq', 1, false);


--
-- Name: phpbb3_styles_imageset_data_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.phpbb3_styles_imageset_data_seq', 1, false);


--
-- Name: phpbb3_styles_imageset_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.phpbb3_styles_imageset_seq', 1, false);


--
-- Name: phpbb3_styles_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.phpbb3_styles_seq', 1, false);


--
-- Name: phpbb3_styles_template_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.phpbb3_styles_template_seq', 1, false);


--
-- Name: phpbb3_styles_theme_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.phpbb3_styles_theme_seq', 1, false);


--
-- Name: phpbb3_teampage_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.phpbb3_teampage_seq', 1, false);


--
-- Name: phpbb3_topics_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.phpbb3_topics_seq', 1, false);


--
-- Name: phpbb3_users_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.phpbb3_users_seq', 1, false);


--
-- Name: phpbb3_warnings_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.phpbb3_warnings_seq', 1, false);


--
-- Name: phpbb3_words_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.phpbb3_words_seq', 1, false);


--
-- Name: phpbb3recovery_users_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.phpbb3recovery_users_seq', 1, false);


--
-- Name: point_type_id_point_type_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.point_type_id_point_type_seq', 1, false);


--
-- Name: points_id_point_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.points_id_point_seq', 1, false);


--
-- Name: polygone_type_id_polygone_type_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.polygone_type_id_polygone_type_seq', 1, false);


--
-- Name: polygones_id_polygone_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.polygones_id_polygone_seq', 1, false);


--
-- Name: type_precision_gps_id_type_precision_gps_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.type_precision_gps_id_type_precision_gps_seq', 1, false);


--
-- Name: commentaires commentaires_id_commentaire_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.commentaires
    ADD CONSTRAINT commentaires_id_commentaire_pkey PRIMARY KEY (id_commentaire);


--
-- Name: emails_bounce emails_bounce_id_email_bounce; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.emails_bounce
    ADD CONSTRAINT emails_bounce_id_email_bounce PRIMARY KEY (id_email_bounce);


--
-- Name: historique_modifications_points historique_modifications_points_id_historique_modifications_poi; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.historique_modifications_points
    ADD CONSTRAINT historique_modifications_points_id_historique_modifications_poi PRIMARY KEY (id_historique_modifications_points);


--
-- Name: phpbb3_acl_options phpbb3_acl_options_auth_option; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_acl_options
    ADD CONSTRAINT phpbb3_acl_options_auth_option UNIQUE (auth_option);


--
-- Name: phpbb3_acl_options phpbb3_acl_options_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_acl_options
    ADD CONSTRAINT phpbb3_acl_options_pkey PRIMARY KEY (auth_option_id);


--
-- Name: phpbb3_acl_roles_data phpbb3_acl_roles_data_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_acl_roles_data
    ADD CONSTRAINT phpbb3_acl_roles_data_pkey PRIMARY KEY (role_id, auth_option_id);


--
-- Name: phpbb3_acl_roles phpbb3_acl_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_acl_roles
    ADD CONSTRAINT phpbb3_acl_roles_pkey PRIMARY KEY (role_id);


--
-- Name: phpbb3_attachments phpbb3_attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_attachments
    ADD CONSTRAINT phpbb3_attachments_pkey PRIMARY KEY (attach_id);


--
-- Name: phpbb3_banlist phpbb3_banlist_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_banlist
    ADD CONSTRAINT phpbb3_banlist_pkey PRIMARY KEY (ban_id);


--
-- Name: phpbb3_bbcodes phpbb3_bbcodes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_bbcodes
    ADD CONSTRAINT phpbb3_bbcodes_pkey PRIMARY KEY (bbcode_id);


--
-- Name: phpbb3_bookmarks phpbb3_bookmarks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_bookmarks
    ADD CONSTRAINT phpbb3_bookmarks_pkey PRIMARY KEY (topic_id, user_id);


--
-- Name: phpbb3_bots phpbb3_bots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_bots
    ADD CONSTRAINT phpbb3_bots_pkey PRIMARY KEY (bot_id);


--
-- Name: phpbb3_captcha_questions phpbb3_captcha_questions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_captcha_questions
    ADD CONSTRAINT phpbb3_captcha_questions_pkey PRIMARY KEY (question_id);


--
-- Name: phpbb3_cleantalk_sfw_logs phpbb3_cleantalk_sfw_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_cleantalk_sfw_logs
    ADD CONSTRAINT phpbb3_cleantalk_sfw_logs_pkey PRIMARY KEY (ip);


--
-- Name: phpbb3_config phpbb3_config_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_config
    ADD CONSTRAINT phpbb3_config_pkey PRIMARY KEY (config_name);


--
-- Name: phpbb3_confirm phpbb3_confirm_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_confirm
    ADD CONSTRAINT phpbb3_confirm_pkey PRIMARY KEY (session_id, confirm_id);


--
-- Name: phpbb3_disallow phpbb3_disallow_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_disallow
    ADD CONSTRAINT phpbb3_disallow_pkey PRIMARY KEY (disallow_id);


--
-- Name: phpbb3_drafts phpbb3_drafts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_drafts
    ADD CONSTRAINT phpbb3_drafts_pkey PRIMARY KEY (draft_id);


--
-- Name: phpbb3_ext phpbb3_ext_ext_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_ext
    ADD CONSTRAINT phpbb3_ext_ext_name UNIQUE (ext_name);


--
-- Name: phpbb3_extension_groups phpbb3_extension_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_extension_groups
    ADD CONSTRAINT phpbb3_extension_groups_pkey PRIMARY KEY (group_id);


--
-- Name: phpbb3_extensions phpbb3_extensions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_extensions
    ADD CONSTRAINT phpbb3_extensions_pkey PRIMARY KEY (extension_id);


--
-- Name: phpbb3_forums_access phpbb3_forums_access_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_forums_access
    ADD CONSTRAINT phpbb3_forums_access_pkey PRIMARY KEY (forum_id, user_id, session_id);


--
-- Name: phpbb3_forums phpbb3_forums_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_forums
    ADD CONSTRAINT phpbb3_forums_pkey PRIMARY KEY (forum_id);


--
-- Name: phpbb3_forums_track phpbb3_forums_track_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_forums_track
    ADD CONSTRAINT phpbb3_forums_track_pkey PRIMARY KEY (user_id, forum_id);


--
-- Name: phpbb3_groups phpbb3_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_groups
    ADD CONSTRAINT phpbb3_groups_pkey PRIMARY KEY (group_id);


--
-- Name: phpbb3_icons phpbb3_icons_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_icons
    ADD CONSTRAINT phpbb3_icons_pkey PRIMARY KEY (icons_id);


--
-- Name: phpbb3_lang phpbb3_lang_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_lang
    ADD CONSTRAINT phpbb3_lang_pkey PRIMARY KEY (lang_id);


--
-- Name: phpbb3_log phpbb3_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_log
    ADD CONSTRAINT phpbb3_log_pkey PRIMARY KEY (log_id);


--
-- Name: phpbb3_migrations phpbb3_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_migrations
    ADD CONSTRAINT phpbb3_migrations_pkey PRIMARY KEY (migration_name);


--
-- Name: phpbb3_modules phpbb3_modules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_modules
    ADD CONSTRAINT phpbb3_modules_pkey PRIMARY KEY (module_id);


--
-- Name: phpbb3_notification_emails phpbb3_notification_emails_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_notification_emails
    ADD CONSTRAINT phpbb3_notification_emails_pkey PRIMARY KEY (notification_type_id, item_id, item_parent_id, user_id);


--
-- Name: phpbb3_notification_types phpbb3_notification_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_notification_types
    ADD CONSTRAINT phpbb3_notification_types_pkey PRIMARY KEY (notification_type_id);


--
-- Name: phpbb3_notification_types phpbb3_notification_types_type; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_notification_types
    ADD CONSTRAINT phpbb3_notification_types_type UNIQUE (notification_type_name);


--
-- Name: phpbb3_notifications phpbb3_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_notifications
    ADD CONSTRAINT phpbb3_notifications_pkey PRIMARY KEY (notification_id);


--
-- Name: phpbb3_oauth_accounts phpbb3_oauth_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_oauth_accounts
    ADD CONSTRAINT phpbb3_oauth_accounts_pkey PRIMARY KEY (user_id, provider);


--
-- Name: phpbb3_posts phpbb3_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_posts
    ADD CONSTRAINT phpbb3_posts_pkey PRIMARY KEY (post_id);


--
-- Name: phpbb3_privmsgs_folder phpbb3_privmsgs_folder_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_privmsgs_folder
    ADD CONSTRAINT phpbb3_privmsgs_folder_pkey PRIMARY KEY (folder_id);


--
-- Name: phpbb3_privmsgs phpbb3_privmsgs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_privmsgs
    ADD CONSTRAINT phpbb3_privmsgs_pkey PRIMARY KEY (msg_id);


--
-- Name: phpbb3_privmsgs_rules phpbb3_privmsgs_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_privmsgs_rules
    ADD CONSTRAINT phpbb3_privmsgs_rules_pkey PRIMARY KEY (rule_id);


--
-- Name: phpbb3_profile_fields_data phpbb3_profile_fields_data_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_profile_fields_data
    ADD CONSTRAINT phpbb3_profile_fields_data_pkey PRIMARY KEY (user_id);


--
-- Name: phpbb3_profile_fields_lang phpbb3_profile_fields_lang_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_profile_fields_lang
    ADD CONSTRAINT phpbb3_profile_fields_lang_pkey PRIMARY KEY (field_id, lang_id, option_id);


--
-- Name: phpbb3_profile_fields phpbb3_profile_fields_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_profile_fields
    ADD CONSTRAINT phpbb3_profile_fields_pkey PRIMARY KEY (field_id);


--
-- Name: phpbb3_profile_lang phpbb3_profile_lang_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_profile_lang
    ADD CONSTRAINT phpbb3_profile_lang_pkey PRIMARY KEY (field_id, lang_id);


--
-- Name: phpbb3_qa_confirm phpbb3_qa_confirm_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_qa_confirm
    ADD CONSTRAINT phpbb3_qa_confirm_pkey PRIMARY KEY (confirm_id);


--
-- Name: phpbb3_ranks phpbb3_ranks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_ranks
    ADD CONSTRAINT phpbb3_ranks_pkey PRIMARY KEY (rank_id);


--
-- Name: phpbb3_reports phpbb3_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_reports
    ADD CONSTRAINT phpbb3_reports_pkey PRIMARY KEY (report_id);


--
-- Name: phpbb3_reports_reasons phpbb3_reports_reasons_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_reports_reasons
    ADD CONSTRAINT phpbb3_reports_reasons_pkey PRIMARY KEY (reason_id);


--
-- Name: phpbb3_search_results phpbb3_search_results_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_search_results
    ADD CONSTRAINT phpbb3_search_results_pkey PRIMARY KEY (search_key);


--
-- Name: phpbb3_search_wordlist phpbb3_search_wordlist_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_search_wordlist
    ADD CONSTRAINT phpbb3_search_wordlist_pkey PRIMARY KEY (word_id);


--
-- Name: phpbb3_search_wordlist phpbb3_search_wordlist_wrd_txt; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_search_wordlist
    ADD CONSTRAINT phpbb3_search_wordlist_wrd_txt UNIQUE (word_text);


--
-- Name: phpbb3_search_wordmatch phpbb3_search_wordmatch_un_mtch; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_search_wordmatch
    ADD CONSTRAINT phpbb3_search_wordmatch_un_mtch UNIQUE (word_id, post_id, title_match);


--
-- Name: phpbb3_sessions_keys phpbb3_sessions_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_sessions_keys
    ADD CONSTRAINT phpbb3_sessions_keys_pkey PRIMARY KEY (key_id, user_id);


--
-- Name: phpbb3_sessions phpbb3_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_sessions
    ADD CONSTRAINT phpbb3_sessions_pkey PRIMARY KEY (session_id);


--
-- Name: phpbb3_sitelist phpbb3_sitelist_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_sitelist
    ADD CONSTRAINT phpbb3_sitelist_pkey PRIMARY KEY (site_id);


--
-- Name: phpbb3_smilies phpbb3_smilies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_smilies
    ADD CONSTRAINT phpbb3_smilies_pkey PRIMARY KEY (smiley_id);


--
-- Name: phpbb3_styles_imageset_data phpbb3_styles_imageset_data_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_styles_imageset_data
    ADD CONSTRAINT phpbb3_styles_imageset_data_pkey PRIMARY KEY (image_id);


--
-- Name: phpbb3_styles_imageset phpbb3_styles_imageset_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_styles_imageset
    ADD CONSTRAINT phpbb3_styles_imageset_pkey PRIMARY KEY (imageset_id);


--
-- Name: phpbb3_styles phpbb3_styles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_styles
    ADD CONSTRAINT phpbb3_styles_pkey PRIMARY KEY (style_id);


--
-- Name: phpbb3_styles phpbb3_styles_style_name; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_styles
    ADD CONSTRAINT phpbb3_styles_style_name UNIQUE (style_name);


--
-- Name: phpbb3_styles_template phpbb3_styles_template_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_styles_template
    ADD CONSTRAINT phpbb3_styles_template_pkey PRIMARY KEY (template_id);


--
-- Name: phpbb3_styles_theme phpbb3_styles_theme_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_styles_theme
    ADD CONSTRAINT phpbb3_styles_theme_pkey PRIMARY KEY (theme_id);


--
-- Name: phpbb3_teampage phpbb3_teampage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_teampage
    ADD CONSTRAINT phpbb3_teampage_pkey PRIMARY KEY (teampage_id);


--
-- Name: phpbb3_topics phpbb3_topics_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_topics
    ADD CONSTRAINT phpbb3_topics_pkey PRIMARY KEY (topic_id);


--
-- Name: phpbb3_topics_posted phpbb3_topics_posted_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_topics_posted
    ADD CONSTRAINT phpbb3_topics_posted_pkey PRIMARY KEY (user_id, topic_id);


--
-- Name: phpbb3_topics_track phpbb3_topics_track_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_topics_track
    ADD CONSTRAINT phpbb3_topics_track_pkey PRIMARY KEY (user_id, topic_id);


--
-- Name: phpbb3_user_notifications phpbb3_user_notifications_itm_usr_mthd; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_user_notifications
    ADD CONSTRAINT phpbb3_user_notifications_itm_usr_mthd UNIQUE (item_type, item_id, user_id, method);


--
-- Name: phpbb3_users phpbb3_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_users
    ADD CONSTRAINT phpbb3_users_pkey PRIMARY KEY (user_id);


--
-- Name: phpbb3_users phpbb3_users_username_clean; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_users
    ADD CONSTRAINT phpbb3_users_username_clean UNIQUE (username_clean);


--
-- Name: phpbb3_warnings phpbb3_warnings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_warnings
    ADD CONSTRAINT phpbb3_warnings_pkey PRIMARY KEY (warning_id);


--
-- Name: phpbb3_words phpbb3_words_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_words
    ADD CONSTRAINT phpbb3_words_pkey PRIMARY KEY (word_id);


--
-- Name: phpbb3_zebra phpbb3_zebra_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3_zebra
    ADD CONSTRAINT phpbb3_zebra_pkey PRIMARY KEY (user_id, zebra_id);


--
-- Name: phpbb3recovery_profile_fields_data phpbb3recovery_profile_fields_data_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3recovery_profile_fields_data
    ADD CONSTRAINT phpbb3recovery_profile_fields_data_pkey PRIMARY KEY (user_id);


--
-- Name: phpbb3recovery_users phpbb3recovery_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3recovery_users
    ADD CONSTRAINT phpbb3recovery_users_pkey PRIMARY KEY (user_id);


--
-- Name: phpbb3recovery_users phpbb3recovery_users_username_clean; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.phpbb3recovery_users
    ADD CONSTRAINT phpbb3recovery_users_username_clean UNIQUE (username_clean);


--
-- Name: point_type point_type_id_point_type_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.point_type
    ADD CONSTRAINT point_type_id_point_type_pkey PRIMARY KEY (id_point_type);


--
-- Name: points points_id_point_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.points
    ADD CONSTRAINT points_id_point_pkey PRIMARY KEY (id_point);


--
-- Name: polygone_type polygone_type_id_polygone_type_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.polygone_type
    ADD CONSTRAINT polygone_type_id_polygone_type_pkey PRIMARY KEY (id_polygone_type);


--
-- Name: polygones polygones_id_polygone_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.polygones
    ADD CONSTRAINT polygones_id_polygone_pkey PRIMARY KEY (id_polygone);


--
-- Name: type_precision_gps type_precision_gps_id_type_precision_gps_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.type_precision_gps
    ADD CONSTRAINT type_precision_gps_id_type_precision_gps_pkey PRIMARY KEY (id_type_precision_gps);


--
-- Name: commentaires_auteur; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX commentaires_auteur ON public.commentaires USING btree (auteur_commentaire);


--
-- Name: commentaires_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX commentaires_date ON public.commentaires USING btree (date);


--
-- Name: commentaires_demande_correction; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX commentaires_demande_correction ON public.commentaires USING btree (demande_correction);


--
-- Name: commentaires_id_createur; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX commentaires_id_createur ON public.commentaires USING btree (id_createur_commentaire);


--
-- Name: commentaires_id_point; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX commentaires_id_point ON public.commentaires USING btree (id_point);


--
-- Name: commentaires_photo_existe; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX commentaires_photo_existe ON public.commentaires USING btree (photo_existe);


--
-- Name: emails_bounce_a_traiter; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX emails_bounce_a_traiter ON public.emails_bounce USING btree (a_traiter);


--
-- Name: emails_bounce_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX emails_bounce_date ON public.emails_bounce USING btree (date);


--
-- Name: historique_modifications_points_date_modification; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX historique_modifications_points_date_modification ON public.historique_modifications_points USING btree (date_modification);


--
-- Name: historique_modifications_points_id_point; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX historique_modifications_points_id_point ON public.historique_modifications_points USING btree (id_point);


--
-- Name: historique_modifications_points_id_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX historique_modifications_points_id_user ON public.historique_modifications_points USING btree (id_user);


--
-- Name: index_nom_page; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX index_nom_page ON public.pages_wiki USING btree (nom_page);


--
-- Name: phpbb3_acl_groups_auth_opt_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_acl_groups_auth_opt_id ON public.phpbb3_acl_groups USING btree (auth_option_id);


--
-- Name: phpbb3_acl_groups_auth_role_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_acl_groups_auth_role_id ON public.phpbb3_acl_groups USING btree (auth_role_id);


--
-- Name: phpbb3_acl_groups_group_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_acl_groups_group_id ON public.phpbb3_acl_groups USING btree (group_id);


--
-- Name: phpbb3_acl_roles_data_ath_op_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_acl_roles_data_ath_op_id ON public.phpbb3_acl_roles_data USING btree (auth_option_id);


--
-- Name: phpbb3_acl_roles_role_order; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_acl_roles_role_order ON public.phpbb3_acl_roles USING btree (role_order);


--
-- Name: phpbb3_acl_roles_role_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_acl_roles_role_type ON public.phpbb3_acl_roles USING btree (role_type);


--
-- Name: phpbb3_acl_users_auth_option_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_acl_users_auth_option_id ON public.phpbb3_acl_users USING btree (auth_option_id);


--
-- Name: phpbb3_acl_users_auth_role_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_acl_users_auth_role_id ON public.phpbb3_acl_users USING btree (auth_role_id);


--
-- Name: phpbb3_acl_users_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_acl_users_user_id ON public.phpbb3_acl_users USING btree (user_id);


--
-- Name: phpbb3_attachments_filetime; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_attachments_filetime ON public.phpbb3_attachments USING btree (filetime);


--
-- Name: phpbb3_attachments_is_orphan; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_attachments_is_orphan ON public.phpbb3_attachments USING btree (is_orphan);


--
-- Name: phpbb3_attachments_post_msg_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_attachments_post_msg_id ON public.phpbb3_attachments USING btree (post_msg_id);


--
-- Name: phpbb3_attachments_poster_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_attachments_poster_id ON public.phpbb3_attachments USING btree (poster_id);


--
-- Name: phpbb3_attachments_topic_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_attachments_topic_id ON public.phpbb3_attachments USING btree (topic_id);


--
-- Name: phpbb3_banlist_ban_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_banlist_ban_email ON public.phpbb3_banlist USING btree (ban_email, ban_exclude);


--
-- Name: phpbb3_banlist_ban_end; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_banlist_ban_end ON public.phpbb3_banlist USING btree (ban_end);


--
-- Name: phpbb3_banlist_ban_ip; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_banlist_ban_ip ON public.phpbb3_banlist USING btree (ban_ip, ban_exclude);


--
-- Name: phpbb3_banlist_ban_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_banlist_ban_user ON public.phpbb3_banlist USING btree (ban_userid, ban_exclude);


--
-- Name: phpbb3_bbcodes_display_on_post; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_bbcodes_display_on_post ON public.phpbb3_bbcodes USING btree (display_on_posting);


--
-- Name: phpbb3_bots_bot_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_bots_bot_active ON public.phpbb3_bots USING btree (bot_active);


--
-- Name: phpbb3_captcha_answers_qid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_captcha_answers_qid ON public.phpbb3_captcha_answers USING btree (question_id);


--
-- Name: phpbb3_captcha_questions_lang; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_captcha_questions_lang ON public.phpbb3_captcha_questions USING btree (lang_iso);


--
-- Name: phpbb3_config_is_dynamic; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_config_is_dynamic ON public.phpbb3_config USING btree (is_dynamic);


--
-- Name: phpbb3_confirm_confirm_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_confirm_confirm_type ON public.phpbb3_confirm USING btree (confirm_type);


--
-- Name: phpbb3_drafts_save_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_drafts_save_time ON public.phpbb3_drafts USING btree (save_time);


--
-- Name: phpbb3_forums_forum_lastpost_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_forums_forum_lastpost_id ON public.phpbb3_forums USING btree (forum_last_post_id);


--
-- Name: phpbb3_forums_left_right_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_forums_left_right_id ON public.phpbb3_forums USING btree (left_id, right_id);


--
-- Name: phpbb3_forums_watch_forum_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_forums_watch_forum_id ON public.phpbb3_forums_watch USING btree (forum_id);


--
-- Name: phpbb3_forums_watch_notify_stat; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_forums_watch_notify_stat ON public.phpbb3_forums_watch USING btree (notify_status);


--
-- Name: phpbb3_forums_watch_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_forums_watch_user_id ON public.phpbb3_forums_watch USING btree (user_id);


--
-- Name: phpbb3_groups_group_legend_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_groups_group_legend_name ON public.phpbb3_groups USING btree (group_legend, group_name);


--
-- Name: phpbb3_icons_display_on_posting; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_icons_display_on_posting ON public.phpbb3_icons USING btree (display_on_posting);


--
-- Name: phpbb3_lang_lang_iso; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_lang_lang_iso ON public.phpbb3_lang USING btree (lang_iso);


--
-- Name: phpbb3_log_forum_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_log_forum_id ON public.phpbb3_log USING btree (forum_id);


--
-- Name: phpbb3_log_log_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_log_log_time ON public.phpbb3_log USING btree (log_time);


--
-- Name: phpbb3_log_log_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_log_log_type ON public.phpbb3_log USING btree (log_type);


--
-- Name: phpbb3_log_reportee_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_log_reportee_id ON public.phpbb3_log USING btree (reportee_id);


--
-- Name: phpbb3_log_topic_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_log_topic_id ON public.phpbb3_log USING btree (topic_id);


--
-- Name: phpbb3_log_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_log_user_id ON public.phpbb3_log USING btree (user_id);


--
-- Name: phpbb3_login_attempts_att_for; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_login_attempts_att_for ON public.phpbb3_login_attempts USING btree (attempt_forwarded_for, attempt_time);


--
-- Name: phpbb3_login_attempts_att_ip; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_login_attempts_att_ip ON public.phpbb3_login_attempts USING btree (attempt_ip, attempt_time);


--
-- Name: phpbb3_login_attempts_att_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_login_attempts_att_time ON public.phpbb3_login_attempts USING btree (attempt_time);


--
-- Name: phpbb3_login_attempts_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_login_attempts_user_id ON public.phpbb3_login_attempts USING btree (user_id);


--
-- Name: phpbb3_moderator_cache_disp_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_moderator_cache_disp_idx ON public.phpbb3_moderator_cache USING btree (display_on_index);


--
-- Name: phpbb3_moderator_cache_forum_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_moderator_cache_forum_id ON public.phpbb3_moderator_cache USING btree (forum_id);


--
-- Name: phpbb3_modules_class_left_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_modules_class_left_id ON public.phpbb3_modules USING btree (module_class, left_id);


--
-- Name: phpbb3_modules_left_right_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_modules_left_right_id ON public.phpbb3_modules USING btree (left_id, right_id);


--
-- Name: phpbb3_modules_module_enabled; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_modules_module_enabled ON public.phpbb3_modules USING btree (module_enabled);


--
-- Name: phpbb3_notifications_item_ident; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_notifications_item_ident ON public.phpbb3_notifications USING btree (notification_type_id, item_id);


--
-- Name: phpbb3_notifications_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_notifications_user ON public.phpbb3_notifications USING btree (user_id, notification_read);


--
-- Name: phpbb3_oauth_states_provider; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_oauth_states_provider ON public.phpbb3_oauth_states USING btree (provider);


--
-- Name: phpbb3_oauth_states_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_oauth_states_user_id ON public.phpbb3_oauth_states USING btree (user_id);


--
-- Name: phpbb3_oauth_tokens_provider; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_oauth_tokens_provider ON public.phpbb3_oauth_tokens USING btree (provider);


--
-- Name: phpbb3_oauth_tokens_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_oauth_tokens_user_id ON public.phpbb3_oauth_tokens USING btree (user_id);


--
-- Name: phpbb3_poll_options_poll_opt_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_poll_options_poll_opt_id ON public.phpbb3_poll_options USING btree (poll_option_id);


--
-- Name: phpbb3_poll_options_topic_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_poll_options_topic_id ON public.phpbb3_poll_options USING btree (topic_id);


--
-- Name: phpbb3_poll_votes_topic_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_poll_votes_topic_id ON public.phpbb3_poll_votes USING btree (topic_id);


--
-- Name: phpbb3_poll_votes_vote_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_poll_votes_vote_user_id ON public.phpbb3_poll_votes USING btree (vote_user_id);


--
-- Name: phpbb3_poll_votes_vote_user_ip; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_poll_votes_vote_user_ip ON public.phpbb3_poll_votes USING btree (vote_user_ip);


--
-- Name: phpbb3_posts_forum_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_posts_forum_id ON public.phpbb3_posts USING btree (forum_id);


--
-- Name: phpbb3_posts_post_username; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_posts_post_username ON public.phpbb3_posts USING btree (post_username);


--
-- Name: phpbb3_posts_post_visibility; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_posts_post_visibility ON public.phpbb3_posts USING btree (post_visibility);


--
-- Name: phpbb3_posts_poster_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_posts_poster_id ON public.phpbb3_posts USING btree (poster_id);


--
-- Name: phpbb3_posts_poster_ip; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_posts_poster_ip ON public.phpbb3_posts USING btree (poster_ip);


--
-- Name: phpbb3_posts_tid_post_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_posts_tid_post_time ON public.phpbb3_posts USING btree (topic_id, post_time);


--
-- Name: phpbb3_posts_topic_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_posts_topic_id ON public.phpbb3_posts USING btree (topic_id);


--
-- Name: phpbb3_privmsgs_author_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_privmsgs_author_id ON public.phpbb3_privmsgs USING btree (author_id);


--
-- Name: phpbb3_privmsgs_author_ip; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_privmsgs_author_ip ON public.phpbb3_privmsgs USING btree (author_ip);


--
-- Name: phpbb3_privmsgs_folder_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_privmsgs_folder_user_id ON public.phpbb3_privmsgs_folder USING btree (user_id);


--
-- Name: phpbb3_privmsgs_message_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_privmsgs_message_time ON public.phpbb3_privmsgs USING btree (message_time);


--
-- Name: phpbb3_privmsgs_root_level; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_privmsgs_root_level ON public.phpbb3_privmsgs USING btree (root_level);


--
-- Name: phpbb3_privmsgs_rules_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_privmsgs_rules_user_id ON public.phpbb3_privmsgs_rules USING btree (user_id);


--
-- Name: phpbb3_privmsgs_to_author_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_privmsgs_to_author_id ON public.phpbb3_privmsgs_to USING btree (author_id);


--
-- Name: phpbb3_privmsgs_to_msg_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_privmsgs_to_msg_id ON public.phpbb3_privmsgs_to USING btree (msg_id);


--
-- Name: phpbb3_privmsgs_to_usr_flder_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_privmsgs_to_usr_flder_id ON public.phpbb3_privmsgs_to USING btree (user_id, folder_id);


--
-- Name: phpbb3_profile_fields_fld_ordr; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_profile_fields_fld_ordr ON public.phpbb3_profile_fields USING btree (field_order);


--
-- Name: phpbb3_profile_fields_fld_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_profile_fields_fld_type ON public.phpbb3_profile_fields USING btree (field_type);


--
-- Name: phpbb3_qa_confirm_lookup; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_qa_confirm_lookup ON public.phpbb3_qa_confirm USING btree (confirm_id, session_id, lang_iso);


--
-- Name: phpbb3_qa_confirm_session_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_qa_confirm_session_id ON public.phpbb3_qa_confirm USING btree (session_id);


--
-- Name: phpbb3_reports_pm_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_reports_pm_id ON public.phpbb3_reports USING btree (pm_id);


--
-- Name: phpbb3_reports_post_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_reports_post_id ON public.phpbb3_reports USING btree (post_id);


--
-- Name: phpbb3_search_wordlist_wrd_cnt; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_search_wordlist_wrd_cnt ON public.phpbb3_search_wordlist USING btree (word_count);


--
-- Name: phpbb3_search_wordmatch_post_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_search_wordmatch_post_id ON public.phpbb3_search_wordmatch USING btree (post_id);


--
-- Name: phpbb3_search_wordmatch_word_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_search_wordmatch_word_id ON public.phpbb3_search_wordmatch USING btree (word_id);


--
-- Name: phpbb3_sessions_keys_last_login; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_sessions_keys_last_login ON public.phpbb3_sessions_keys USING btree (last_login);


--
-- Name: phpbb3_sessions_session_fid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_sessions_session_fid ON public.phpbb3_sessions USING btree (session_forum_id);


--
-- Name: phpbb3_sessions_session_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_sessions_session_time ON public.phpbb3_sessions USING btree (session_time);


--
-- Name: phpbb3_sessions_session_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_sessions_session_user_id ON public.phpbb3_sessions USING btree (session_user_id);


--
-- Name: phpbb3_smilies_display_on_post; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_smilies_display_on_post ON public.phpbb3_smilies USING btree (display_on_posting);


--
-- Name: phpbb3_styles_imageset_data_i_d; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_styles_imageset_data_i_d ON public.phpbb3_styles_imageset_data USING btree (imageset_id);


--
-- Name: phpbb3_styles_imageset_imgset_nm; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX phpbb3_styles_imageset_imgset_nm ON public.phpbb3_styles_imageset USING btree (imageset_name);


--
-- Name: phpbb3_styles_template_data_tfn; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_styles_template_data_tfn ON public.phpbb3_styles_template_data USING btree (template_filename);


--
-- Name: phpbb3_styles_template_data_tid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_styles_template_data_tid ON public.phpbb3_styles_template_data USING btree (template_id);


--
-- Name: phpbb3_styles_template_tmplte_nm; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX phpbb3_styles_template_tmplte_nm ON public.phpbb3_styles_template USING btree (template_name);


--
-- Name: phpbb3_styles_theme_theme_name; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX phpbb3_styles_theme_theme_name ON public.phpbb3_styles_theme USING btree (theme_name);


--
-- Name: phpbb3_topics_fid_time_moved; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_topics_fid_time_moved ON public.phpbb3_topics USING btree (forum_id, topic_last_post_time, topic_moved_id);


--
-- Name: phpbb3_topics_forum_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_topics_forum_id ON public.phpbb3_topics USING btree (forum_id);


--
-- Name: phpbb3_topics_forum_id_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_topics_forum_id_type ON public.phpbb3_topics USING btree (forum_id, topic_type);


--
-- Name: phpbb3_topics_forum_vis_last; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_topics_forum_vis_last ON public.phpbb3_topics USING btree (forum_id, topic_visibility, topic_last_post_id);


--
-- Name: phpbb3_topics_last_post_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_topics_last_post_time ON public.phpbb3_topics USING btree (topic_last_post_time);


--
-- Name: phpbb3_topics_latest_topics; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_topics_latest_topics ON public.phpbb3_topics USING btree (forum_id, topic_last_post_time, topic_last_post_id, topic_moved_id);


--
-- Name: phpbb3_topics_topic_visibility; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_topics_topic_visibility ON public.phpbb3_topics USING btree (topic_visibility);


--
-- Name: phpbb3_topics_track_forum_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_topics_track_forum_id ON public.phpbb3_topics_track USING btree (forum_id);


--
-- Name: phpbb3_topics_track_topic_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_topics_track_topic_id ON public.phpbb3_topics_track USING btree (topic_id);


--
-- Name: phpbb3_topics_watch_notify_stat; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_topics_watch_notify_stat ON public.phpbb3_topics_watch USING btree (notify_status);


--
-- Name: phpbb3_topics_watch_topic_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_topics_watch_topic_id ON public.phpbb3_topics_watch USING btree (topic_id);


--
-- Name: phpbb3_topics_watch_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_topics_watch_user_id ON public.phpbb3_topics_watch USING btree (user_id);


--
-- Name: phpbb3_user_group_group_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_user_group_group_id ON public.phpbb3_user_group USING btree (group_id);


--
-- Name: phpbb3_user_group_group_leader; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_user_group_group_leader ON public.phpbb3_user_group USING btree (group_leader);


--
-- Name: phpbb3_user_group_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_user_group_user_id ON public.phpbb3_user_group USING btree (user_id);


--
-- Name: phpbb3_user_notifications_uid_itm_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_user_notifications_uid_itm_id ON public.phpbb3_user_notifications USING btree (user_id, item_id);


--
-- Name: phpbb3_user_notifications_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_user_notifications_user_id ON public.phpbb3_user_notifications USING btree (user_id);


--
-- Name: phpbb3_user_notifications_usr_itm_tpe; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_user_notifications_usr_itm_tpe ON public.phpbb3_user_notifications USING btree (user_id, item_type, item_id);


--
-- Name: phpbb3_users_user_birthday; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_users_user_birthday ON public.phpbb3_users USING btree (user_birthday);


--
-- Name: phpbb3_users_user_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_users_user_email ON public.phpbb3_users USING btree (user_email);


--
-- Name: phpbb3_users_user_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3_users_user_type ON public.phpbb3_users USING btree (user_type);


--
-- Name: phpbb3recovery_users_user_birthday; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3recovery_users_user_birthday ON public.phpbb3recovery_users USING btree (user_birthday);


--
-- Name: phpbb3recovery_users_user_email_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3recovery_users_user_email_hash ON public.phpbb3recovery_users USING btree (user_email_hash);


--
-- Name: phpbb3recovery_users_user_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX phpbb3recovery_users_user_type ON public.phpbb3recovery_users USING btree (user_type);


--
-- Name: points_altitude; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX points_altitude ON public.points USING btree (altitude);


--
-- Name: points_date_creation; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX points_date_creation ON public.points USING btree (date_creation);


--
-- Name: points_ferme; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX points_ferme ON public.points USING btree (conditions_utilisation);


--
-- Name: points_geom; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX points_geom ON public.points USING btree (geom);


--
-- Name: points_id_point_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX points_id_point_type ON public.points USING btree (id_point_type);


--
-- Name: points_id_type_precision_gps; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX points_id_type_precision_gps ON public.points USING btree (id_type_precision_gps);


--
-- Name: points_modele; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX points_modele ON public.points USING btree (modele);


--
-- Name: points_nom; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX points_nom ON public.points USING btree (nom);


--
-- Name: points_places; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX points_places ON public.points USING btree (places);


--
-- Name: points_places_matelas; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX points_places_matelas ON public.points USING btree (places_matelas);


--
-- Name: polygone_type_ordre_taille; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX polygone_type_ordre_taille ON public.polygone_type USING btree (ordre_taille);


--
-- Name: polygones_geom; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX polygones_geom ON public.polygones USING btree (geom);


--
-- Name: polygones_id_polygone_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX polygones_id_polygone_type ON public.polygones USING btree (id_polygone_type);


--
-- Name: polygones_nom_polygone; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX polygones_nom_polygone ON public.polygones USING btree (nom_polygone);


--
-- Name: type_precision_gps_ordre; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX type_precision_gps_ordre ON public.type_precision_gps USING btree (ordre);


--
-- PostgreSQL database dump complete
--

